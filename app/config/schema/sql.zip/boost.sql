-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 19, 2010 at 06:17 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.2-1ubuntu4.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `boost`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE IF NOT EXISTS `addresses` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `foreign_key` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `line_1` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `line_2` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zip` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `country_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `foreign_key`, `model`, `line_1`, `line_2`, `zip`, `country_id`, `state_id`, `city_id`, `created`, `modified`) VALUES
('50733ebe-59d7-11df-9ccf-000ae4cc0097', 'f375fcec-59d1-11df-9ccf-000ae4cc0097', 'offices', 'Ottho Heldringstraat 5', '', '1066 AZ', 'c5cf7076-5110-11df-9f9e-000ae4cc0097', '728fb3a2-59d6-11df-9ccf-000ae4cc0097', '533efa6c-59d6-11df-9ccf-000ae4cc0097', '2010-05-07 14:51:45', '2010-05-07 14:51:48');

-- --------------------------------------------------------

--
-- Table structure for table `auth_keys`
--

CREATE TABLE IF NOT EXISTS `auth_keys` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key_type_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `foreign_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `expires` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_key` (`key`),
  UNIQUE KEY `one_key_per_type` (`user_id`,`auth_key_type_id`),
  KEY `auth_key_type_id` (`auth_key_type_id`),
  KEY `user_id` (`user_id`),
  KEY `auth_key_type_id_2` (`auth_key_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_keys`
--


-- --------------------------------------------------------

--
-- Table structure for table `auth_key_types`
--

CREATE TABLE IF NOT EXISTS `auth_key_types` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_key_types`
--

INSERT INTO `auth_key_types` (`id`, `name`) VALUES
('49f32b94-94dc-4fd1-8205-eae223c1de0a', 'Account Activation'),
('49f32d17-9fd0-4ca0-8caf-f19323c1de0a', 'Login Cookie'),
('49f331ee-10b0-4082-b754-f28523c1de0a', 'Lost Password');

-- --------------------------------------------------------

--
-- Table structure for table `capabilities`
--

CREATE TABLE IF NOT EXISTS `capabilities` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `capability_category_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `capabilities`
--

INSERT INTO `capabilities` (`id`, `capability_category_id`, `name`, `description`, `created`, `modified`) VALUES
('6c52da18-5202-11df-952d-000ae4cc0097', 'a74e557a-51f3-11df-952d-000ae4cc0097', 'Rapid Data Entry', 'Quick entry forms (i.e. usable without mouse) are available to enter information collected for example on paper in the street. This forms are customized by NRO and payment types (or other contextual factors).', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c52dc70-5202-11df-952d-000ae4cc0097', 'a74e557a-51f3-11df-952d-000ae4cc0097', 'Bulk Data Load (Batch)', 'The system includes a file upload feature to import several records at once, possibly with various file format (csv, flf, etc.) and object/field patterns. This file can be provided by a third party or the result of an export from another system.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c52dd6a-5202-11df-952d-000ae4cc0097', 'a74e557a-51f3-11df-952d-000ae4cc0097', 'Online Constituent Self-Service', 'A space where the supporter can edit his/her information directly without contacting GP staff.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c52ddf6-5202-11df-952d-000ae4cc0097', 'a74e557a-51f3-11df-952d-000ae4cc0097', 'Remote Access', 'A special configuration is needed to allow 3rd party agencies to perform the quick entry for GP, without loging into the system or accessing constituent data.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c5e401a-5202-11df-952d-000ae4cc0097', 'a74e564c-51f3-11df-952d-000ae4cc0097', 'Detection Criteria Configuration', 'The ability to define duplication identification parameters, adjusting detection sensitivity levels across multiple fields (e.g. constituent name, email address, mobile number, and mailing address) and configurable by country.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c5e4376-5202-11df-952d-000ae4cc0097', 'a74e564c-51f3-11df-952d-000ae4cc0097', 'Online Duplication Detection', 'Deduplication mechanism to identify potential duplicates after a direct entry of a new constituent in the system.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c5e4484-5202-11df-952d-000ae4cc0097', 'a74e564c-51f3-11df-952d-000ae4cc0097', 'Batch Duplication Detection', 'Deduplication mechanism to identify potential duplicates after a file batch import.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c5e456a-5202-11df-952d-000ae4cc0097', 'a74e564c-51f3-11df-952d-000ae4cc0097', 'Constituent Record Merge', 'A feature to merge records marked for deduplication, allowing the end user to select the attributes to retain or overwrite. It also will recalculate relevant fields (e.g. first gift, largest gift, originating source).', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c65bba6-5202-11df-952d-000ae4cc0097', 'a74e570a-51f3-11df-952d-000ae4cc0097', '360 Degree Constituent Profile', 'All the data related to the constituent activities of all types (outbound/inbuond contact, on-line advocacy, email opens/click-throughs, etc.) across time is accessible in a single view and available for segmentation.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c65c056-5202-11df-952d-000ae4cc0097', 'a74e570a-51f3-11df-952d-000ae4cc0097', 'Donation Log', 'Current and historical log of all financial transactions, including all donation types (i.e. tributes, grants, legacies, etc) and merchandise purchases.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c65c1f0-5202-11df-952d-000ae4cc0097', 'a74e570a-51f3-11df-952d-000ae4cc0097', 'Relationship Tree', 'It is possible to maintain the graph of the relationship between constituents (ex: friends, household, etc). ', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c65c34e-5202-11df-952d-000ae4cc0097', 'a74e570a-51f3-11df-952d-000ae4cc0097', 'Multiple Address Maintenance', 'A constituent record can support multiple addresses and contact details (i.e. phone, email addresses) with the associated contact preference and active/seasonal dates.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c65c4c0-5202-11df-952d-000ae4cc0097', 'a74e570a-51f3-11df-952d-000ae4cc0097', 'International Address Standardization', 'While the user can enter the address in several formats, the system then standardize this input in a consistent way based on country-level postal requirements.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c65c628-5202-11df-952d-000ae4cc0097', 'a74e570a-51f3-11df-952d-000ae4cc0097', 'International Address Verification', 'Postal codes are verified against a table of legal values. In countries where data is available, the address is verified that it is ''mailable'', and a service is provided to update addresses as postal codes, street names, etc. are changed by postal authorities.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c65c7a4-5202-11df-952d-000ae4cc0097', 'a74e570a-51f3-11df-952d-000ae4cc0097', 'Comments & Attachments', 'GP can add comments and attach file to  a constituent record. Comments can also be added to contact moments e.g. phone call. Documents of all standard formats (e.g. jpg, doc, xls) can be attached to a constituent record, or an individual transaction.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c65c920-5202-11df-952d-000ae4cc0097', 'a74e570a-51f3-11df-952d-000ae4cc0097', 'Cross-Channel Activity Log', 'Constituent acvities across all applicable communication channels is logged with clear identifiction of the channel used.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c6bb5ce-5202-11df-952d-000ae4cc0097', 'a74e5872-51f3-11df-952d-000ae4cc0097', 'Intelligent Contact Routing', 'Supporters are put in communication with the right interlocutor based on the request. This include country / NRO  and potentially department routing (ex: climate campaigner in Italy, supporter services in India, etc).', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c6bb826-5202-11df-952d-000ae4cc0097', 'a74e5872-51f3-11df-952d-000ae4cc0097', 'Communication Templates / Scripts', 'GP Staff can manage scripts to help facilitate 1-0-1 contact with supporters over multiple communication channels. Scripts are defined as telemarketing scripts, standard email templates, scripts for handling constituent complaints, etc.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c6bb8b2-5202-11df-952d-000ae4cc0097', 'a74e5872-51f3-11df-952d-000ae4cc0097', 'Inbound & Outbound Contact Moments', 'The system allows creating (and, when appropriate, automatically creates) outbound and inbound contact moments (also called activities), including events happening in other systems (cf. Integration).', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c6bbc18-5202-11df-952d-000ae4cc0097', 'a74e5872-51f3-11df-952d-000ae4cc0097', 'Quality Assurance Monitoring', 'System tools that monitor inbound and outbound communication - recording phone calls, scanning emails, SMS, and web communication for key words, noncompliant behavior, etc. QA tools help facilitate staff training.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c6bbcae-5202-11df-952d-000ae4cc0097', 'a74e5872-51f3-11df-952d-000ae4cc0097', 'Merchandise Giveaways / Benefits Tracking', 'GP Staff can manage merchandise sales (including tax and shipping). This also includes giveaways to be use are promotion materials in special events.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c6bbd26-5202-11df-952d-000ae4cc0097', 'a74e5872-51f3-11df-952d-000ae4cc0097', 'One-Off Receipts / Acknowledgements', 'Supporter services can print and send donation receipt per donation. These receipts may be used for tax deduction and are generated based on the country legislation and NRO template. Receipts should have customisable layout including letter attachment.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c6bbda8-5202-11df-952d-000ae4cc0097', 'a74e5872-51f3-11df-952d-000ae4cc0097', 'Bulk Receipts / Acknowledgements', 'Once a year (or more) all the receipt for the period can be generated and printed as a batch. Including or excluding previously printed receipts.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c727e36-5202-11df-952d-000ae4cc0097', 'a74e5926-51f3-11df-952d-000ae4cc0097', 'Cultivation / Solicitation Plan Development', 'The systems allow managing cultivation and solicitation plans (e.g. the essence of the major donor strategy) at an individual or group of individuals level.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c728052-5202-11df-952d-000ae4cc0097', 'a74e5926-51f3-11df-952d-000ae4cc0097', 'Prospect Management & Forecasting', 'The systems allow managing and converting leads/prospects as well as monitoring/forecasting the performance of such activities and expected income based on previous performance and conversion ratios.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c7280de-5202-11df-952d-000ae4cc0097', 'a74e5926-51f3-11df-952d-000ae4cc0097', 'Proposal Lifecycle Management	', 'Ability to define workflow for major donor cycle, with prompts and reminders for follow-ups and next steps.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c728156-5202-11df-952d-000ae4cc0097', 'a74e5926-51f3-11df-952d-000ae4cc0097', 'Moves Management', 'System captures defined ''stages'' of prospect development (e.g. identification, qualification, cultivation, solicitation, stewardship) which is supported by workflow and analytics.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c79567a-5202-11df-952d-000ae4cc0097', 'a74e59f8-51f3-11df-952d-000ae4cc0097', 'Availability Tracking & Scheduling', 'The system allows maintaining the list of volunteers and their skills, availability and schedule appointments / work sessions.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c7958c8-5202-11df-952d-000ae4cc0097', 'a74e59f8-51f3-11df-952d-000ae4cc0097', 'Performance Management', 'The system allows monitoring the performance of a volunteer or a group of volunteers.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c805718-5202-11df-952d-000ae4cc0097', 'a74e5b92-51f3-11df-952d-000ae4cc0097', 'File Segmentation', 'System supports segmentation based on RFM, prior donor actions, inbound and outbound contacts, cyber activist actions, events attended, interests. System allows end-user to manually assign a segment ID code.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c805b96-5202-11df-952d-000ae4cc0097', 'a74e5b92-51f3-11df-952d-000ae4cc0097', 'Segment Performance', 'It is possible to monitor the performance and perform data analysis on a given segment or group of segments over time across campaigns.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c805d26-5202-11df-952d-000ae4cc0097', 'a74e5b92-51f3-11df-952d-000ae4cc0097', 'Segment ID Codes', 'System automatically generates segment codes for an appeal when segmenting for a campaign.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c805e8e-5202-11df-952d-000ae4cc0097', 'a74e5b92-51f3-11df-952d-000ae4cc0097', 'Test / Control Segments', 'Campaign execution includes the ability for testing and optimization of the message using a variety of methods (e.g. splits, Nth select, random selects).', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c805fec-5202-11df-952d-000ae4cc0097', 'a74e5b92-51f3-11df-952d-000ae4cc0097', 'Campaign Optimization', 'Based on past and current performance it possible to develop the most appropriate set of segments to include in order to optimize ROI. A what-if analysis tool allows end-users to forecast segment performance and tweak parameters for optimal results.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c806168-5202-11df-952d-000ae4cc0097', 'a74e5b92-51f3-11df-952d-000ae4cc0097', 'Response Analysis', 'It is possible to visualize and analyze the performance for a given campaign  based on multi dimensional segments and campaign results.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c86f47e-5202-11df-952d-000ae4cc0097', 'a74e5c50-51f3-11df-952d-000ae4cc0097', 'Campaign Plan Development', 'Defining the objectives and strategy for fundraising/advocacy campaigns at a global, NRO, team level, etc. Plan development includes budget definition, resource allocation, detailed workplan, etc.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c86f6e0-5202-11df-952d-000ae4cc0097', 'a74e5c50-51f3-11df-952d-000ae4cc0097', 'Multi-Stage Campaign Set Up', 'The system offers the opportunity to set up a multi-stage (multi-appeal across varying timeframes), multi-channel campaign. Such campaign structure and definition can be reused for future campaigns.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c86f776-5202-11df-952d-000ae4cc0097', 'a74e5c50-51f3-11df-952d-000ae4cc0097', 'Response Triggered Workflow Design', 'Rule definition to manage inbound communication across multiple channels: web, email, mail, sms, phone, etc. Rules include automated reactions to hard-bounce, soft-bounce, etc. response types in addition to custom rules that define multi-channel reaction strategies (i.e. more than 2 email responses from a single constituent results in a task to place an outbound phone call).', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c86f848-5202-11df-952d-000ae4cc0097', 'a74e5c50-51f3-11df-952d-000ae4cc0097', 'List Management', 'The system allows maintaining a list/segment of constituents (ex: donor, cyberactivist, newsletter, etc.).', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c86fe74-5202-11df-952d-000ae4cc0097', 'a74e5c50-51f3-11df-952d-000ae4cc0097', 'Communication Template Development', 'The system allows setting up templates for appeals across channels (ex: newsletter, sms welcome message), so that they can be reused in different NROs or for other campaigns.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c8e47ba-5202-11df-952d-000ae4cc0097', 'a74e5d22-51f3-11df-952d-000ae4cc0097', 'Venue Management', 'The system offers facilities to help organize an event (ex: accommodation, catering, resources, agenda, vendor and contract management, etc.)', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c8e4c60-5202-11df-952d-000ae4cc0097', 'a74e5d22-51f3-11df-952d-000ae4cc0097', 'Ticket Sale & RSVP Tracking', 'The system allows selling ticket and setting up reservation with validation and track from a staff perspective and ideally self service facilities for the consituent.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c8e4df0-5202-11df-952d-000ae4cc0097', 'a74e5d22-51f3-11df-952d-000ae4cc0097', 'Seating Chart Management', 'The system allow managing rooms/places and associated sitting charts for events.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c949494-5202-11df-952d-000ae4cc0097', 'a74e5dfe-51f3-11df-952d-000ae4cc0097', 'Multi-Channel Outbound Communication Management', 'It is possible to setup a communication across various channels: web, email, mail, sms, phone, advertisement (radio spot, billboard, etc.), etc. within the same appeal/campaign/segmentation.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c9496d8-5202-11df-952d-000ae4cc0097', 'a74e5dfe-51f3-11df-952d-000ae4cc0097', 'Multi-Channel Inbound Communication Management', 'It is possible to receive communication across various channels: web, email, mail, sms, phone, etc. within the same appeal/campaign/segmentation. The system should record an inbound communication moment associated to the constituent.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c94976e-5202-11df-952d-000ae4cc0097', 'a74e5dfe-51f3-11df-952d-000ae4cc0097', 'Expense Management', 'Expenses can be recorded on the campaign level with drill down to the appeal and segment level.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c9497dc-5202-11df-952d-000ae4cc0097', 'a74e5dfe-51f3-11df-952d-000ae4cc0097', 'Budget & Status Tracking', 'It is possible manage and track the status of a budget for a given campaign, team or unit.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c9b5f40-5202-11df-952d-000ae4cc0097', 'a74e5fc0-51f3-11df-952d-000ae4cc0097', 'Venue Management', 'The system allow managing the list of cities and venues where Direct Dialogue activities are taking place.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c9b6170-5202-11df-952d-000ae4cc0097', 'a74e5fc0-51f3-11df-952d-000ae4cc0097', 'Expense Management', 'The system allows managing the expenses (and associated resources) for Direct Dialogue activities, and have these allocated to the relevant campaign.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6c9b61fc-5202-11df-952d-000ae4cc0097', 'a74e5fc0-51f3-11df-952d-000ae4cc0097', 'Team Mobilization & Shift Management', 'The system stores recruiter demographic and availability data, including historical and planned shifts, results achieved, and hours recruited.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6ca3ef34-5202-11df-952d-000ae4cc0097', 'a74e60b0-51f3-11df-952d-000ae4cc0097', 'Recruiter Lifecycle Management', 'The system provide facilities to manage the recruiters from recruitment to the end/renewal of contract.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6ca3f1c8-5202-11df-952d-000ae4cc0097', 'a74e60b0-51f3-11df-952d-000ae4cc0097', 'Remuneration Package Management', 'The system allows setting up incentive based on the recruiter performance.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6ca3f25e-5202-11df-952d-000ae4cc0097', 'a74e60b0-51f3-11df-952d-000ae4cc0097', 'Performance Management	', 'The system allow monitoring the performance of the recruiters (conversion rate, drop-out rate of the recruited people over time for a given recruiter, etc.) and venue over time.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6caae5a0-5202-11df-952d-000ae4cc0097', 'a74e6290-51f3-11df-952d-000ae4cc0097', 'One-Off Donation', 'The system allows setting up one-off donations.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6caaea5a-5202-11df-952d-000ae4cc0097', 'a74e6290-51f3-11df-952d-000ae4cc0097', 'Recurring Donation', 'The system allows setting up recurring donation (monthly, yearly, etc.), and offer the associated facilities (manual and/or automated) to process such gift when due.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6caaec12-5202-11df-952d-000ae4cc0097', 'a74e6290-51f3-11df-952d-000ae4cc0097', 'Split Donation', 'A single donation can be split into multiple parts with different designations and/or appeals and/or type (donation, merchandise, subscription).', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6caaed98-5202-11df-952d-000ae4cc0097', 'a74e6290-51f3-11df-952d-000ae4cc0097', 'Pledges', 'A pledge (or promise) of a donation can be recorded against a donor record and managed with follow up activity for conversion to payment. Pledges are then matched against actual payments when they occur.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6caaef1e-5202-11df-952d-000ae4cc0097', 'a74e6290-51f3-11df-952d-000ae4cc0097', 'In Memory / Tribute', 'The system allows setting up one gift as a tribute to another person. With the details rcorded in the donors record.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6caaf086-5202-11df-952d-000ae4cc0097', 'a74e6290-51f3-11df-952d-000ae4cc0097', 'Soft Credit', 'Soft credits allow more than one constituent to share credit for a single gift without adding duplicate gift records to the database.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6caaf1e4-5202-11df-952d-000ae4cc0097', 'a74e6290-51f3-11df-952d-000ae4cc0097', 'Grants', 'The system supports the fundraising for, and processing of foundation grant transactions (grants management itself is not a requirement).', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cab0418-5202-11df-952d-000ae4cc0097', 'a74e6290-51f3-11df-952d-000ae4cc0097', 'Legacy', 'System supports the management of legacy giving, including tracking anticipated amounts, actual amounts, partial payments, residual payments.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cab05d0-5202-11df-952d-000ae4cc0097', 'a74e6290-51f3-11df-952d-000ae4cc0097', 'Workplace Giving', 'The system allows organizing workplace giving.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cab072e-5202-11df-952d-000ae4cc0097', 'a74e6290-51f3-11df-952d-000ae4cc0097', 'Virtual Gift', 'The system allows associating one financial gift with a virtual retribution (ex: ecard, picture, etc.).', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cb00abc-5202-11df-952d-000ae4cc0097', 'a74e6358-51f3-11df-952d-000ae4cc0097', 'Literature / Publication Purchases', 'The systems allows managing the list of publications (periodical, book, leaflet, etc.), the stock and associated purchase. As part of merchandise process.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cb00f94-5202-11df-952d-000ae4cc0097', 'a74e6358-51f3-11df-952d-000ae4cc0097', 'Apparel / Other Item Purchases', 'The system allows the end-user to process purchase requests of other items (ex: sticker, mugs, t-shirts, etc).', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cb01124-5202-11df-952d-000ae4cc0097', 'a74e6358-51f3-11df-952d-000ae4cc0097', 'Sales Tax & Shipping Calculations', 'The system allow managing the local taxation rules as well the different shipping facilities and their associated procedures.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cb012a0-5202-11df-952d-000ae4cc0097', 'a74e6358-51f3-11df-952d-000ae4cc0097', 'Sales Tax & Shipping Calculations', 'Fulfillment Date & Time	Date of dispatch and packaging can be recorded on the donor record for access by supporter services or online self service.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cb51106-5202-11df-952d-000ae4cc0097', 'a74e6fa6-51f3-11df-952d-000ae4cc0097', 'Concurrent Donations', 'System supports a donor having more than one concurrent payment plan, possibly with different payment methods.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cb51534-5202-11df-952d-000ae4cc0097', 'a74e6fa6-51f3-11df-952d-000ae4cc0097', 'Rejection / Error Management', 'The systems allows monitoring the rejected or erroneous transactions and triggers the associated follow-up activities and/or automated processes. Full details or rejected transactions are recorded in the donor record.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cb516e2-5202-11df-952d-000ae4cc0097', 'a74e6fa6-51f3-11df-952d-000ae4cc0097', 'Refunds', 'The system allows performing a refund operation and/or maintain the description of the associated procedure.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cb51840-5202-11df-952d-000ae4cc0097', 'a74e6fa6-51f3-11df-952d-000ae4cc0097', 'Subscription Management', 'The system supports a magazine subscription programs.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cb5199e-5202-11df-952d-000ae4cc0097', 'a74e6fa6-51f3-11df-952d-000ae4cc0097', 'Bank / Credit Card Institution File Management', 'The system allows maintaining the bank and payment gateway interface, ie. the list of institutions, the associated account and the file import and export formats.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cb51b06-5202-11df-952d-000ae4cc0097', 'a74e6fa6-51f3-11df-952d-000ae4cc0097', 'Multi-Currency', 'The system supports multiple currencies within an NRO (one per batch and transaction) including an individual having transactions in more than one currency.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cba0fda-5202-11df-952d-000ae4cc0097', 'a74e7096-51f3-11df-952d-000ae4cc0097', 'Designation / Account Mapping', 'The system maintains a reference between a designation on a transaction and the General ledger revenue account. It also supports using more than one cash account (to be debited).', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cba121e-5202-11df-952d-000ae4cc0097', 'a74e7096-51f3-11df-952d-000ae4cc0097', 'Account / Campaign Expense Mapping', 'Expenses in the General Ledger synch back to fundraising and are associated to the appropriate campaign.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cbf2e66-5202-11df-952d-000ae4cc0097', '78b5e7c4-51f2-11df-952d-000ae4cc0097', 'Constituent Service Performance', 'The systems allows monitoring the performance of the supporter services activities, such as the number of records opened, the average response time for mail and email, the conversion rate, etc.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cbf30c8-5202-11df-952d-000ae4cc0097', '78b5e7c4-51f2-11df-952d-000ae4cc0097', 'Communication Campaign Performance', 'The system allows monitoring the performance of  advocacy activities (open, bounce, signup rate, etc.) over time for a given campaign at a segment, appeal and campaign level.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cbf3168-5202-11df-952d-000ae4cc0097', '78b5e7c4-51f2-11df-952d-000ae4cc0097', 'Fundraising Performance', 'The system allows monitoring the performance of the fundraising effort over time by segment, appeal and campaign (such as conversion, upgrade, etc.) as well as the attrition rate and other KPI.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cbf31f4-5202-11df-952d-000ae4cc0097', '78b5e7c4-51f2-11df-952d-000ae4cc0097', 'Direct Dialogue Performance', 'The system allows monitoring the performance over time of the direct dialog activities at a NRO, city, team, recruiter level.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cbf3546-5202-11df-952d-000ae4cc0097', '78b5e7c4-51f2-11df-952d-000ae4cc0097', 'Constituent Lifecycle Analysis', 'The system allows monitoring analysing the constituent lifecycle (at an individual or segment level), based on the previous segmentation and activities, geographic and demographic data, etc.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cc46f66-5202-11df-952d-000ae4cc0097', '78b5e86e-51f2-11df-952d-000ae4cc0097', 'Task Management', 'Is possible to define manually tasks and follow-up activities to be performed via the system or outside the system. Also possible to allocate tasks per suppoter service staff member and report on the status of those tasks. Workflow can be used to escalate incomplete tasks or to automatically task someone else.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cc4729a-5202-11df-952d-000ae4cc0097', '78b5e86e-51f2-11df-952d-000ae4cc0097', 'Workflow Management', 'System includes integrated workflow to support movement through the system, including time-based triggers, ability to send alerts via email, sms, and internal tasks.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cc47a6a-5202-11df-952d-000ae4cc0097', '78b5e86e-51f2-11df-952d-000ae4cc0097', 'Online Help Files', 'Help file are proposed for each functionalities which are customizable by the NRO.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cc47b6e-5202-11df-952d-000ae4cc0097', '78b5e86e-51f2-11df-952d-000ae4cc0097', 'On-Demand Export File Generation', 'The system allows exporting data and managing the associated export templates in different formats (cvs, xml, etc.)', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cc9c63c-5202-11df-952d-000ae4cc0097', '78b5e904-51f2-11df-952d-000ae4cc0097', 'Audit Trail (Date/Time/User)', 'The system logs the details of the user activities on every objects as well as the operations (such as import/export) that have been performed.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cc9ca74-5202-11df-952d-000ae4cc0097', '78b5e904-51f2-11df-952d-000ae4cc0097', 'Rollback', 'When applicable changes made to the data can be reversed.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cc9cc04-5202-11df-952d-000ae4cc0097', '78b5e904-51f2-11df-952d-000ae4cc0097', 'Data Encryption', 'Sensitive data can be encrypted using a public/private key scheme. Sensitive information send by email (for backup, integration or other purposes) are also encrypted via PGP.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cc9cd94-5202-11df-952d-000ae4cc0097', '78b5e904-51f2-11df-952d-000ae4cc0097', 'On-Screen Field Validation', 'The system allows setting up custom validation rules (per NRO) with the associated precise contextual error or notice messages in the appropriate language.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cc9cf10-5202-11df-952d-000ae4cc0097', '78b5e904-51f2-11df-952d-000ae4cc0097', 'Batch Field Validation', 'Invalid records are detected during a batch import and the possibility is given to the user to continue with the valid record or cancel the import in order to fix the incriminated records.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cc9d082-5202-11df-952d-000ae4cc0097', '78b5e904-51f2-11df-952d-000ae4cc0097', 'Multi-Level User Roles & Privileges', 'The system proposes a fine grained access control mechanism similar to Access Control List (ACL)  for all the resources (object and properties). Such system allows defining a generic hierarchy of role (with rights inheritance) and also allows overriding these rules for a single user account level.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cc9d21c-5202-11df-952d-000ae4cc0097', '78b5e904-51f2-11df-952d-000ae4cc0097', 'Security Compliance', 'Data protection mechanism and procedure as described in ISO and/or PCI standards are implemented.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cce9306-5202-11df-952d-000ae4cc0097', '78b5e9ae-51f2-11df-952d-000ae4cc0097', 'Bar Code Scanning & Document Retrieval', 'Documents, forms, etc. can be tagged with a bar code for easy retrieval at a later stage. It also allows to tag documents with keyword and organize them by categories, as with a classic filesystem.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cce9b58-5202-11df-952d-000ae4cc0097', '78b5e9ae-51f2-11df-952d-000ae4cc0097', 'OCR (Optical Character Recognition) Integration', 'The system allows importing data by scanning documents such as direct dialog forms.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cce9d2e-5202-11df-952d-000ae4cc0097', '78b5e9ae-51f2-11df-952d-000ae4cc0097', 'Cross-Document Relationship Tracking', 'Documents are linked to other documents.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6cce9eaa-5202-11df-952d-000ae4cc0097', '78b5e9ae-51f2-11df-952d-000ae4cc0097', 'Constituent-Document Relationship Tracking', 'Documents are linked to constituent records.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6ccea008-5202-11df-952d-000ae4cc0097', '78b5e9ae-51f2-11df-952d-000ae4cc0097', 'Version Control', 'The system offers check-in and check-out of documents, as well as version control management.', '2010-04-27 14:22:16', '2010-04-27 14:22:19'),
('6ccea170-5202-11df-952d-000ae4cc0097', '78b5e9ae-51f2-11df-952d-000ae4cc0097', 'Print', 'Documents can be printed for distribution via direct mail, inter-office correspondence, etc.', '2010-04-27 14:22:16', '2010-04-27 14:22:19');

-- --------------------------------------------------------

--
-- Table structure for table `capabilities_categories`
--

CREATE TABLE IF NOT EXISTS `capabilities_categories` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `serial` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `capabilities_categories`
--

INSERT INTO `capabilities_categories` (`id`, `name`, `serial`, `parent_id`, `created`, `modified`) VALUES
('78b5e22e-51f2-11df-952d-000ae4cc0097', 'Constituent Data Management', '1.0', '', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('78b5e49a-51f2-11df-952d-000ae4cc0097', 'Constituent Relationship Management', '2.0', '', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('78b5e576-51f2-11df-952d-000ae4cc0097', 'Campaign Management', '3.0', '', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('78b5e62a-51f2-11df-952d-000ae4cc0097', 'Direct Dialogue Management', '4.0', '', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('78b5e6f2-51f2-11df-952d-000ae4cc0097', 'Donation Management & Accounting', '5.0', '', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('78b5e7c4-51f2-11df-952d-000ae4cc0097', 'Monitoring & Evaluation', '6.0', '', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('78b5e86e-51f2-11df-952d-000ae4cc0097', 'Staff Efficiency Tools', '7.0', '', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('78b5e904-51f2-11df-952d-000ae4cc0097', 'Data Maintenance', '8.0', '', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('78b5e9ae-51f2-11df-952d-000ae4cc0097', 'Document Management', '9.0', '', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e557a-51f3-11df-952d-000ae4cc0097', 'Data Entry', '1.1', '78b5e22e-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e564c-51f3-11df-952d-000ae4cc0097', 'Data De-Duplication', '1.2', '78b5e22e-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e570a-51f3-11df-952d-000ae4cc0097', 'Profile Management', '1.3', '78b5e22e-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e5872-51f3-11df-952d-000ae4cc0097', 'Constituent Services', '2.1', '78b5e49a-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e5926-51f3-11df-952d-000ae4cc0097', 'Major Gift / Foundation Management', '2.2', '78b5e49a-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e59f8-51f3-11df-952d-000ae4cc0097', 'Volunteer Management', '2.3', '78b5e49a-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e5b92-51f3-11df-952d-000ae4cc0097', 'Market Segmentation', '3.1', '78b5e576-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e5c50-51f3-11df-952d-000ae4cc0097', 'Campaign Development', '3.2', '78b5e576-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e5d22-51f3-11df-952d-000ae4cc0097', 'Event Planning', '3.3', '78b5e576-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e5dfe-51f3-11df-952d-000ae4cc0097', 'Campaign Execution', '3.4', '78b5e576-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e5fc0-51f3-11df-952d-000ae4cc0097', 'Direct Dialogue Logistics', '4.1', '78b5e576-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e60b0-51f3-11df-952d-000ae4cc0097', 'Recruiter Management', '4.2', '78b5e576-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e6290-51f3-11df-952d-000ae4cc0097', 'Donation Management', '5.1', '78b5e6f2-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e6358-51f3-11df-952d-000ae4cc0097', 'Merchandise Management', '5.2', '78b5e6f2-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e6fa6-51f3-11df-952d-000ae4cc0097', 'Payment Processing', '5.3', '78b5e6f2-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30'),
('a74e7096-51f3-11df-952d-000ae4cc0097', 'General Ledger Interface', '5.4', '78b5e6f2-51f2-11df-952d-000ae4cc0097', '2010-04-27 13:41:30', '2010-04-27 13:41:30');

-- --------------------------------------------------------

--
-- Table structure for table `capabilities_channels`
--

CREATE TABLE IF NOT EXISTS `capabilities_channels` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `capability_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `channel_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `capabilities_channels`
--


-- --------------------------------------------------------

--
-- Table structure for table `capabilities_requirements`
--

CREATE TABLE IF NOT EXISTS `capabilities_requirements` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `capability_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `requirement_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `capabilities_requirements`
--


-- --------------------------------------------------------

--
-- Table structure for table `channels`
--

CREATE TABLE IF NOT EXISTS `channels` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `traceable` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `channels`
--

INSERT INTO `channels` (`id`, `name`, `traceable`, `created`, `modified`) VALUES
('1ca51d9e-5209-11df-952d-000ae4cc0097', 'television', 0, '2010-04-27 16:25:14', '2010-04-27 16:25:14'),
('1ca51fba-5209-11df-952d-000ae4cc0097', 'radio', 0, '2010-04-27 16:25:14', '2010-04-27 16:25:14'),
('2ae2b59c-5209-11df-952d-000ae4cc0097', 'billboard', 0, '2010-04-27 16:28:31', '2010-04-27 16:28:31'),
('2ae2b7cc-5209-11df-952d-000ae4cc0097', 'press', 0, '2010-04-27 16:28:31', '2010-04-27 16:28:31'),
('b7051da4-5208-11df-952d-000ae4cc0097', 'web', 1, '2010-04-27 16:25:14', '2010-04-27 16:25:14'),
('b7052038-5208-11df-952d-000ae4cc0097', 'mobile web', 1, '2010-04-27 16:25:14', '2010-04-27 16:25:14'),
('bd46ea10-520a-11df-952d-000ae4cc0097', 'mass email / newsletter', 1, '2010-04-27 16:25:14', '2010-04-27 16:25:14'),
('bd46ed26-520a-11df-952d-000ae4cc0097', 'email', 1, '2010-04-27 16:25:14', '2010-04-27 16:25:14'),
('bf964b14-5208-11df-952d-000ae4cc0097', 'phone', 1, '2010-04-27 16:25:14', '2010-04-27 16:25:14'),
('bf964d44-5208-11df-952d-000ae4cc0097', 'sms / mms', 1, '2010-04-27 16:25:14', '2010-04-27 16:25:14'),
('f8269650-5208-11df-952d-000ae4cc0097', 'mail', 1, '2010-04-27 16:25:14', '2010-04-27 16:25:14');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `country_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`),
  KEY `state_id` (`state_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `country_id`, `state_id`, `name`, `created`, `modified`) VALUES
('533efa6c-59d6-11df-9ccf-000ae4cc0097', 'c5cf7076-5110-11df-9f9e-000ae4cc0097', '728fb3a2-59d6-11df-9ccf-000ae4cc0097', 'amsterdam', '2010-05-07 00:00:00', '2010-05-07 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `foreign_key` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `lft` int(11) NOT NULL,
  `rght` int(11) NOT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `author_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author_email` varchar(320) COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `is_spam` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `comment_type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `code`) VALUES
('c2498a22-5110-11df-9f9e-000ae4cc0097', 'afghanistan', 'af'),
('c25526ac-5110-11df-9f9e-000ae4cc0097', 'åland islands', 'ax'),
('c25a387c-5110-11df-9f9e-000ae4cc0097', 'albania', 'al'),
('c25f5938-5110-11df-9f9e-000ae4cc0097', 'algeria', 'dz'),
('c26476fc-5110-11df-9f9e-000ae4cc0097', 'american samoa', 'as'),
('c2699204-5110-11df-9f9e-000ae4cc0097', 'andorra', 'ad'),
('c26eb20c-5110-11df-9f9e-000ae4cc0097', 'angola', 'ao'),
('c273cda0-5110-11df-9f9e-000ae4cc0097', 'anguilla', 'ai'),
('c278ed80-5110-11df-9f9e-000ae4cc0097', 'antarctica', 'aq'),
('c27e0cf2-5110-11df-9f9e-000ae4cc0097', 'antigua and barbuda', 'ag'),
('c2832912-5110-11df-9f9e-000ae4cc0097', 'argentina', 'ar'),
('c295d530-5110-11df-9f9e-000ae4cc0097', 'armenia', 'am'),
('c2a522a6-5110-11df-9f9e-000ae4cc0097', 'aruba', 'aw'),
('c2aa3f5c-5110-11df-9f9e-000ae4cc0097', 'australia', 'au'),
('c2bcef12-5110-11df-9f9e-000ae4cc0097', 'austria', 'at'),
('c2cc3698-5110-11df-9f9e-000ae4cc0097', 'azerbaijan', 'az'),
('c2d1432c-5110-11df-9f9e-000ae4cc0097', 'bahamas', 'bs'),
('c2d672ca-5110-11df-9f9e-000ae4cc0097', 'bahrain', 'bh'),
('c2db8dc8-5110-11df-9f9e-000ae4cc0097', 'bangladesh', 'bd'),
('c2e0ec96-5110-11df-9f9e-000ae4cc0097', 'barbados', 'bb'),
('c2e60a28-5110-11df-9f9e-000ae4cc0097', 'belarus', 'by'),
('c2eb2774-5110-11df-9f9e-000ae4cc0097', 'belgium', 'be'),
('c2f04556-5110-11df-9f9e-000ae4cc0097', 'belize', 'bz'),
('c2f5672a-5110-11df-9f9e-000ae4cc0097', 'benin', 'bj'),
('c2fa837c-5110-11df-9f9e-000ae4cc0097', 'bermuda', 'bm'),
('c3014f7c-5110-11df-9f9e-000ae4cc0097', 'bhutan', 'bt'),
('c3066e1c-5110-11df-9f9e-000ae4cc0097', 'bolivia', 'bo'),
('c30d3dbe-5110-11df-9f9e-000ae4cc0097', 'bosnia and herzegovina', 'ba'),
('c31411ca-5110-11df-9f9e-000ae4cc0097', 'botswana', 'bw'),
('c31ae82e-5110-11df-9f9e-000ae4cc0097', 'bouvet island', 'bv'),
('c3219e6c-5110-11df-9f9e-000ae4cc0097', 'brazil', 'br'),
('c3287d2c-5110-11df-9f9e-000ae4cc0097', 'british indian ocean territory', 'io'),
('c32f4e0e-5110-11df-9f9e-000ae4cc0097', 'brunei', 'bn'),
('c3362300-5110-11df-9f9e-000ae4cc0097', 'bulgaria', 'bg'),
('c33cdab0-5110-11df-9f9e-000ae4cc0097', 'burkina faso', 'bf'),
('c343c4ce-5110-11df-9f9e-000ae4cc0097', 'burundi', 'bi'),
('c34a94b6-5110-11df-9f9e-000ae4cc0097', 'cambodia', 'kh'),
('c34fad98-5110-11df-9f9e-000ae4cc0097', 'cameroon', 'cm'),
('c354cc06-5110-11df-9f9e-000ae4cc0097', 'canada', 'ca'),
('c359edbc-5110-11df-9f9e-000ae4cc0097', 'cape verde', 'cv'),
('c35f4a46-5110-11df-9f9e-000ae4cc0097', 'cayman islands', 'ky'),
('c3642912-5110-11df-9f9e-000ae4cc0097', 'central african republic', 'cf'),
('c3694848-5110-11df-9f9e-000ae4cc0097', 'chad', 'td'),
('c36e5f5e-5110-11df-9f9e-000ae4cc0097', 'chile', 'cl'),
('c3737ff2-5110-11df-9f9e-000ae4cc0097', 'china', 'cn'),
('c378a284-5110-11df-9f9e-000ae4cc0097', 'christmas island', 'cx'),
('c37e02ec-5110-11df-9f9e-000ae4cc0097', 'cocos (keeling) islands', 'cc'),
('c382d894-5110-11df-9f9e-000ae4cc0097', 'colombia', 'co'),
('c387f478-5110-11df-9f9e-000ae4cc0097', 'comoros', 'km'),
('c38d13ae-5110-11df-9f9e-000ae4cc0097', 'congo, the republic of', 'cg'),
('c3923186-5110-11df-9f9e-000ae4cc0097', 'congo, the democratic republic of', 'cd'),
('c3975332-5110-11df-9f9e-000ae4cc0097', 'cook islands', 'ck'),
('c39c6ca0-5110-11df-9f9e-000ae4cc0097', 'costa rica', 'cr'),
('c3a1882a-5110-11df-9f9e-000ae4cc0097', 'côte d’ivoire', 'ci'),
('c3a6b106-5110-11df-9f9e-000ae4cc0097', 'croatia', 'hr'),
('c3abc812-5110-11df-9f9e-000ae4cc0097', 'cuba', 'cu'),
('c3b0e3e2-5110-11df-9f9e-000ae4cc0097', 'cyprus', 'cy'),
('c3b60354-5110-11df-9f9e-000ae4cc0097', 'czech republic', 'cz'),
('c3bb205a-5110-11df-9f9e-000ae4cc0097', 'denmark', 'dk'),
('c3c03f68-5110-11df-9f9e-000ae4cc0097', 'djibouti', 'dj'),
('c3c55b10-5110-11df-9f9e-000ae4cc0097', 'dominica', 'dm'),
('c3ca8f5e-5110-11df-9f9e-000ae4cc0097', 'dominican republic', 'do'),
('c3cf981e-5110-11df-9f9e-000ae4cc0097', 'ecuador', 'ec'),
('c3d4b66e-5110-11df-9f9e-000ae4cc0097', 'egypt', 'eg'),
('c3d9d5c2-5110-11df-9f9e-000ae4cc0097', 'el salvador', 'sv'),
('c3defb24-5110-11df-9f9e-000ae4cc0097', 'equatorial guinea', 'gq'),
('c3e40f56-5110-11df-9f9e-000ae4cc0097', 'eritrea', 'er'),
('c3e92d1a-5110-11df-9f9e-000ae4cc0097', 'estonia', 'ee'),
('c3ee4af2-5110-11df-9f9e-000ae4cc0097', 'ethiopia', 'et'),
('c3f36c58-5110-11df-9f9e-000ae4cc0097', 'falkland islands', 'fk'),
('c3f88968-5110-11df-9f9e-000ae4cc0097', 'faroe islands', 'fo'),
('c3fda45c-5110-11df-9f9e-000ae4cc0097', 'fiji', 'fj'),
('c402c7e8-5110-11df-9f9e-000ae4cc0097', 'finland', 'fi'),
('c407e14c-5110-11df-9f9e-000ae4cc0097', 'france', 'fr'),
('c40cfccc-5110-11df-9f9e-000ae4cc0097', 'french guyana', 'gf'),
('c41247e0-5110-11df-9f9e-000ae4cc0097', 'french polynesia', 'pf'),
('c4177896-5110-11df-9f9e-000ae4cc0097', 'french southern territories', 'tf'),
('c41e49f0-5110-11df-9f9e-000ae4cc0097', 'gabon', 'ga'),
('c4251816-5110-11df-9f9e-000ae4cc0097', 'gambia', 'gm'),
('c42bd57a-5110-11df-9f9e-000ae4cc0097', 'georgia', 'ge'),
('c432b868-5110-11df-9f9e-000ae4cc0097', 'germany', 'de'),
('c43973ec-5110-11df-9f9e-000ae4cc0097', 'ghana', 'gh'),
('c4407caa-5110-11df-9f9e-000ae4cc0097', 'gibraltar', 'gi'),
('c4472884-5110-11df-9f9e-000ae4cc0097', 'greece', 'gr'),
('c44df8f8-5110-11df-9f9e-000ae4cc0097', 'greenland', 'gl'),
('c454b472-5110-11df-9f9e-000ae4cc0097', 'grenada', 'gd'),
('c45b9bc0-5110-11df-9f9e-000ae4cc0097', 'guadeloupe', 'gp'),
('c460a2aa-5110-11df-9f9e-000ae4cc0097', 'guam', 'gu'),
('c465d342-5110-11df-9f9e-000ae4cc0097', 'guatemala', 'gt'),
('c46af368-5110-11df-9f9e-000ae4cc0097', 'guernsey', 'gg'),
('c4700e0c-5110-11df-9f9e-000ae4cc0097', 'guinea', 'gn'),
('c47534ea-5110-11df-9f9e-000ae4cc0097', 'guinea-bissau', 'gw'),
('c47a48d6-5110-11df-9f9e-000ae4cc0097', 'guyana', 'gy'),
('c47f6ab4-5110-11df-9f9e-000ae4cc0097', 'haiti', 'ht'),
('c4848814-5110-11df-9f9e-000ae4cc0097', 'heard island and mcdonald islands', 'hm'),
('c489a3d0-5110-11df-9f9e-000ae4cc0097', 'holy see (vatican city state)', 'va'),
('c48ec4f0-5110-11df-9f9e-000ae4cc0097', 'honduras', 'hn'),
('c493e002-5110-11df-9f9e-000ae4cc0097', 'hong kong', 'hk'),
('c498fe16-5110-11df-9f9e-000ae4cc0097', 'hungary', 'hu'),
('c49e096a-5110-11df-9f9e-000ae4cc0097', 'iceland', 'is'),
('c4a3254e-5110-11df-9f9e-000ae4cc0097', 'india', 'in'),
('c4a8588e-5110-11df-9f9e-000ae4cc0097', 'indonesia', 'id'),
('c4ad74e0-5110-11df-9f9e-000ae4cc0097', 'iran', 'ir'),
('c4b2956a-5110-11df-9f9e-000ae4cc0097', 'iraq', 'iq'),
('c4b7b144-5110-11df-9f9e-000ae4cc0097', 'ireland', 'ie'),
('c4bcd5e8-5110-11df-9f9e-000ae4cc0097', 'isle of man', 'im'),
('c4c1ed1c-5110-11df-9f9e-000ae4cc0097', 'israel', 'il'),
('c4c70cde-5110-11df-9f9e-000ae4cc0097', 'italy', 'it'),
('c4cc2e30-5110-11df-9f9e-000ae4cc0097', 'jamaica', 'jm'),
('c4d1473a-5110-11df-9f9e-000ae4cc0097', 'japan', 'jp'),
('c4d66350-5110-11df-9f9e-000ae4cc0097', 'jersey', 'je'),
('c4db712e-5110-11df-9f9e-000ae4cc0097', 'jordan', 'jo'),
('c4e0a2ca-5110-11df-9f9e-000ae4cc0097', 'kazakhstan', 'kz'),
('c4e5c138-5110-11df-9f9e-000ae4cc0097', 'kenya', 'ke'),
('c4eadccc-5110-11df-9f9e-000ae4cc0097', 'kiribati', 'ki'),
('c4effb58-5110-11df-9f9e-000ae4cc0097', 'korea, democratic people''s republic of', 'kp'),
('c4f519da-5110-11df-9f9e-000ae4cc0097', 'korea, republic of', 'kr'),
('c4fa3848-5110-11df-9f9e-000ae4cc0097', 'kuwait', 'kw'),
('c4ff54b8-5110-11df-9f9e-000ae4cc0097', 'kyrgyzstan', 'kg'),
('c5047682-5110-11df-9f9e-000ae4cc0097', 'laos', 'la'),
('c50990b8-5110-11df-9f9e-000ae4cc0097', 'latvia', 'lv'),
('c50eb12e-5110-11df-9f9e-000ae4cc0097', 'lebanon', 'lb'),
('c513b822-5110-11df-9f9e-000ae4cc0097', 'lesotho', 'ls'),
('c518d302-5110-11df-9f9e-000ae4cc0097', 'liberia', 'lr'),
('c51df602-5110-11df-9f9e-000ae4cc0097', 'libya', 'ly'),
('c5326650-5110-11df-9f9e-000ae4cc0097', 'liechtenstein', 'li'),
('c5393a98-5110-11df-9f9e-000ae4cc0097', 'lithuania', 'lt'),
('c53e532a-5110-11df-9f9e-000ae4cc0097', 'luxembourg', 'lu'),
('c54361ee-5110-11df-9f9e-000ae4cc0097', 'macau', 'mo'),
('c54891f0-5110-11df-9f9e-000ae4cc0097', 'macedonia', 'mk'),
('c54f648a-5110-11df-9f9e-000ae4cc0097', 'madagascar', 'mg'),
('c554bc64-5110-11df-9f9e-000ae4cc0097', 'malawi', 'mw'),
('c55bb000-5110-11df-9f9e-000ae4cc0097', 'malaysia', 'my'),
('c5625c70-5110-11df-9f9e-000ae4cc0097', 'maldives', 'mv'),
('c5691b5a-5110-11df-9f9e-000ae4cc0097', 'mali', 'ml'),
('c56e4abc-5110-11df-9f9e-000ae4cc0097', 'malta', 'mt'),
('c57367a4-5110-11df-9f9e-000ae4cc0097', 'marshall islands', 'mh'),
('c578873e-5110-11df-9f9e-000ae4cc0097', 'martinique', 'mq'),
('c57da2c8-5110-11df-9f9e-000ae4cc0097', 'mauritania', 'mr'),
('c582c406-5110-11df-9f9e-000ae4cc0097', 'mauritius', 'mu'),
('c587e224-5110-11df-9f9e-000ae4cc0097', 'mayotte', 'yt'),
('c58cff20-5110-11df-9f9e-000ae4cc0097', 'mexico', 'mx'),
('c5921da2-5110-11df-9f9e-000ae4cc0097', 'micronesia', 'fm'),
('c5973fb2-5110-11df-9f9e-000ae4cc0097', 'moldova', 'md'),
('c59c4408-5110-11df-9f9e-000ae4cc0097', 'monaco', 'mc'),
('c5a1778e-5110-11df-9f9e-000ae4cc0097', 'mongolia', 'mn'),
('c5a69890-5110-11df-9f9e-000ae4cc0097', 'montenegro', 'me'),
('c5abb262-5110-11df-9f9e-000ae4cc0097', 'montserrat', 'ms'),
('c5b0ccfc-5110-11df-9f9e-000ae4cc0097', 'morocco', 'ma'),
('c5b5ed2c-5110-11df-9f9e-000ae4cc0097', 'mozambique', 'mz'),
('c5bb4632-5110-11df-9f9e-000ae4cc0097', 'myanmar', 'mm'),
('c5c03016-5110-11df-9f9e-000ae4cc0097', 'namibia', 'na'),
('c5c5312e-5110-11df-9f9e-000ae4cc0097', 'nauru', 'nr'),
('c5ca508c-5110-11df-9f9e-000ae4cc0097', 'nepal', 'np'),
('c5cf7076-5110-11df-9f9e-000ae4cc0097', 'netherlands', 'nl'),
('c5d4a208-5110-11df-9f9e-000ae4cc0097', 'netherlands antilles', 'an'),
('c5d9bcf2-5110-11df-9f9e-000ae4cc0097', 'new caledonia', 'nc'),
('c5deda66-5110-11df-9f9e-000ae4cc0097', 'new zealand', 'nz'),
('c5e3fa82-5110-11df-9f9e-000ae4cc0097', 'nicaragua', 'ni'),
('c5e90590-5110-11df-9f9e-000ae4cc0097', 'niger', 'ne'),
('c5ee35ba-5110-11df-9f9e-000ae4cc0097', 'nigeria', 'ng'),
('c5f35388-5110-11df-9f9e-000ae4cc0097', 'niue', 'nu'),
('c5f86f12-5110-11df-9f9e-000ae4cc0097', 'norfolk island', 'nf'),
('c5fd978a-5110-11df-9f9e-000ae4cc0097', 'northern mariana islands', 'mp'),
('c602afae-5110-11df-9f9e-000ae4cc0097', 'norway', 'no'),
('c607c994-5110-11df-9f9e-000ae4cc0097', 'oman', 'om'),
('c60d0cc4-5110-11df-9f9e-000ae4cc0097', 'pakistan', 'pk'),
('c611f324-5110-11df-9f9e-000ae4cc0097', 'palau', 'pw'),
('c61729c0-5110-11df-9f9e-000ae4cc0097', 'palestine', 'ps'),
('c61c4158-5110-11df-9f9e-000ae4cc0097', 'panama', 'pa'),
('c6216232-5110-11df-9f9e-000ae4cc0097', 'papua new guinea', 'pg'),
('c626808c-5110-11df-9f9e-000ae4cc0097', 'paraguay', 'py'),
('c62b9a4a-5110-11df-9f9e-000ae4cc0097', 'peru', 'pe'),
('c630bc5a-5110-11df-9f9e-000ae4cc0097', 'philippines', 'ph'),
('c635d672-5110-11df-9f9e-000ae4cc0097', 'pitcairn', 'pn'),
('c63afc24-5110-11df-9f9e-000ae4cc0097', 'poland', 'pl'),
('c6401538-5110-11df-9f9e-000ae4cc0097', 'portugal', 'pt'),
('c645343c-5110-11df-9f9e-000ae4cc0097', 'puerto rico', 'pr'),
('c64a4fb2-5110-11df-9f9e-000ae4cc0097', 'qatar', 'qa'),
('c6511ffe-5110-11df-9f9e-000ae4cc0097', 'réunion', 're'),
('c6563de0-5110-11df-9f9e-000ae4cc0097', 'romania', 'ro'),
('c65d0dfa-5110-11df-9f9e-000ae4cc0097', 'russia', 'ru'),
('c663e3c8-5110-11df-9f9e-000ae4cc0097', 'rwanda', 'rw'),
('c66aaf78-5110-11df-9f9e-000ae4cc0097', 'saint barthélemy', 'bl'),
('c6717fba-5110-11df-9f9e-000ae4cc0097', 'saint helena', 'sh'),
('c6784c5a-5110-11df-9f9e-000ae4cc0097', 'saint kitts and nevis', 'kn'),
('c67f1d0a-5110-11df-9f9e-000ae4cc0097', 'saint lucia', 'lc'),
('c6865a98-5110-11df-9f9e-000ae4cc0097', 'saint martin', 'mf'),
('c68b7910-5110-11df-9f9e-000ae4cc0097', 'saint pierre and miquelon', 'pm'),
('c690953a-5110-11df-9f9e-000ae4cc0097', 'saint vincent and the grenadines', 'vc'),
('c695b236-5110-11df-9f9e-000ae4cc0097', 'samoa', 'ws'),
('c69ad342-5110-11df-9f9e-000ae4cc0097', 'san marino', 'sm'),
('c69fee4a-5110-11df-9f9e-000ae4cc0097', 'sao tome and principe', 'st'),
('c6a4fa5c-5110-11df-9f9e-000ae4cc0097', 'saudi arabia', 'sa'),
('c6aa2cc0-5110-11df-9f9e-000ae4cc0097', 'senegal', 'sn'),
('c6af4656-5110-11df-9f9e-000ae4cc0097', 'serbia', 'rs'),
('c6b468fc-5110-11df-9f9e-000ae4cc0097', 'seychelles', 'sc'),
('c6c5cae8-5110-11df-9f9e-000ae4cc0097', 'sierra leone', 'sl'),
('c6db94d6-5110-11df-9f9e-000ae4cc0097', 'singapore', 'sg'),
('c6e804e6-5110-11df-9f9e-000ae4cc0097', 'slovakia', 'sk'),
('c6ec9a6a-5110-11df-9f9e-000ae4cc0097', 'slovenia', 'si'),
('c6f1b608-5110-11df-9f9e-000ae4cc0097', 'solomon islands', 'sb'),
('c6f6d250-5110-11df-9f9e-000ae4cc0097', 'somalia', 'so'),
('c6fbf1d6-5110-11df-9f9e-000ae4cc0097', 'south africa', 'za'),
('c700fe24-5110-11df-9f9e-000ae4cc0097', 'south georgia and the south sandwich islands', 'gs'),
('c7062c1e-5110-11df-9f9e-000ae4cc0097', 'spain', 'es'),
('c70b537e-5110-11df-9f9e-000ae4cc0097', 'sri lanka', 'lk'),
('c7108db2-5110-11df-9f9e-000ae4cc0097', 'sudan', 'sd'),
('c7158e66-5110-11df-9f9e-000ae4cc0097', 'suriname', 'sr'),
('c71aa5c2-5110-11df-9f9e-000ae4cc0097', 'svalbard and jan mayen', 'sj'),
('c71fc7b4-5110-11df-9f9e-000ae4cc0097', 'swaziland', 'sz'),
('c724e410-5110-11df-9f9e-000ae4cc0097', 'sweden', 'se'),
('c729fe6e-5110-11df-9f9e-000ae4cc0097', 'switzerland', 'ch'),
('c72f1a2a-5110-11df-9f9e-000ae4cc0097', 'syria', 'sy'),
('c7343d16-5110-11df-9f9e-000ae4cc0097', 'taiwan', 'tw'),
('c7395ad0-5110-11df-9f9e-000ae4cc0097', 'tajikistan', 'tj'),
('c7402b30-5110-11df-9f9e-000ae4cc0097', 'tanzania', 'tz'),
('c7454782-5110-11df-9f9e-000ae4cc0097', 'thailand', 'th'),
('c74a8076-5110-11df-9f9e-000ae4cc0097', 'east timor', 'tl'),
('c751357e-5110-11df-9f9e-000ae4cc0097', 'togo', 'tg'),
('c756417c-5110-11df-9f9e-000ae4cc0097', 'tokelau', 'tk'),
('c75b7692-5110-11df-9f9e-000ae4cc0097', 'tonga', 'to'),
('c762459e-5110-11df-9f9e-000ae4cc0097', 'trinidad and tobago', 'tt'),
('c769120c-5110-11df-9f9e-000ae4cc0097', 'tunisia', 'tn'),
('c76fe2bc-5110-11df-9f9e-000ae4cc0097', 'turkey', 'tr'),
('c776b29a-5110-11df-9f9e-000ae4cc0097', 'turkmenistan', 'tm'),
('c77dbc2a-5110-11df-9f9e-000ae4cc0097', 'turks and caicos islands', 'tc'),
('c78455c6-5110-11df-9f9e-000ae4cc0097', 'tuvalu', 'tv'),
('c78b1f1e-5110-11df-9f9e-000ae4cc0097', 'uganda', 'ug'),
('c791f366-5110-11df-9f9e-000ae4cc0097', 'ukraine', 'ua'),
('c798bcd2-5110-11df-9f9e-000ae4cc0097', 'united arab emirates', 'ae'),
('c79f921e-5110-11df-9f9e-000ae4cc0097', 'united kingdom', 'gb'),
('c7a661ac-5110-11df-9f9e-000ae4cc0097', 'united states', 'us'),
('c7ad3176-5110-11df-9f9e-000ae4cc0097', 'united states minor outlying, islands', 'um'),
('c7b250c0-5110-11df-9f9e-000ae4cc0097', 'uruguay', 'uy'),
('c7b773e8-5110-11df-9f9e-000ae4cc0097', 'uzbekistan', 'uz'),
('c7bc8aae-5110-11df-9f9e-000ae4cc0097', 'vanuatu', 'vu'),
('c7c1a872-5110-11df-9f9e-000ae4cc0097', 'vatican city', 'se'),
('c7c6caf0-5110-11df-9f9e-000ae4cc0097', 'venezuela', 've'),
('c7cc2342-5110-11df-9f9e-000ae4cc0097', 'vietnam', 'vn'),
('c7d13daa-5110-11df-9f9e-000ae4cc0097', 'virgin islands, british', 'vg'),
('c7d64bba-5110-11df-9f9e-000ae4cc0097', 'virgin islands, u.s.', 'vi'),
('c7db7a36-5110-11df-9f9e-000ae4cc0097', 'wallis and futuna', 'wf'),
('c7e0984a-5110-11df-9f9e-000ae4cc0097', 'western sahara', 'eh'),
('c7e5b9a6-5110-11df-9f9e-000ae4cc0097', 'yemen', 'ye'),
('c7ead3f0-5110-11df-9f9e-000ae4cc0097', 'zambia', 'zm'),
('c7efddaa-5110-11df-9f9e-000ae4cc0097', 'zimbabwe', 'sw'),
('fe30d45a-5917-11df-bae3-000ae4cc0097', 'ascension island', 'sh'),
('fe30d7d4-5917-11df-bae3-000ae4cc0097', 'tristan da cunha', 'sh');

-- --------------------------------------------------------

--
-- Table structure for table `countries_currencies`
--

CREATE TABLE IF NOT EXISTS `countries_currencies` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `country_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `currency_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `countries_currencies`
--

INSERT INTO `countries_currencies` (`id`, `country_id`, `currency_id`, `created`, `modified`) VALUES
('90763b6c-591c-11df-bae3-000ae4cc0097', 'c2498a22-5110-11df-9f9e-000ae4cc0097', '79a8f00c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90763db0-591c-11df-bae3-000ae4cc0097', 'c25a387c-5110-11df-9f9e-000ae4cc0097', '79a8f20a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90763e3c-591c-11df-bae3-000ae4cc0097', 'c25f5938-5110-11df-9f9e-000ae4cc0097', '79a8f34a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90763ebe-591c-11df-bae3-000ae4cc0097', 'c2699204-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90763f22-591c-11df-bae3-000ae4cc0097', 'c26eb20c-5110-11df-9f9e-000ae4cc0097', '79a8f3cc-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90763f9a-591c-11df-bae3-000ae4cc0097', 'c273cda0-5110-11df-9f9e-000ae4cc0097', '79a910be-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90763ffe-591c-11df-bae3-000ae4cc0097', 'c27e0cf2-5110-11df-9f9e-000ae4cc0097', '79a910be-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764058-591c-11df-bae3-000ae4cc0097', 'c2832912-5110-11df-9f9e-000ae4cc0097', '79a8f44e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907640bc-591c-11df-bae3-000ae4cc0097', 'c295d530-5110-11df-9f9e-000ae4cc0097', '79a8f4c6-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764120-591c-11df-bae3-000ae4cc0097', 'c2a522a6-5110-11df-9f9e-000ae4cc0097', '79a8f53e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076417a-591c-11df-bae3-000ae4cc0097', 'c2aa3f5c-5110-11df-9f9e-000ae4cc0097', '79a8f638-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907641de-591c-11df-bae3-000ae4cc0097', 'c2bcef12-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764238-591c-11df-bae3-000ae4cc0097', 'c2cc3698-5110-11df-9f9e-000ae4cc0097', '79a8f6a6-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076429c-591c-11df-bae3-000ae4cc0097', 'c2d1432c-5110-11df-9f9e-000ae4cc0097', '79a8f71e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764300-591c-11df-bae3-000ae4cc0097', 'c2d672ca-5110-11df-9f9e-000ae4cc0097', '79a8f78c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764364-591c-11df-bae3-000ae4cc0097', 'c2db8dc8-5110-11df-9f9e-000ae4cc0097', '79a8f804-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907643c8-591c-11df-bae3-000ae4cc0097', 'c2e0ec96-5110-11df-9f9e-000ae4cc0097', '79a8f872-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764422-591c-11df-bae3-000ae4cc0097', 'c2e60a28-5110-11df-9f9e-000ae4cc0097', '79a8f8ea-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076447c-591c-11df-bae3-000ae4cc0097', 'c2eb2774-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907647d8-591c-11df-bae3-000ae4cc0097', 'c2f04556-5110-11df-9f9e-000ae4cc0097', '79a8f962-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076488c-591c-11df-bae3-000ae4cc0097', 'c2f5672a-5110-11df-9f9e-000ae4cc0097', '79a9db70-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907648f0-591c-11df-bae3-000ae4cc0097', 'c2fa837c-5110-11df-9f9e-000ae4cc0097', '79a8f9d0-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764954-591c-11df-bae3-000ae4cc0097', 'c3014f7c-5110-11df-9f9e-000ae4cc0097', '79a8fa3e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907649ae-591c-11df-bae3-000ae4cc0097', 'c3014f7c-5110-11df-9f9e-000ae4cc0097', '79a9222a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764a1c-591c-11df-bae3-000ae4cc0097', 'c3066e1c-5110-11df-9f9e-000ae4cc0097', '79a8fda4-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764a76-591c-11df-bae3-000ae4cc0097', 'c30d3dbe-5110-11df-9f9e-000ae4cc0097', '79a8fe26-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764ad0-591c-11df-bae3-000ae4cc0097', 'c31411ca-5110-11df-9f9e-000ae4cc0097', '79a8fe9e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764b34-591c-11df-bae3-000ae4cc0097', 'c3219e6c-5110-11df-9f9e-000ae4cc0097', '79a8ff0c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764b98-591c-11df-bae3-000ae4cc0097', 'c3287d2c-5110-11df-9f9e-000ae4cc0097', '79a9d878-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764bf2-591c-11df-bae3-000ae4cc0097', 'c32f4e0e-5110-11df-9f9e-000ae4cc0097', '79a90074-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764c56-591c-11df-bae3-000ae4cc0097', 'c32f4e0e-5110-11df-9f9e-000ae4cc0097', '79a96d02-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764cb0-591c-11df-bae3-000ae4cc0097', 'c3362300-5110-11df-9f9e-000ae4cc0097', '79a900d8-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764d14-591c-11df-bae3-000ae4cc0097', 'c33cdab0-5110-11df-9f9e-000ae4cc0097', '79a9db70-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764d6e-591c-11df-bae3-000ae4cc0097', 'c343c4ce-5110-11df-9f9e-000ae4cc0097', '79a90150-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764dd2-591c-11df-bae3-000ae4cc0097', 'c34a94b6-5110-11df-9f9e-000ae4cc0097', '79a901be-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764e2c-591c-11df-bae3-000ae4cc0097', 'c34fad98-5110-11df-9f9e-000ae4cc0097', '79a90394-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764e90-591c-11df-bae3-000ae4cc0097', 'c354cc06-5110-11df-9f9e-000ae4cc0097', '79a90236-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764ef4-591c-11df-bae3-000ae4cc0097', 'c359edbc-5110-11df-9f9e-000ae4cc0097', '79a902ae-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90764f4e-591c-11df-bae3-000ae4cc0097', 'c35f4a46-5110-11df-9f9e-000ae4cc0097', '79a9031c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765570-591c-11df-bae3-000ae4cc0097', 'c3642912-5110-11df-9f9e-000ae4cc0097', '79a90394-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907655e8-591c-11df-bae3-000ae4cc0097', 'c3694848-5110-11df-9f9e-000ae4cc0097', '79a90394-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765656-591c-11df-bae3-000ae4cc0097', 'c36e5f5e-5110-11df-9f9e-000ae4cc0097', '79a9047a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907656b0-591c-11df-bae3-000ae4cc0097', 'c3737ff2-5110-11df-9f9e-000ae4cc0097', '79a904f2-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076571e-591c-11df-bae3-000ae4cc0097', 'c37e02ec-5110-11df-9f9e-000ae4cc0097', '79a8f638-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765782-591c-11df-bae3-000ae4cc0097', 'c37e02ec-5110-11df-9f9e-000ae4cc0097', '79a90560-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907657e6-591c-11df-bae3-000ae4cc0097', 'c382d894-5110-11df-9f9e-000ae4cc0097', '79a905d8-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765840-591c-11df-bae3-000ae4cc0097', 'c7d13daa-5110-11df-9f9e-000ae4cc0097', '79a8fff2-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907658a4-591c-11df-bae3-000ae4cc0097', 'c7d13daa-5110-11df-9f9e-000ae4cc0097', '79a9d800-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907658fe-591c-11df-bae3-000ae4cc0097', 'fe30d45a-5917-11df-bae3-000ae4cc0097', '79a8f5b6-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076596c-591c-11df-bae3-000ae4cc0097', 'fe30d45a-5917-11df-bae3-000ae4cc0097', '79a9694c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907659c6-591c-11df-bae3-000ae4cc0097', 'c387f478-5110-11df-9f9e-000ae4cc0097', '79a90650-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765a2a-591c-11df-bae3-000ae4cc0097', 'c38d13ae-5110-11df-9f9e-000ae4cc0097', '79a90394-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765a8e-591c-11df-bae3-000ae4cc0097', 'c3923186-5110-11df-9f9e-000ae4cc0097', '79a90c36-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765ae8-591c-11df-bae3-000ae4cc0097', 'c3975332-5110-11df-9f9e-000ae4cc0097', '79a94e4e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765b4c-591c-11df-bae3-000ae4cc0097', 'c3975332-5110-11df-9f9e-000ae4cc0097', '79a90cae-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765ba6-591c-11df-bae3-000ae4cc0097', 'c39c6ca0-5110-11df-9f9e-000ae4cc0097', '79a90d30-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765c0a-591c-11df-bae3-000ae4cc0097', 'c3a1882a-5110-11df-9f9e-000ae4cc0097', '79a9db70-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765c6e-591c-11df-bae3-000ae4cc0097', 'c3a6b106-5110-11df-9f9e-000ae4cc0097', '79a90d9e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765cd2-591c-11df-bae3-000ae4cc0097', 'c3abc812-5110-11df-9f9e-000ae4cc0097', '79a90e0c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90765d36-591c-11df-bae3-000ae4cc0097', 'c3abc812-5110-11df-9f9e-000ae4cc0097', '79a90e84-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766524-591c-11df-bae3-000ae4cc0097', 'c3b0e3e2-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766588-591c-11df-bae3-000ae4cc0097', 'c3b60354-5110-11df-9f9e-000ae4cc0097', '79a90efc-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907665ec-591c-11df-bae3-000ae4cc0097', 'c3bb205a-5110-11df-9f9e-000ae4cc0097', '79a90f6a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766650-591c-11df-bae3-000ae4cc0097', 'c3c03f68-5110-11df-9f9e-000ae4cc0097', '79a90fd8-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907666b4-591c-11df-bae3-000ae4cc0097', 'c3c55b10-5110-11df-9f9e-000ae4cc0097', '79a910be-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076670e-591c-11df-bae3-000ae4cc0097', 'c3ca8f5e-5110-11df-9f9e-000ae4cc0097', '79a91050-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766772-591c-11df-bae3-000ae4cc0097', 'c3cf981e-5110-11df-9f9e-000ae4cc0097', '79a9d800-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907667cc-591c-11df-bae3-000ae4cc0097', 'c3d4b66e-5110-11df-9f9e-000ae4cc0097', '79a9112c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766830-591c-11df-bae3-000ae4cc0097', 'c3d9d5c2-5110-11df-9f9e-000ae4cc0097', '79a969c4-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766894-591c-11df-bae3-000ae4cc0097', 'c3d9d5c2-5110-11df-9f9e-000ae4cc0097', '79a9d800-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907668ee-591c-11df-bae3-000ae4cc0097', 'c3defb24-5110-11df-9f9e-000ae4cc0097', '79a90394-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076695c-591c-11df-bae3-000ae4cc0097', 'c3e40f56-5110-11df-9f9e-000ae4cc0097', '79a9119a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907669c0-591c-11df-bae3-000ae4cc0097', 'c3e92d1a-5110-11df-9f9e-000ae4cc0097', '79a91212-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766a24-591c-11df-bae3-000ae4cc0097', 'c3ee4af2-5110-11df-9f9e-000ae4cc0097', '79a91280-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766a7e-591c-11df-bae3-000ae4cc0097', 'c3f36c58-5110-11df-9f9e-000ae4cc0097', '79a9135c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766ae2-591c-11df-bae3-000ae4cc0097', 'c3f88968-5110-11df-9f9e-000ae4cc0097', '79a90f6a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766b3c-591c-11df-bae3-000ae4cc0097', 'c3f88968-5110-11df-9f9e-000ae4cc0097', '79a913d4-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766b96-591c-11df-bae3-000ae4cc0097', 'c3fda45c-5110-11df-9f9e-000ae4cc0097', '79a9144c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766bfa-591c-11df-bae3-000ae4cc0097', 'c402c7e8-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766c54-591c-11df-bae3-000ae4cc0097', 'c407e14c-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766cb8-591c-11df-bae3-000ae4cc0097', 'c41247e0-5110-11df-9f9e-000ae4cc0097', '79a9040c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766d12-591c-11df-bae3-000ae4cc0097', 'c41e49f0-5110-11df-9f9e-000ae4cc0097', '79a90394-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90766da8-591c-11df-bae3-000ae4cc0097', 'c4251816-5110-11df-9f9e-000ae4cc0097', '79a914ba-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767758-591c-11df-bae3-000ae4cc0097', 'c42bd57a-5110-11df-9f9e-000ae4cc0097', '79a91532-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907677bc-591c-11df-bae3-000ae4cc0097', 'c432b868-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767816-591c-11df-bae3-000ae4cc0097', 'c43973ec-5110-11df-9f9e-000ae4cc0097', '79a91da2-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767870-591c-11df-bae3-000ae4cc0097', 'c4407caa-5110-11df-9f9e-000ae4cc0097', '79a91e10-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907678c0-591c-11df-bae3-000ae4cc0097', 'c4472884-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076791a-591c-11df-bae3-000ae4cc0097', 'c454b472-5110-11df-9f9e-000ae4cc0097', '79a910be-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767974-591c-11df-bae3-000ae4cc0097', 'c465d342-5110-11df-9f9e-000ae4cc0097', '79a91e74-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907679c4-591c-11df-bae3-000ae4cc0097', 'c46af368-5110-11df-9f9e-000ae4cc0097', '79a8ff7a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767a1e-591c-11df-bae3-000ae4cc0097', 'c46af368-5110-11df-9f9e-000ae4cc0097', '79a91ee2-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767a78-591c-11df-bae3-000ae4cc0097', 'c4700e0c-5110-11df-9f9e-000ae4cc0097', '79a91f5a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767ad2-591c-11df-bae3-000ae4cc0097', 'c47534ea-5110-11df-9f9e-000ae4cc0097', '79a9db70-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767b2c-591c-11df-bae3-000ae4cc0097', 'c47a48d6-5110-11df-9f9e-000ae4cc0097', '79a91fbe-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767b7c-591c-11df-bae3-000ae4cc0097', 'c47f6ab4-5110-11df-9f9e-000ae4cc0097', '79a92022-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767bd6-591c-11df-bae3-000ae4cc0097', 'c48ec4f0-5110-11df-9f9e-000ae4cc0097', '79a92090-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767c30-591c-11df-bae3-000ae4cc0097', 'c493e002-5110-11df-9f9e-000ae4cc0097', '79a920f4-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767c8a-591c-11df-bae3-000ae4cc0097', 'c498fe16-5110-11df-9f9e-000ae4cc0097', '79a92158-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767ce4-591c-11df-bae3-000ae4cc0097', 'c49e096a-5110-11df-9f9e-000ae4cc0097', '79a921c6-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767d3e-591c-11df-bae3-000ae4cc0097', 'c4a3254e-5110-11df-9f9e-000ae4cc0097', '79a9222a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767d98-591c-11df-bae3-000ae4cc0097', 'c4a8588e-5110-11df-9f9e-000ae4cc0097', '79a92298-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767df2-591c-11df-bae3-000ae4cc0097', 'c74a8076-5110-11df-9f9e-000ae4cc0097', '79a9d800-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767e42-591c-11df-bae3-000ae4cc0097', 'c4ad74e0-5110-11df-9f9e-000ae4cc0097', '79a922fc-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90767e9c-591c-11df-bae3-000ae4cc0097', 'c4b2956a-5110-11df-9f9e-000ae4cc0097', '79a9236a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076863a-591c-11df-bae3-000ae4cc0097', 'c4b7b144-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907686d0-591c-11df-bae3-000ae4cc0097', 'c4bcd5e8-5110-11df-9f9e-000ae4cc0097', '79a8ff7a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90768d6a-591c-11df-bae3-000ae4cc0097', 'c4bcd5e8-5110-11df-9f9e-000ae4cc0097', '79a93a30-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90768dec-591c-11df-bae3-000ae4cc0097', 'c4c1ed1c-5110-11df-9f9e-000ae4cc0097', '79a923ce-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90768e64-591c-11df-bae3-000ae4cc0097', 'c4c70cde-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90768ec8-591c-11df-bae3-000ae4cc0097', 'c4cc2e30-5110-11df-9f9e-000ae4cc0097', '79a92432-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90768f22-591c-11df-bae3-000ae4cc0097', 'c4d1473a-5110-11df-9f9e-000ae4cc0097', '79a92496-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90768f86-591c-11df-bae3-000ae4cc0097', 'c4d66350-5110-11df-9f9e-000ae4cc0097', '79a8ff7a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90768fe0-591c-11df-bae3-000ae4cc0097', 'c4d66350-5110-11df-9f9e-000ae4cc0097', '79a92504-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769044-591c-11df-bae3-000ae4cc0097', 'c4db712e-5110-11df-9f9e-000ae4cc0097', '79a92572-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076909e-591c-11df-bae3-000ae4cc0097', 'c4e0a2ca-5110-11df-9f9e-000ae4cc0097', '79a92702-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769102-591c-11df-bae3-000ae4cc0097', 'c4e5c138-5110-11df-9f9e-000ae4cc0097', '79a9277a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076915c-591c-11df-bae3-000ae4cc0097', 'c4eadccc-5110-11df-9f9e-000ae4cc0097', '79a8f638-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907691c0-591c-11df-bae3-000ae4cc0097', 'c4eadccc-5110-11df-9f9e-000ae4cc0097', '79a932f6-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076921a-591c-11df-bae3-000ae4cc0097', 'c4effb58-5110-11df-9f9e-000ae4cc0097', '79a9502e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076927e-591c-11df-bae3-000ae4cc0097', 'c4f519da-5110-11df-9f9e-000ae4cc0097', '79a9c1ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907692d8-591c-11df-bae3-000ae4cc0097', 'c4fa3848-5110-11df-9f9e-000ae4cc0097', '79a93378-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076933c-591c-11df-bae3-000ae4cc0097', 'c4ff54b8-5110-11df-9f9e-000ae4cc0097', '79a933e6-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769396-591c-11df-bae3-000ae4cc0097', 'c5047682-5110-11df-9f9e-000ae4cc0097', '79a9345e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907693fa-591c-11df-bae3-000ae4cc0097', 'c50990b8-5110-11df-9f9e-000ae4cc0097', '79a934d6-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769454-591c-11df-bae3-000ae4cc0097', 'c50eb12e-5110-11df-9f9e-000ae4cc0097', '79a93544-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907694b8-591c-11df-bae3-000ae4cc0097', 'c513b822-5110-11df-9f9e-000ae4cc0097', '79a935bc-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769512-591c-11df-bae3-000ae4cc0097', 'c513b822-5110-11df-9f9e-000ae4cc0097', '79a9c004-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769576-591c-11df-bae3-000ae4cc0097', 'c518d302-5110-11df-9f9e-000ae4cc0097', '79a9362a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907695d0-591c-11df-bae3-000ae4cc0097', 'c51df602-5110-11df-9f9e-000ae4cc0097', '79a936a2-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769634-591c-11df-bae3-000ae4cc0097', 'c5326650-5110-11df-9f9e-000ae4cc0097', '79a9c6a8-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076968e-591c-11df-bae3-000ae4cc0097', 'c5393a98-5110-11df-9f9e-000ae4cc0097', '79a93710-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('907696f2-591c-11df-bae3-000ae4cc0097', 'c53e532a-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769d6e-591c-11df-bae3-000ae4cc0097', 'c54361ee-5110-11df-9f9e-000ae4cc0097', '79a9377e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769dd2-591c-11df-bae3-000ae4cc0097', 'c54891f0-5110-11df-9f9e-000ae4cc0097', '79a937f6-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769e36-591c-11df-bae3-000ae4cc0097', 'c54f648a-5110-11df-9f9e-000ae4cc0097', '79a93864-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769e9a-591c-11df-bae3-000ae4cc0097', 'c554bc64-5110-11df-9f9e-000ae4cc0097', '79a938dc-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769efe-591c-11df-bae3-000ae4cc0097', 'c55bb000-5110-11df-9f9e-000ae4cc0097', '79a9394a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769f58-591c-11df-bae3-000ae4cc0097', 'c5625c70-5110-11df-9f9e-000ae4cc0097', '79a939c2-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('90769fbc-591c-11df-bae3-000ae4cc0097', 'c5691b5a-5110-11df-9f9e-000ae4cc0097', '79a9db70-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a016-591c-11df-bae3-000ae4cc0097', 'c56e4abc-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a07a-591c-11df-bae3-000ae4cc0097', 'c57367a4-5110-11df-9f9e-000ae4cc0097', '79a9d800-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a0d4-591c-11df-bae3-000ae4cc0097', 'c57da2c8-5110-11df-9f9e-000ae4cc0097', '79a93ab2-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a138-591c-11df-bae3-000ae4cc0097', 'c582c406-5110-11df-9f9e-000ae4cc0097', '79a93b2a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a192-591c-11df-bae3-000ae4cc0097', 'c58cff20-5110-11df-9f9e-000ae4cc0097', '79a93b98-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a1f6-591c-11df-bae3-000ae4cc0097', 'c5921da2-5110-11df-9f9e-000ae4cc0097', '79a93c10-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a250-591c-11df-bae3-000ae4cc0097', 'c5921da2-5110-11df-9f9e-000ae4cc0097', '79a9d800-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a2aa-591c-11df-bae3-000ae4cc0097', 'c5973fb2-5110-11df-9f9e-000ae4cc0097', '79a93c88-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a30e-591c-11df-bae3-000ae4cc0097', 'c59c4408-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a372-591c-11df-bae3-000ae4cc0097', 'c5a1778e-5110-11df-9f9e-000ae4cc0097', '79a93d00-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a3cc-591c-11df-bae3-000ae4cc0097', 'c5a69890-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a430-591c-11df-bae3-000ae4cc0097', 'c5abb262-5110-11df-9f9e-000ae4cc0097', '79a910be-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a48a-591c-11df-bae3-000ae4cc0097', 'c5b0ccfc-5110-11df-9f9e-000ae4cc0097', '79a93d6e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a4ee-591c-11df-bae3-000ae4cc0097', 'c5b5ed2c-5110-11df-9f9e-000ae4cc0097', '79a94b06-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a552-591c-11df-bae3-000ae4cc0097', 'c5bb4632-5110-11df-9f9e-000ae4cc0097', '79a94b88-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a5ac-591c-11df-bae3-000ae4cc0097', 'c3b0e3e2-5110-11df-9f9e-000ae4cc0097', '79a9d4fe-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a610-591c-11df-bae3-000ae4cc0097', 'c5c03016-5110-11df-9f9e-000ae4cc0097', '79a94c00-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a7b4-591c-11df-bae3-000ae4cc0097', 'c5c03016-5110-11df-9f9e-000ae4cc0097', '79a9c004-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a822-591c-11df-bae3-000ae4cc0097', 'c5c5312e-5110-11df-9f9e-000ae4cc0097', '79a8f638-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a94e-591c-11df-bae3-000ae4cc0097', 'c5c5312e-5110-11df-9f9e-000ae4cc0097', '79a94c6e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076a9bc-591c-11df-bae3-000ae4cc0097', 'c5ca508c-5110-11df-9f9e-000ae4cc0097', '79a94cf0-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076aa2a-591c-11df-bae3-000ae4cc0097', 'c5cf7076-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076aa84-591c-11df-bae3-000ae4cc0097', 'c5d4a208-5110-11df-9f9e-000ae4cc0097', '79a94d68-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076aae8-591c-11df-bae3-000ae4cc0097', 'c5d9bcf2-5110-11df-9f9e-000ae4cc0097', '79a9040c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ab4c-591c-11df-bae3-000ae4cc0097', 'c5deda66-5110-11df-9f9e-000ae4cc0097', '79a94e4e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076aba6-591c-11df-bae3-000ae4cc0097', 'c5e3fa82-5110-11df-9f9e-000ae4cc0097', '79a94ec6-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ac0a-591c-11df-bae3-000ae4cc0097', 'c5e90590-5110-11df-9f9e-000ae4cc0097', '79a9db70-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ac6e-591c-11df-bae3-000ae4cc0097', 'c5ee35ba-5110-11df-9f9e-000ae4cc0097', '79a94f3e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076acd2-591c-11df-bae3-000ae4cc0097', 'c5f35388-5110-11df-9f9e-000ae4cc0097', '79a94e4e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ad36-591c-11df-bae3-000ae4cc0097', 'c5f35388-5110-11df-9f9e-000ae4cc0097', '79a94fac-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ad90-591c-11df-bae3-000ae4cc0097', 'c5fd978a-5110-11df-9f9e-000ae4cc0097', '79a9509c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076adf4-591c-11df-bae3-000ae4cc0097', 'c5fd978a-5110-11df-9f9e-000ae4cc0097', '79a9d800-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ae62-591c-11df-bae3-000ae4cc0097', 'c602afae-5110-11df-9f9e-000ae4cc0097', '79a9511e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076aec6-591c-11df-bae3-000ae4cc0097', 'c607c994-5110-11df-9f9e-000ae4cc0097', '79a9518c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076af2a-591c-11df-bae3-000ae4cc0097', 'c60d0cc4-5110-11df-9f9e-000ae4cc0097', '79a95204-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076af84-591c-11df-bae3-000ae4cc0097', 'c611f324-5110-11df-9f9e-000ae4cc0097', '79a9527c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076afe8-591c-11df-bae3-000ae4cc0097', 'c611f324-5110-11df-9f9e-000ae4cc0097', '79a9d800-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b042-591c-11df-bae3-000ae4cc0097', 'c61729c0-5110-11df-9f9e-000ae4cc0097', '79a923ce-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b3a8-591c-11df-bae3-000ae4cc0097', 'c61729c0-5110-11df-9f9e-000ae4cc0097', '79a92572-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b416-591c-11df-bae3-000ae4cc0097', 'c61c4158-5110-11df-9f9e-000ae4cc0097', '79a952fe-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b47a-591c-11df-bae3-000ae4cc0097', 'c61c4158-5110-11df-9f9e-000ae4cc0097', '79a9d800-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b4de-591c-11df-bae3-000ae4cc0097', 'c6216232-5110-11df-9f9e-000ae4cc0097', '79a95376-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b538-591c-11df-bae3-000ae4cc0097', 'c626808c-5110-11df-9f9e-000ae4cc0097', '79a953ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b59c-591c-11df-bae3-000ae4cc0097', 'c62b9a4a-5110-11df-9f9e-000ae4cc0097', '79a95466-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b600-591c-11df-bae3-000ae4cc0097', 'c630bc5a-5110-11df-9f9e-000ae4cc0097', '79a954d4-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b664-591c-11df-bae3-000ae4cc0097', 'c63afc24-5110-11df-9f9e-000ae4cc0097', '79a9554c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b6c8-591c-11df-bae3-000ae4cc0097', 'c6401538-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b72c-591c-11df-bae3-000ae4cc0097', 'c64a4fb2-5110-11df-9f9e-000ae4cc0097', '79a955c4-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b790-591c-11df-bae3-000ae4cc0097', 'c6563de0-5110-11df-9f9e-000ae4cc0097', '79a9563c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b7ea-591c-11df-bae3-000ae4cc0097', 'c65d0dfa-5110-11df-9f9e-000ae4cc0097', '79a956aa-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b84e-591c-11df-bae3-000ae4cc0097', 'c663e3c8-5110-11df-9f9e-000ae4cc0097', '79a968ac-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b8b2-591c-11df-bae3-000ae4cc0097', 'c6717fba-5110-11df-9f9e-000ae4cc0097', '79a9694c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b90c-591c-11df-bae3-000ae4cc0097', 'c67f1d0a-5110-11df-9f9e-000ae4cc0097', '79a910be-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b970-591c-11df-bae3-000ae4cc0097', 'c690953a-5110-11df-9f9e-000ae4cc0097', '79a910be-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076b9d4-591c-11df-bae3-000ae4cc0097', 'c695b236-5110-11df-9f9e-000ae4cc0097', '79a96a3c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ba38-591c-11df-bae3-000ae4cc0097', 'c69ad342-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ba92-591c-11df-bae3-000ae4cc0097', 'c69fee4a-5110-11df-9f9e-000ae4cc0097', '79a96ab4-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076baf6-591c-11df-bae3-000ae4cc0097', 'c6a4fa5c-5110-11df-9f9e-000ae4cc0097', '79a96b2c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076bb5a-591c-11df-bae3-000ae4cc0097', 'c6aa2cc0-5110-11df-9f9e-000ae4cc0097', '79a9db70-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076bbbe-591c-11df-bae3-000ae4cc0097', 'c6af4656-5110-11df-9f9e-000ae4cc0097', '79a96ba4-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076bc22-591c-11df-bae3-000ae4cc0097', 'c6b468fc-5110-11df-9f9e-000ae4cc0097', '79a96c1c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c384-591c-11df-bae3-000ae4cc0097', 'c6c5cae8-5110-11df-9f9e-000ae4cc0097', '79a96c94-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c3e8-591c-11df-bae3-000ae4cc0097', 'c6db94d6-5110-11df-9f9e-000ae4cc0097', '79a90074-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c44c-591c-11df-bae3-000ae4cc0097', 'c6db94d6-5110-11df-9f9e-000ae4cc0097', '79a96d02-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c4a6-591c-11df-bae3-000ae4cc0097', 'c6e804e6-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c50a-591c-11df-bae3-000ae4cc0097', 'c6ec9a6a-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c56e-591c-11df-bae3-000ae4cc0097', 'c6f1b608-5110-11df-9f9e-000ae4cc0097', '79a96d7a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c5d2-591c-11df-bae3-000ae4cc0097', 'c6f6d250-5110-11df-9f9e-000ae4cc0097', '79a96df2-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c636-591c-11df-bae3-000ae4cc0097', 'c6fbf1d6-5110-11df-9f9e-000ae4cc0097', '79a9c004-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c69a-591c-11df-bae3-000ae4cc0097', 'c700fe24-5110-11df-9f9e-000ae4cc0097', '79a8ff7a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c6fe-591c-11df-bae3-000ae4cc0097', 'c700fe24-5110-11df-9f9e-000ae4cc0097', '79a9c112-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c762-591c-11df-bae3-000ae4cc0097', 'c7062c1e-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c7c6-591c-11df-bae3-000ae4cc0097', 'c70b537e-5110-11df-9f9e-000ae4cc0097', '79a9c3f6-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c82a-591c-11df-bae3-000ae4cc0097', 'c7108db2-5110-11df-9f9e-000ae4cc0097', '79a9c4a0-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c88e-591c-11df-bae3-000ae4cc0097', 'c7158e66-5110-11df-9f9e-000ae4cc0097', '79a9c522-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c8e8-591c-11df-bae3-000ae4cc0097', 'c71fc7b4-5110-11df-9f9e-000ae4cc0097', '79a9c5a4-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076c94c-591c-11df-bae3-000ae4cc0097', 'c724e410-5110-11df-9f9e-000ae4cc0097', '79a9c626-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ca00-591c-11df-bae3-000ae4cc0097', 'c729fe6e-5110-11df-9f9e-000ae4cc0097', '79a9c6a8-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ca6e-591c-11df-bae3-000ae4cc0097', 'c72f1a2a-5110-11df-9f9e-000ae4cc0097', '79a9c720-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076cad2-591c-11df-bae3-000ae4cc0097', 'c7343d16-5110-11df-9f9e-000ae4cc0097', '79a94dd6-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076cb40-591c-11df-bae3-000ae4cc0097', 'c7395ad0-5110-11df-9f9e-000ae4cc0097', '79a9c7a2-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076cbae-591c-11df-bae3-000ae4cc0097', 'c7402b30-5110-11df-9f9e-000ae4cc0097', '79a9c82e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076cc12-591c-11df-bae3-000ae4cc0097', 'c7454782-5110-11df-9f9e-000ae4cc0097', '79a9c8a6-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076cc80-591c-11df-bae3-000ae4cc0097', 'c751357e-5110-11df-9f9e-000ae4cc0097', '79a9db70-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076cce4-591c-11df-bae3-000ae4cc0097', 'c75b7692-5110-11df-9f9e-000ae4cc0097', '79a9c928-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076cd52-591c-11df-bae3-000ae4cc0097', 'c762459e-5110-11df-9f9e-000ae4cc0097', '79a9d364-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076cdb6-591c-11df-bae3-000ae4cc0097', 'c769120c-5110-11df-9f9e-000ae4cc0097', '79a9d47c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ce1a-591c-11df-bae3-000ae4cc0097', 'c76fe2bc-5110-11df-9f9e-000ae4cc0097', '79a9d4fe-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ce88-591c-11df-bae3-000ae4cc0097', 'c776b29a-5110-11df-9f9e-000ae4cc0097', '79a9d576-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ceec-591c-11df-bae3-000ae4cc0097', 'c77dbc2a-5110-11df-9f9e-000ae4cc0097', '79a9d800-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076cf50-591c-11df-bae3-000ae4cc0097', 'c78455c6-5110-11df-9f9e-000ae4cc0097', '79a8f638-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076cfb4-591c-11df-bae3-000ae4cc0097', 'c78455c6-5110-11df-9f9e-000ae4cc0097', '79a9d5f8-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076dc2a-591c-11df-bae3-000ae4cc0097', 'c78b1f1e-5110-11df-9f9e-000ae4cc0097', '79a9d684-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076dc98-591c-11df-bae3-000ae4cc0097', 'c791f366-5110-11df-9f9e-000ae4cc0097', '79a9d6fc-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076dcfc-591c-11df-bae3-000ae4cc0097', 'c798bcd2-5110-11df-9f9e-000ae4cc0097', '79a9d77e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076dd56-591c-11df-bae3-000ae4cc0097', 'c79f921e-5110-11df-9f9e-000ae4cc0097', '79a8ff7a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076ddba-591c-11df-bae3-000ae4cc0097', 'c7a661ac-5110-11df-9f9e-000ae4cc0097', '79a9d800-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076de1e-591c-11df-bae3-000ae4cc0097', 'c7b250c0-5110-11df-9f9e-000ae4cc0097', '79a9d8fa-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076de82-591c-11df-bae3-000ae4cc0097', 'c7b773e8-5110-11df-9f9e-000ae4cc0097', '79a9d972-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076dee6-591c-11df-bae3-000ae4cc0097', 'c7bc8aae-5110-11df-9f9e-000ae4cc0097', '79a9d9f4-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076df4a-591c-11df-bae3-000ae4cc0097', 'c7c1a872-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076dfae-591c-11df-bae3-000ae4cc0097', 'c7c6caf0-5110-11df-9f9e-000ae4cc0097', '79a9da6c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e012-591c-11df-bae3-000ae4cc0097', 'c7cc2342-5110-11df-9f9e-000ae4cc0097', '79a9daee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e06c-591c-11df-bae3-000ae4cc0097', 'c7db7a36-5110-11df-9f9e-000ae4cc0097', '79a9040c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e0da-591c-11df-bae3-000ae4cc0097', 'c7e0984a-5110-11df-9f9e-000ae4cc0097', '79a93d6e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e13e-591c-11df-bae3-000ae4cc0097', 'c7e5b9a6-5110-11df-9f9e-000ae4cc0097', '79a9dbe8-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e198-591c-11df-bae3-000ae4cc0097', 'c7ead3f0-5110-11df-9f9e-000ae4cc0097', '79a9dc6a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e206-591c-11df-bae3-000ae4cc0097', 'c7efddaa-5110-11df-9f9e-000ae4cc0097', '79a8fe9e-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e260-591c-11df-bae3-000ae4cc0097', 'c7efddaa-5110-11df-9f9e-000ae4cc0097', '79a8ff7a-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e2ce-591c-11df-bae3-000ae4cc0097', 'c7efddaa-5110-11df-9f9e-000ae4cc0097', '79a912ee-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e328-591c-11df-bae3-000ae4cc0097', 'c7efddaa-5110-11df-9f9e-000ae4cc0097', '79a9c004-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e38c-591c-11df-bae3-000ae4cc0097', 'c7efddaa-5110-11df-9f9e-000ae4cc0097', '79a9d800-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e3f0-591c-11df-bae3-000ae4cc0097', 'c7efddaa-5110-11df-9f9e-000ae4cc0097', '79a9dcec-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e454-591c-11df-bae3-000ae4cc0097', 'fe30d7d4-5917-11df-bae3-000ae4cc0097', '79a9694c-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06'),
('9076e4b8-591c-11df-bae3-000ae4cc0097', 'fe30d7d4-5917-11df-bae3-000ae4cc0097', '79a9d3f0-591a-11df-bae3-000ae4cc0097', '2010-05-06 16:35:06', '2010-05-06 16:35:06');

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE IF NOT EXISTS `currencies` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sign` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `ISO_code` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fractional_unit` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `number_to_basic` smallint(6) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `name`, `sign`, `ISO_code`, `fractional_unit`, `number_to_basic`, `created`, `modified`) VALUES
('79a8f00c-591a-11df-bae3-000ae4cc0097', 'afghan afghani', '؋', 'afn', 'pul', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f20a-591a-11df-bae3-000ae4cc0097', 'albanian lek', 'l', 'all', 'qintar', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f2a0-591a-11df-bae3-000ae4cc0097', 'alderney pound', '£', 'NUL', 'penny', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f34a-591a-11df-bae3-000ae4cc0097', 'algerian dinar', 'د.ج', 'dzd', 'centime', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f3cc-591a-11df-bae3-000ae4cc0097', 'angolan kwanza', 'kz', 'aoa', 'cêntimo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f44e-591a-11df-bae3-000ae4cc0097', 'argentine peso', '$', 'ars', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f4c6-591a-11df-bae3-000ae4cc0097', 'armenian dram', 'դր.', 'amd', 'luma', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f53e-591a-11df-bae3-000ae4cc0097', 'aruban florin', 'ƒ', 'awg', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f5b6-591a-11df-bae3-000ae4cc0097', 'ascension pound', '£', 'NUL', 'penny', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f638-591a-11df-bae3-000ae4cc0097', 'australian dollar', '$', 'aud', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f6a6-591a-11df-bae3-000ae4cc0097', 'azerbaijani manat', 'azer', 'azn', 'qəpik', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f71e-591a-11df-bae3-000ae4cc0097', 'bahamian dollar', '$', 'bsd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f78c-591a-11df-bae3-000ae4cc0097', 'bahraini dinar', 'ب.د', 'bhd', 'fils', 1, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f804-591a-11df-bae3-000ae4cc0097', 'bangladeshi taka', '৳', 'bdt', 'paisa', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f872-591a-11df-bae3-000ae4cc0097', 'barbadian dollar', '$', 'bbd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f8ea-591a-11df-bae3-000ae4cc0097', 'belarusian ruble', 'br', 'byr', 'kapyeyka', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f962-591a-11df-bae3-000ae4cc0097', 'belize dollar', '$', 'bzd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8f9d0-591a-11df-bae3-000ae4cc0097', 'bermudian dollar', '$', 'bmd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8fa3e-591a-11df-bae3-000ae4cc0097', 'bhutanese ngultrum', ' ', 'btn', 'chertrum', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8fda4-591a-11df-bae3-000ae4cc0097', 'bolivian boliviano', 'bs.', 'bob', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8fe26-591a-11df-bae3-000ae4cc0097', 'bosnia and herzegovina convertible mark', 'km o', 'bam', 'fening', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8fe9e-591a-11df-bae3-000ae4cc0097', 'botswana pula', 'p', 'bwp', 'thebe', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8ff0c-591a-11df-bae3-000ae4cc0097', 'brazilian real', 'r$', 'brl', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8ff7a-591a-11df-bae3-000ae4cc0097', 'british pound', '£', 'gbp', 'penny', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a8fff2-591a-11df-bae3-000ae4cc0097', 'british virgin islands dollar', '$', 'NUL', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90074-591a-11df-bae3-000ae4cc0097', 'brunei dollar', '$', 'bnd', 'sen', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a900d8-591a-11df-bae3-000ae4cc0097', 'bulgarian lev', 'лв', 'bgn', 'stotinka', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90150-591a-11df-bae3-000ae4cc0097', 'burundian franc', 'fr', 'bif', 'centime', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a901be-591a-11df-bae3-000ae4cc0097', 'cambodian riel', '៛', 'khr', 'sen', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90236-591a-11df-bae3-000ae4cc0097', 'canadian dollar', '$', 'cad', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a902ae-591a-11df-bae3-000ae4cc0097', 'cape verdean escudo', '$ or', 'cve', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9031c-591a-11df-bae3-000ae4cc0097', 'cayman islands dollar', '$', 'kyd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90394-591a-11df-bae3-000ae4cc0097', 'central african cfa franc', 'fr', 'xaf', 'centime', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9040c-591a-11df-bae3-000ae4cc0097', 'cfp franc', 'fr', 'xpf', 'centime', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9047a-591a-11df-bae3-000ae4cc0097', 'chilean peso', '$', 'clp', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a904f2-591a-11df-bae3-000ae4cc0097', 'chinese yuan', '元', 'cny', 'fen', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90560-591a-11df-bae3-000ae4cc0097', 'cocos (keeling) islands dollar', '$', 'NUL', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a905d8-591a-11df-bae3-000ae4cc0097', 'colombian peso', '$', 'cop', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90650-591a-11df-bae3-000ae4cc0097', 'comorian franc', 'fr', 'kmf', 'centime', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90c36-591a-11df-bae3-000ae4cc0097', 'congolese franc', 'fr', 'cdf', 'centime', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90cae-591a-11df-bae3-000ae4cc0097', 'cook islands dollar', '$', 'NUL', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90d30-591a-11df-bae3-000ae4cc0097', 'costa rican colón', '₡', 'crc', 'céntimo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90d9e-591a-11df-bae3-000ae4cc0097', 'croatian kuna', 'kn', 'hrk', 'lipa', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90e0c-591a-11df-bae3-000ae4cc0097', 'cuban convertible peso', '$', 'cuc', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90e84-591a-11df-bae3-000ae4cc0097', 'cuban peso', '$', 'cup', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90efc-591a-11df-bae3-000ae4cc0097', 'czech koruna', 'kč', 'czk', 'haléř', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90f6a-591a-11df-bae3-000ae4cc0097', 'danish krone', 'kr', 'dkk', 'øre', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a90fd8-591a-11df-bae3-000ae4cc0097', 'djiboutian franc', 'fr', 'djf', 'centime', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a91050-591a-11df-bae3-000ae4cc0097', 'dominican peso', '$', 'dop', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a910be-591a-11df-bae3-000ae4cc0097', 'east caribbean dollar', '$', 'xcd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9112c-591a-11df-bae3-000ae4cc0097', 'egyptian pound', '£ or', 'egp', 'piastre', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9119a-591a-11df-bae3-000ae4cc0097', 'eritrean nakfa', 'nfk', 'ern', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a91212-591a-11df-bae3-000ae4cc0097', 'estonian kroon', 'kr', 'eek', 'sent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a91280-591a-11df-bae3-000ae4cc0097', 'ethiopian birr', ' ', 'etb', 'santim', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a912ee-591a-11df-bae3-000ae4cc0097', 'euro', '€', 'eur', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9135c-591a-11df-bae3-000ae4cc0097', 'falkland islands pound', '£', 'fkp', 'penny', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a913d4-591a-11df-bae3-000ae4cc0097', 'faroese króna', 'kr', 'NUL', 'oyra', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9144c-591a-11df-bae3-000ae4cc0097', 'fijian dollar', '$', 'fjd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a914ba-591a-11df-bae3-000ae4cc0097', 'gambian dalasi', 'd', 'gmd', 'butut', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a91532-591a-11df-bae3-000ae4cc0097', 'georgian lari', 'ლ', 'gel', 'tetri', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a91da2-591a-11df-bae3-000ae4cc0097', 'ghanaian cedi', '₵', 'ghs', 'pesewa', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a91e10-591a-11df-bae3-000ae4cc0097', 'gibraltar pound', '£', 'gip', 'penny', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a91e74-591a-11df-bae3-000ae4cc0097', 'guatemalan quetzal', 'q', 'gtq', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a91ee2-591a-11df-bae3-000ae4cc0097', 'guernsey pound', '£', 'NUL', 'penny', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a91f5a-591a-11df-bae3-000ae4cc0097', 'guinean franc', 'fr', 'gnf', 'centime', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a91fbe-591a-11df-bae3-000ae4cc0097', 'guyanese dollar', '$', 'gyd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a92022-591a-11df-bae3-000ae4cc0097', 'haitian gourde', 'g', 'htg', 'centime', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a92090-591a-11df-bae3-000ae4cc0097', 'honduran lempira', 'l', 'hnl', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a920f4-591a-11df-bae3-000ae4cc0097', 'hong kong dollar', '$', 'hkd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a92158-591a-11df-bae3-000ae4cc0097', 'hungarian forint', 'ft', 'huf', 'fillér', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a921c6-591a-11df-bae3-000ae4cc0097', 'icelandic króna', 'kr', 'isk', 'eyrir', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9222a-591a-11df-bae3-000ae4cc0097', 'indian rupee', '₨', 'inr', 'paisa', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a92298-591a-11df-bae3-000ae4cc0097', 'indonesian rupiah', 'rp', 'idr', 'sen', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a922fc-591a-11df-bae3-000ae4cc0097', 'iranian rial', '﷼', 'irr', 'dinar', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9236a-591a-11df-bae3-000ae4cc0097', 'iraqi dinar', 'ع.د', 'iqd', 'fils', 1, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a923ce-591a-11df-bae3-000ae4cc0097', 'israeli new sheqel', '₪', 'ils', 'agora', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a92432-591a-11df-bae3-000ae4cc0097', 'jamaican dollar', '$', 'jmd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a92496-591a-11df-bae3-000ae4cc0097', 'japanese yen', '¥', 'jpy', 'sen', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a92504-591a-11df-bae3-000ae4cc0097', 'jersey pound', '£', 'NUL', 'penny', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a92572-591a-11df-bae3-000ae4cc0097', 'jordanian dinar', 'د.ا', 'jod', 'piastre', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a925e0-591a-11df-bae3-000ae4cc0097', 'karabakh dram', 'դր.', 'NUL', 'luma', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a92702-591a-11df-bae3-000ae4cc0097', 'kazakhstani tenge', '〒', 'kzt', 'tiyn', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9277a-591a-11df-bae3-000ae4cc0097', 'kenyan shilling', 'sh', 'kes', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a932f6-591a-11df-bae3-000ae4cc0097', 'kiribati dollar', '$', 'NUL', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a93378-591a-11df-bae3-000ae4cc0097', 'kuwaiti dinar', 'د.ك', 'kwd', 'fils', 1, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a933e6-591a-11df-bae3-000ae4cc0097', 'kyrgyzstani som', ' ', 'kgs', 'tyiyn', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9345e-591a-11df-bae3-000ae4cc0097', 'lao kip', '₭', 'lak', 'att', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a934d6-591a-11df-bae3-000ae4cc0097', 'latvian lats', 'ls', 'lvl', 'santīms', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a93544-591a-11df-bae3-000ae4cc0097', 'lebanese pound', 'ل.ل', 'lbp', 'piastre', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a935bc-591a-11df-bae3-000ae4cc0097', 'lesotho loti', 'l', 'lsl', 'sente', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9362a-591a-11df-bae3-000ae4cc0097', 'liberian dollar', '$', 'lrd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a936a2-591a-11df-bae3-000ae4cc0097', 'libyan dinar', 'ل.د', 'lyd', 'dirham', 1, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a93710-591a-11df-bae3-000ae4cc0097', 'lithuanian litas', 'lt', 'ltl', 'centas', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9377e-591a-11df-bae3-000ae4cc0097', 'macanese pataca', 'p', 'mop', 'avo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a937f6-591a-11df-bae3-000ae4cc0097', 'macedonian denar', 'ден', 'mkd', 'deni', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a93864-591a-11df-bae3-000ae4cc0097', 'malagasy ariary', ' ', 'mga', 'iraimbilanja', 5, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a938dc-591a-11df-bae3-000ae4cc0097', 'malawian kwacha', 'mk', 'mwk', 'tambala', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9394a-591a-11df-bae3-000ae4cc0097', 'malaysian ringgit', 'rm', 'myr', 'sen', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a939c2-591a-11df-bae3-000ae4cc0097', 'maldivian rufiyaa', 'ރ.', 'mvr', 'laari', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a93a30-591a-11df-bae3-000ae4cc0097', 'manx pound', '£', 'NUL', 'penny', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a93ab2-591a-11df-bae3-000ae4cc0097', 'mauritanian ouguiya', 'um', 'mro', 'khoums', 5, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a93b2a-591a-11df-bae3-000ae4cc0097', 'mauritian rupee', '₨', 'mur', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a93b98-591a-11df-bae3-000ae4cc0097', 'mexican peso', '$', 'mxn', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a93c10-591a-11df-bae3-000ae4cc0097', 'micronesian dollar', '$', 'NUL', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a93c88-591a-11df-bae3-000ae4cc0097', 'moldovan leu', 'l', 'mdl', 'ban', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a93d00-591a-11df-bae3-000ae4cc0097', 'mongolian tögrög', '₮', 'mnt', 'möngö', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a93d6e-591a-11df-bae3-000ae4cc0097', 'moroccan dirham', 'د.م.', 'mad', 'centime', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a94b06-591a-11df-bae3-000ae4cc0097', 'mozambican metical', 'mtn', 'mzn', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a94b88-591a-11df-bae3-000ae4cc0097', 'myanma kyat', 'k', 'mmk', 'pya', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a94c00-591a-11df-bae3-000ae4cc0097', 'namibian dollar', '$', 'nad', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a94c6e-591a-11df-bae3-000ae4cc0097', 'nauruan dollar', '$', 'NUL', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a94cf0-591a-11df-bae3-000ae4cc0097', 'nepalese rupee', '₨', 'npr', 'paisa', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a94d68-591a-11df-bae3-000ae4cc0097', 'netherlands antillean guilder', 'ƒ', 'ang', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a94dd6-591a-11df-bae3-000ae4cc0097', 'new taiwan dollar', '$', 'twd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a94e4e-591a-11df-bae3-000ae4cc0097', 'new zealand dollar', '$', 'nzd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a94ec6-591a-11df-bae3-000ae4cc0097', 'nicaraguan córdoba', 'c$', 'nio', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a94f3e-591a-11df-bae3-000ae4cc0097', 'nigerian naira', '₦', 'ngn', 'kobo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a94fac-591a-11df-bae3-000ae4cc0097', 'niuean dollar', '$', 'NUL', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9502e-591a-11df-bae3-000ae4cc0097', 'north korean won', '₩', 'kpw', 'chŏn', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9509c-591a-11df-bae3-000ae4cc0097', 'northern mariana islands dollar', '$', 'NUL', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9511e-591a-11df-bae3-000ae4cc0097', 'norwegian krone', 'kr', 'nok', 'øre', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9518c-591a-11df-bae3-000ae4cc0097', 'omani rial', 'ر.ع.', 'omr', 'baisa', 1, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a95204-591a-11df-bae3-000ae4cc0097', 'pakistani rupee', '₨', 'pkr', 'paisa', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9527c-591a-11df-bae3-000ae4cc0097', 'palauan dollar', '$', 'NUL', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a952fe-591a-11df-bae3-000ae4cc0097', 'panamanian balboa', 'b/.', 'pab', 'centésimo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a95376-591a-11df-bae3-000ae4cc0097', 'papua new guinean kina', 'k', 'pgk', 'toea', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a953ee-591a-11df-bae3-000ae4cc0097', 'paraguayan guaraní', '₲', 'pyg', 'céntimo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a95466-591a-11df-bae3-000ae4cc0097', 'peruvian nuevo sol', 's/.', 'pen', 'céntimo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a954d4-591a-11df-bae3-000ae4cc0097', 'philippine peso', '₱', 'php', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9554c-591a-11df-bae3-000ae4cc0097', 'polish złoty', 'zł', 'pln', 'grosz', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a955c4-591a-11df-bae3-000ae4cc0097', 'qatari riyal', 'ر.ق', 'qar', 'dirham', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9563c-591a-11df-bae3-000ae4cc0097', 'romanian leu', 'l', 'ron', 'ban', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a956aa-591a-11df-bae3-000ae4cc0097', 'russian ruble', 'р.', 'rub', 'kopek', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a968ac-591a-11df-bae3-000ae4cc0097', 'rwandan franc', 'fr', 'rwf', 'centime', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9694c-591a-11df-bae3-000ae4cc0097', 'saint helena pound', '£', 'shp', 'penny', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a969c4-591a-11df-bae3-000ae4cc0097', 'salvadoran colón', '₡', 'svc', 'centavo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a96a3c-591a-11df-bae3-000ae4cc0097', 'samoan tala', 't', 'wst', 'sene', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a96ab4-591a-11df-bae3-000ae4cc0097', 'são tomé and príncipe dobra', 'db', 'std', 'cêntimo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a96b2c-591a-11df-bae3-000ae4cc0097', 'saudi riyal', 'ر.س', 'sar', 'hallallah', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a96ba4-591a-11df-bae3-000ae4cc0097', 'serbian dinar', 'дин.', 'rsd', 'para', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a96c1c-591a-11df-bae3-000ae4cc0097', 'seychellois rupee', '₨', 'scr', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a96c94-591a-11df-bae3-000ae4cc0097', 'sierra leonean leone', 'le', 'sll', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a96d02-591a-11df-bae3-000ae4cc0097', 'singapore dollar', '$', 'sgd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a96d7a-591a-11df-bae3-000ae4cc0097', 'solomon islands dollar', '$', 'sbd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a96df2-591a-11df-bae3-000ae4cc0097', 'somali shilling', 'sh', 'sos', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a96e6a-591a-11df-bae3-000ae4cc0097', 'somaliland shilling', 'sh', 'NUL', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c004-591a-11df-bae3-000ae4cc0097', 'south african rand', 'r', 'zar', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c112-591a-11df-bae3-000ae4cc0097', 'south georgia and the south sandwich islands pound', '£', 'NUL', 'penny', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c1ee-591a-11df-bae3-000ae4cc0097', 'south korean won', '₩', 'krw', 'jeon', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c3f6-591a-11df-bae3-000ae4cc0097', 'sri lankan rupee', 'rs', 'lkr', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c4a0-591a-11df-bae3-000ae4cc0097', 'sudanese pound', '£', 'sdg', 'piastre', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c522-591a-11df-bae3-000ae4cc0097', 'surinamese dollar', '$', 'srd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c5a4-591a-11df-bae3-000ae4cc0097', 'swazi lilangeni', 'l', 'szl', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c626-591a-11df-bae3-000ae4cc0097', 'swedish krona', 'kr', 'sek', 'öre', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c6a8-591a-11df-bae3-000ae4cc0097', 'swiss franc', 'fr', 'chf', 'rappen', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c720-591a-11df-bae3-000ae4cc0097', 'syrian pound', '£ or', 'syp', 'piastre', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c7a2-591a-11df-bae3-000ae4cc0097', 'tajikistani somoni', 'ѕм', 'tjs', 'diram', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c82e-591a-11df-bae3-000ae4cc0097', 'tanzanian shilling', 'sh', 'tzs', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c8a6-591a-11df-bae3-000ae4cc0097', 'thai baht', '฿', 'thb', 'satang', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c928-591a-11df-bae3-000ae4cc0097', 'tongan paʻanga', 't$', 'top', 'seniti', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9c9aa-591a-11df-bae3-000ae4cc0097', 'transnistrian ruble', 'р.', 'NUL', 'kopek', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d364-591a-11df-bae3-000ae4cc0097', 'trinidad and tobago dollar', '$', 'ttd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d3f0-591a-11df-bae3-000ae4cc0097', 'tristan da cunha pound', '£', 'NUL', 'penny', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d47c-591a-11df-bae3-000ae4cc0097', 'tunisian dinar', 'د.ت', 'tnd', 'millime', 1, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d4fe-591a-11df-bae3-000ae4cc0097', 'turkish lira', '₤', 'try', 'kuruş', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d576-591a-11df-bae3-000ae4cc0097', 'turkmenistani manat', 'm', 'tmm', 'tennesi', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d5f8-591a-11df-bae3-000ae4cc0097', 'tuvaluan dollar', '$', 'NUL', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d684-591a-11df-bae3-000ae4cc0097', 'ugandan shilling', 'sh', 'ugx', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d6fc-591a-11df-bae3-000ae4cc0097', 'ukrainian hryvnia', '₴', 'uah', 'kopiyka', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d77e-591a-11df-bae3-000ae4cc0097', 'united arab emirates dirham', 'د.إ', 'aed', 'fils', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d800-591a-11df-bae3-000ae4cc0097', 'united states dollar', '$', 'usd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d878-591a-11df-bae3-000ae4cc0097', 'united states dollar[4]', '$', 'usd', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d8fa-591a-11df-bae3-000ae4cc0097', 'uruguayan peso', '$', 'uyu', 'centésimo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d972-591a-11df-bae3-000ae4cc0097', 'uzbekistani som', ' ', 'uzs', 'tiyin', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9d9f4-591a-11df-bae3-000ae4cc0097', 'vanuatu vatu', 'vt', 'vuv', ' ', 0, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9da6c-591a-11df-bae3-000ae4cc0097', 'venezuelan bolívar', 'bs f', 'vef', 'céntimo', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9daee-591a-11df-bae3-000ae4cc0097', 'vietnamese đồng', '₫', 'vnd', 'hào', 10, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9db70-591a-11df-bae3-000ae4cc0097', 'west african cfa franc', 'fr', 'xof', 'centime', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9dbe8-591a-11df-bae3-000ae4cc0097', 'yemeni rial', '﷼', 'yer', 'fils', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9dc6a-591a-11df-bae3-000ae4cc0097', 'zambian kwacha', 'zk', 'zmk', 'ngwee', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08'),
('79a9dcec-591a-11df-bae3-000ae4cc0097', 'zimbabwean dollar', '$', 'zwl', 'cent', 100, '2010-05-06 16:20:08', '2010-05-06 16:20:08');

-- --------------------------------------------------------

--
-- Table structure for table `emails`
--

CREATE TABLE IF NOT EXISTS `emails` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `foreign_key` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(320) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `emails`
--


-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE IF NOT EXISTS `favorites` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `foreign_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `model` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`id`, `user_id`, `foreign_id`, `model`, `created`) VALUES
('4c237329-0928-48bf-bd5b-0aebae790e16', '009d4872-68e0-11df-88bf-000ae4cc0097', '4c174cdc-d134-4733-804f-050dae790e16', 'projects', '2010-06-24 17:00:57');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `original_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ISO_639-2-alpha2` varchar(7) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ISO_639-2-alpha1` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'other language code',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `original_name`, `ISO_639-2-alpha2`, `ISO_639-2-alpha1`, `code`) VALUES
('87dd54e6-5781-11df-819c-000ae4cc0097', 'Chinese (Simplified)', '中文 (简)', 'chi/zho', 'zh', 'zh_tw'),
('bda7b456-5761-11df-819c-000ae4cc0097', 'Afar', 'Afaraf', 'aar', 'aa', NULL),
('bda7b622-5761-11df-819c-000ae4cc0097', 'Abkhaz', 'Аҧсуа', 'abk', 'ab', NULL),
('bda7b6ae-5761-11df-819c-000ae4cc0097', 'Acehnese, Achinese', 'Aceh', 'ace', NULL, NULL),
('bda7b730-5761-11df-819c-000ae4cc0097', 'Acoli', '', 'ach', NULL, NULL),
('bda7b7c6-5761-11df-819c-000ae4cc0097', 'Adangme', 'adangbɛ', 'ada', NULL, NULL),
('bda7b834-5761-11df-819c-000ae4cc0097', 'Adyghe, Adygei', 'адыгэбзэ, адыгабзэ', 'ady', NULL, NULL),
('bda7b8a2-5761-11df-819c-000ae4cc0097', 'Afro-Asiatic languages', '', 'afa', NULL, NULL),
('bda7b910-5761-11df-819c-000ae4cc0097', 'Afrihili', '', 'afh', NULL, NULL),
('bda7b988-5761-11df-819c-000ae4cc0097', 'Afrikaans', 'Afrikaans', 'afr', 'af', NULL),
('bda7b9ec-5761-11df-819c-000ae4cc0097', 'Ainu', 'アイヌ イタㇰ(イタッㇰ) or ainu itak', 'ain', NULL, NULL),
('bda7ba5a-5761-11df-819c-000ae4cc0097', 'Akan', '', 'aka', 'ak', NULL),
('bda7bac8-5761-11df-819c-000ae4cc0097', 'Akkadian', 'akkadû, lišānum akkadītum', 'akk', NULL, NULL),
('bda7bb36-5761-11df-819c-000ae4cc0097', 'Albanian', 'Shqip', 'alb/sqi', 'sq', NULL),
('bda7bb9a-5761-11df-819c-000ae4cc0097', 'Aleut', '', 'ale', NULL, NULL),
('bda7bc08-5761-11df-819c-000ae4cc0097', 'Algonquian languages', '', 'alg', NULL, NULL),
('bda7bc76-5761-11df-819c-000ae4cc0097', 'Southern Altai', 'алтай тили', 'alt', NULL, NULL),
('bda7bce4-5761-11df-819c-000ae4cc0097', 'Amharic', 'አማርኛ', 'amh', 'am', NULL),
('bda7bd48-5761-11df-819c-000ae4cc0097', 'Angika', '', 'anp', NULL, NULL),
('bda7bdb6-5761-11df-819c-000ae4cc0097', 'Apache languages', '', 'apa', NULL, NULL),
('bda7c0d6-5761-11df-819c-000ae4cc0097', 'Arabic', '<span style="direction:rtl">العربية</span>', 'ara', 'ar', NULL),
('bda7c144-5761-11df-819c-000ae4cc0097', 'Aragonese', 'Aragonés', 'arg', 'an', NULL),
('bda7c1a8-5761-11df-819c-000ae4cc0097', 'Armenian', 'Հայերեն լեզու', 'arm/hye', 'hy', NULL),
('bda7c216-5761-11df-819c-000ae4cc0097', 'Mapudungun/Mapuche', 'mapudungun/mapuchedungun ', 'arn', NULL, NULL),
('bda7c284-5761-11df-819c-000ae4cc0097', 'Arapaho', 'Hinóno eitíít', 'arp', NULL, NULL),
('bda7c2e8-5761-11df-819c-000ae4cc0097', 'Artificial languages', '', 'art', NULL, NULL),
('bda7c356-5761-11df-819c-000ae4cc0097', 'Arawak', '', 'arw', NULL, NULL),
('bda7c3c4-5761-11df-819c-000ae4cc0097', 'Assamese', 'অসমীয়া', 'asm', 'as', NULL),
('bda7c428-5761-11df-819c-000ae4cc0097', 'Asturian, Bable, Leonese, Asturleonese', 'asturianu', 'ast', NULL, NULL),
('bda7c496-5761-11df-819c-000ae4cc0097', 'Athapascan languages', '', 'ath', NULL, NULL),
('bda7c504-5761-11df-819c-000ae4cc0097', 'Australian languages', '', 'aus', NULL, NULL),
('bda7c572-5761-11df-819c-000ae4cc0097', 'Avaric', 'авар мацӀ, магӀарул мацӀ', 'ava', 'av', NULL),
('bda7c5e0-5761-11df-819c-000ae4cc0097', 'Avestan', 'avesta', 'ave', 'ae', NULL),
('bda7c644-5761-11df-819c-000ae4cc0097', 'Awadhi', 'अवधी', 'awa', NULL, NULL),
('bda7c6a8-5761-11df-819c-000ae4cc0097', 'Aymara', 'aymar aru', 'aym', 'ay', NULL),
('bda7c70c-5761-11df-819c-000ae4cc0097', 'Azerbaijani', 'Azərbaycanca', 'aze', 'az', NULL),
('bda7c770-5761-11df-819c-000ae4cc0097', 'Banda languages', '', 'bad', NULL, NULL),
('bda7c7e8-5761-11df-819c-000ae4cc0097', 'Bamileke languages', '', 'bai', NULL, NULL),
('bda7c856-5761-11df-819c-000ae4cc0097', 'Bashkir', 'башҡорт теле', 'bak', 'ba', NULL),
('bda7c8ba-5761-11df-819c-000ae4cc0097', 'Baluchi', '<span style="direction:rtl">بلوچی</span>', 'bal', NULL, NULL),
('bda7ce0a-5761-11df-819c-000ae4cc0097', 'Bambara', 'bamanankan', 'bam', 'bm', NULL),
('bda7ce78-5761-11df-819c-000ae4cc0097', 'Balinese', 'Basa Bali', 'ban', NULL, NULL),
('bda7cee6-5761-11df-819c-000ae4cc0097', 'Basque', 'euskara', 'baq/eus', 'eu', NULL),
('bda7cf4a-5761-11df-819c-000ae4cc0097', 'Basa', 'ɓasaá', 'bas', NULL, NULL),
('bda7cfae-5761-11df-819c-000ae4cc0097', 'Baltic languages', '', 'bat', NULL, NULL),
('bda7d01c-5761-11df-819c-000ae4cc0097', 'Beja, Bedawiyet', '<span style="direction:rtl">بداوية</span>', 'bej', NULL, NULL),
('bda7d08a-5761-11df-819c-000ae4cc0097', 'Belarusian', 'Беларуская мова', 'bel', 'be', NULL),
('bda7d0ee-5761-11df-819c-000ae4cc0097', 'Bemba', 'ichiBemba', 'bem', NULL, NULL),
('bda7d15c-5761-11df-819c-000ae4cc0097', 'Bengali', 'বাংলা', 'ben', 'bn', NULL),
('bda7d1c0-5761-11df-819c-000ae4cc0097', 'Berber languages', '', 'ber', NULL, NULL),
('bda7d22e-5761-11df-819c-000ae4cc0097', 'Bhojpuri', 'भोजपुरी', 'bho', NULL, NULL),
('bda7d292-5761-11df-819c-000ae4cc0097', 'Bihari (languages)', '', 'bih', 'bh', NULL),
('bda7d300-5761-11df-819c-000ae4cc0097', 'Bikol', '', 'bik', NULL, NULL),
('bda7d36e-5761-11df-819c-000ae4cc0097', 'Bini, Edo', 'Edo', 'bin', NULL, NULL),
('bda7d3d2-5761-11df-819c-000ae4cc0097', 'Bislama', 'Bislama', 'bis', 'bi', NULL),
('bda7d436-5761-11df-819c-000ae4cc0097', 'Siksika', 'siksiká, ᓱᖽᐧᖿ', 'bla', NULL, NULL),
('bda7d49a-5761-11df-819c-000ae4cc0097', 'Bantu languages', '', 'bnt', NULL, NULL),
('bda7d508-5761-11df-819c-000ae4cc0097', 'Bosnian', 'bosanski jezik', 'bos', 'bs', NULL),
('bda7d56c-5761-11df-819c-000ae4cc0097', 'Braj', 'ब्रज भाषा, Brij Bhasha', 'bra', NULL, NULL),
('bda7d5da-5761-11df-819c-000ae4cc0097', 'Breton', 'brezhoneg', 'bre', 'br', NULL),
('bda7d63e-5761-11df-819c-000ae4cc0097', 'Batak languages', '', 'btk', NULL, NULL),
('bda7de18-5761-11df-819c-000ae4cc0097', 'Buriat', 'буряад хэлэн', 'bua', NULL, NULL),
('bda7de86-5761-11df-819c-000ae4cc0097', 'Buginese', 'ᨅᨔ ᨕᨘᨁᨗ', 'bug', NULL, NULL),
('bda7def4-5761-11df-819c-000ae4cc0097', 'Bulgarian', 'български език', 'bul', 'bg', NULL),
('bda7df58-5761-11df-819c-000ae4cc0097', 'Burmese', '|ျမန္မာစာ', 'bur/mya', 'my', NULL),
('bda7dfc6-5761-11df-819c-000ae4cc0097', 'Blin, Bilin', 'ብሊና', 'byn', NULL, NULL),
('bda7e02a-5761-11df-819c-000ae4cc0097', 'Caddo', 'Hasí:nay', 'cad', NULL, NULL),
('bda7e08e-5761-11df-819c-000ae4cc0097', 'Central American Indian languages', '', 'cai', NULL, NULL),
('bda7e0fc-5761-11df-819c-000ae4cc0097', 'Galibi Carib', '', 'car', NULL, NULL),
('bda7e16a-5761-11df-819c-000ae4cc0097', 'Catalan, Valencian', 'català', 'cat', 'ca', NULL),
('bda7e1d8-5761-11df-819c-000ae4cc0097', 'Caucasian languages', '', 'cau', NULL, NULL),
('bda7e246-5761-11df-819c-000ae4cc0097', 'Cebuano', 'Sinugboanon', 'ceb', NULL, NULL),
('bda7e2aa-5761-11df-819c-000ae4cc0097', 'Celtic languages', '', 'cel', NULL, NULL),
('bda7e318-5761-11df-819c-000ae4cc0097', 'Chamorro', 'Chamoru', 'cha', 'ch', NULL),
('bda7e37c-5761-11df-819c-000ae4cc0097', 'Chibcha', '', 'chb', NULL, NULL),
('bda7e3ea-5761-11df-819c-000ae4cc0097', 'Chechen', 'нохчийн мотт', 'che', 'ce', NULL),
('bda7e44e-5761-11df-819c-000ae4cc0097', 'Chagatai', 'جغتای', 'chg', NULL, NULL),
('bda7e4b2-5761-11df-819c-000ae4cc0097', 'Chinese (Traditional)', '中文 (繁)', 'chi/zho', 'zh', 'zh_cn'),
('bda7e520-5761-11df-819c-000ae4cc0097', 'Chuukese', '', 'chk', NULL, NULL),
('bda7e584-5761-11df-819c-000ae4cc0097', 'Mari', 'марий йылме', 'chm', NULL, NULL),
('bda7e5f2-5761-11df-819c-000ae4cc0097', 'Chinook jargon', '', 'chn', NULL, NULL),
('bda7e660-5761-11df-819c-000ae4cc0097', 'Choctaw', 'Chahta Anumpa', 'cho', NULL, NULL),
('bda7e6c4-5761-11df-819c-000ae4cc0097', 'Chipewyan, Dene Suline', 'Dëne Sųłiné, ᑌᓀᓲᒢᕄᓀ', 'chp', NULL, NULL),
('bda7e732-5761-11df-819c-000ae4cc0097', 'Cherokee', 'ᏣᎳᎩ', 'chr', NULL, NULL),
('bda7f1be-5761-11df-819c-000ae4cc0097', 'Church Slavic, Old Slavonic, Church Slavonic, Old Bulgarian, Old Church Slavonic', 'ѩзыкъ словѣньскъ', 'chu', 'cu', NULL),
('bda7f240-5761-11df-819c-000ae4cc0097', 'Chuvash', 'чӑваш чӗлхи', 'chv', 'cv', NULL),
('bda7f2a4-5761-11df-819c-000ae4cc0097', 'Cheyenne', 'Tsêhést', 'chy', NULL, NULL),
('bda7f312-5761-11df-819c-000ae4cc0097', 'Chamic languages', '', 'cmc', NULL, NULL),
('bda7f380-5761-11df-819c-000ae4cc0097', 'Coptic', 'ⲙⲉⲧⲛ̀ⲣⲉⲙⲛ̀ⲭⲏⲙⲓ', 'cop', NULL, NULL),
('bda7f3e4-5761-11df-819c-000ae4cc0097', 'Cornish', 'Kernewek', 'cor', 'kw', NULL),
('bda7f448-5761-11df-819c-000ae4cc0097', 'Corsican', 'corsu, lingua corsa', 'cos', 'co', NULL),
('bda7f4ac-5761-11df-819c-000ae4cc0097', 'creoles and pidgins, English-based', '', 'cpe', NULL, NULL),
('bda7f524-5761-11df-819c-000ae4cc0097', 'creoles and pidgins, French-based', '', 'cpf', NULL, NULL),
('bda7f592-5761-11df-819c-000ae4cc0097', 'creoles and pidgins, Portuguese-based', '', 'cpp', NULL, NULL),
('bda7f600-5761-11df-819c-000ae4cc0097', 'Cree', 'ᓀᐦᐃᔭᐍᐏᐣ', 'cre', 'cr', NULL),
('bda7f66e-5761-11df-819c-000ae4cc0097', 'Crimean Tatar, Crimean Turkish', 'qırımtatar tili, къырымтатар тили', 'crh', NULL, NULL),
('bda7f6dc-5761-11df-819c-000ae4cc0097', 'creoles and pidgins', '', 'crp', NULL, NULL),
('bda7f74a-5761-11df-819c-000ae4cc0097', 'Kashubian', 'kaszëbsczi jãzëk', 'csb', NULL, NULL),
('bda7f7ae-5761-11df-819c-000ae4cc0097', 'Cushitic languages', '', 'cus', NULL, NULL),
('bda7f81c-5761-11df-819c-000ae4cc0097', 'Czech', 'česky, čeština', 'cze/ces', 'cs', NULL),
('bda7f88a-5761-11df-819c-000ae4cc0097', 'Dakota', 'Lakhota', 'dak', NULL, NULL),
('bda7f8ee-5761-11df-819c-000ae4cc0097', 'Danish', 'dansk', 'dan', 'da', NULL),
('bda7f952-5761-11df-819c-000ae4cc0097', 'Dargwa', 'дарган мез', 'dar', NULL, NULL),
('bda7f9b6-5761-11df-819c-000ae4cc0097', 'Land Dayak languages', '', 'day', NULL, NULL),
('bda7fa24-5761-11df-819c-000ae4cc0097', 'Delaware', 'Lënape', 'del', NULL, NULL),
('bda7fa88-5761-11df-819c-000ae4cc0097', 'Slavey', '', 'den', NULL, NULL),
('bda7fb00-5761-11df-819c-000ae4cc0097', 'Dogrib', 'Tłįchǫ', 'dgr', NULL, NULL),
('bda7fb64-5761-11df-819c-000ae4cc0097', 'Dinka', 'Thuɔŋjäŋ', 'din', NULL, NULL),
('bda8083e-5761-11df-819c-000ae4cc0097', 'Divehi, Dhivehi, Maldivian', '<span style="direction:rtl">ދިވެހިބަސ</span>', 'div', 'dv', NULL),
('bda808b6-5761-11df-819c-000ae4cc0097', 'Dogri', 'डोगरी', 'doi', NULL, NULL),
('bda8091a-5761-11df-819c-000ae4cc0097', 'Dravidian languages', '', 'dra', NULL, NULL),
('bda80988-5761-11df-819c-000ae4cc0097', 'Lower Sorbian', 'dolnoserbski', 'dsb', NULL, NULL),
('bda809ec-5761-11df-819c-000ae4cc0097', 'Duala', '', 'dua', NULL, NULL),
('bda80a64-5761-11df-819c-000ae4cc0097', 'Dutch, Flemish', 'Nederlands', 'dut/nld', 'nl', NULL),
('bda80ac8-5761-11df-819c-000ae4cc0097', 'Dyula', 'Julakan', 'dyu', NULL, NULL),
('bda80b2c-5761-11df-819c-000ae4cc0097', 'Dzongkha', 'རྫོང་ཁ', 'dzo', 'dz', NULL),
('bda80b90-5761-11df-819c-000ae4cc0097', 'Efik', '', 'efi', NULL, NULL),
('bda80bfe-5761-11df-819c-000ae4cc0097', 'Egyptian (Ancient)', '', 'egy', NULL, NULL),
('bda80c6c-5761-11df-819c-000ae4cc0097', 'Ekajuk', '', 'eka', NULL, NULL),
('bda80cda-5761-11df-819c-000ae4cc0097', 'Elamite', '', 'elx', NULL, NULL),
('bda80d48-5761-11df-819c-000ae4cc0097', 'English', 'English', 'eng', 'en', NULL),
('bda80dac-5761-11df-819c-000ae4cc0097', 'Esperanto', 'Esperanto', 'epo', 'eo', NULL),
('bda80e10-5761-11df-819c-000ae4cc0097', 'Estonian', 'eesti keel', 'est', 'et', NULL),
('bda80e74-5761-11df-819c-000ae4cc0097', 'Ewe', 'Ɛʋɛgbɛ', 'ewe', 'ee', NULL),
('bda80ee2-5761-11df-819c-000ae4cc0097', 'Ewondo', '', 'ewo', NULL, NULL),
('bda80f50-5761-11df-819c-000ae4cc0097', 'Fang', '', 'fan', NULL, NULL),
('bda80fbe-5761-11df-819c-000ae4cc0097', 'Faroese', 'føroyskt', 'fao', 'fo', NULL),
('bda81022-5761-11df-819c-000ae4cc0097', 'Fanti', '', 'fat', NULL, NULL),
('bda81090-5761-11df-819c-000ae4cc0097', 'Fijian', 'vosa Vakaviti', 'fij', 'fj', NULL),
('bda810f4-5761-11df-819c-000ae4cc0097', 'Filipino', '', 'fil', 'tl', NULL),
('bda81162-5761-11df-819c-000ae4cc0097', 'Finnish', 'suomi, suomen kieli', 'fin', 'fi', NULL),
('bda811d0-5761-11df-819c-000ae4cc0097', 'Finno-Ugrian languages', '', 'fiu', NULL, NULL),
('bda8123e-5761-11df-819c-000ae4cc0097', 'Fon', 'Fɔngbe', 'fon', NULL, NULL),
('bda812a2-5761-11df-819c-000ae4cc0097', 'French', 'français, langue française', 'fre/fra', 'fr', NULL),
('bda82210-5761-11df-819c-000ae4cc0097', 'Northern Frisian', '', 'frr', NULL, NULL),
('bda82288-5761-11df-819c-000ae4cc0097', 'Eastern Frisian', 'Seeltersk Fräisk, Seeltersk, Fräisk', 'frs', NULL, NULL),
('bda82314-5761-11df-819c-000ae4cc0097', 'Western Frisian', 'frysk', 'fry', 'fy', NULL),
('bda823d2-5761-11df-819c-000ae4cc0097', 'Fulah', 'Fulfulde, Pulaar, Pular', 'ful', 'ff', NULL),
('bda82440-5761-11df-819c-000ae4cc0097', 'Friulian', 'furlan', 'fur', NULL, NULL),
('bda824b8-5761-11df-819c-000ae4cc0097', 'Ga', 'Gã', 'gaa', NULL, NULL),
('bda8251c-5761-11df-819c-000ae4cc0097', 'Gayo', '', 'gay', NULL, NULL),
('bda82594-5761-11df-819c-000ae4cc0097', 'Gbaya', '', 'gba', NULL, NULL),
('bda8260c-5761-11df-819c-000ae4cc0097', 'Germanic languages', '', 'gem', NULL, NULL),
('bda8267a-5761-11df-819c-000ae4cc0097', 'Georgian', 'ქართული ენა (''kartuli ena'')', 'geo/kat', 'ka', NULL),
('bda826f2-5761-11df-819c-000ae4cc0097', 'German', 'Deutsch', 'ger/deu', 'de', NULL),
('bda82760-5761-11df-819c-000ae4cc0097', 'Ge''ez', 'ግዕዝ', 'gez', NULL, NULL),
('bda827ce-5761-11df-819c-000ae4cc0097', 'Gilbertese', 'taetae ni Kiribati', 'gil', NULL, NULL),
('bda8283c-5761-11df-819c-000ae4cc0097', 'Scottish Gaelic, Gaelic', 'Gàidhlig', 'gla', 'gd', NULL),
('bda828aa-5761-11df-819c-000ae4cc0097', 'Irish', 'Gaeilge', 'gle', 'ga', NULL),
('bda82918-5761-11df-819c-000ae4cc0097', 'Galician', 'Galego', 'glg', 'gl', NULL),
('bda82986-5761-11df-819c-000ae4cc0097', 'Manx', 'Gaelg, Manninagh', 'glv', 'gv', NULL),
('bda82a30-5761-11df-819c-000ae4cc0097', 'Gondi', 'Gōndi', 'gon', NULL, NULL),
('bda82a94-5761-11df-819c-000ae4cc0097', 'Gorontalo', '', 'gor', NULL, NULL),
('bda82b02-5761-11df-819c-000ae4cc0097', 'Gothic', '', 'got', NULL, NULL),
('bda83462-5761-11df-819c-000ae4cc0097', 'Grebo', '', 'grb', NULL, NULL),
('bda83502-5761-11df-819c-000ae4cc0097', 'Greek', 'Ελληνικά', 'gre/ell', 'el', NULL),
('bda83598-5761-11df-819c-000ae4cc0097', 'Guarani', 'Avañe''ẽ', 'grn', 'gn', NULL),
('bda8362e-5761-11df-819c-000ae4cc0097', 'Swiss German, Alemannic, Alsatian', 'Alemannisch, Schwyzerdütsch', 'gsw', NULL, NULL),
('bda836ba-5761-11df-819c-000ae4cc0097', 'Gujarati', 'ગુજરાતી', 'guj', 'gu', NULL),
('bda83728-5761-11df-819c-000ae4cc0097', 'Gwichʼin', '', 'gwi', NULL, NULL),
('bda83796-5761-11df-819c-000ae4cc0097', 'Haida', 'X̲aat Kíl', 'hai', NULL, NULL),
('bda83804-5761-11df-819c-000ae4cc0097', 'Haitian Creole, Haitian', 'Kreyòl ayisyen', 'hat', 'ht', NULL),
('bda84128-5761-11df-819c-000ae4cc0097', 'Hausa', 'Hausancī, <span style="direction:rtl">هَوُسَ</span>', 'hau', 'ha', NULL),
('bda841a0-5761-11df-819c-000ae4cc0097', 'Hawaiian', '‘Ōlelo Hawai‘i', 'haw', NULL, NULL),
('bda8420e-5761-11df-819c-000ae4cc0097', 'Hebrew', '<span style="direction:rtl">עִבְרִית, עברית</span>', 'heb', 'he', NULL),
('bda84286-5761-11df-819c-000ae4cc0097', 'Herero', 'Otjiherero', 'her', 'hz', NULL),
('bda842f4-5761-11df-819c-000ae4cc0097', 'Hiligaynon', 'Ilonggo', 'hil', NULL, NULL),
('bda84358-5761-11df-819c-000ae4cc0097', 'Himachali', '', 'him', NULL, NULL),
('bda843d0-5761-11df-819c-000ae4cc0097', 'Hindi', 'हिन्दी', 'hin', 'hi', NULL),
('bda8443e-5761-11df-819c-000ae4cc0097', 'Hittite', '', 'hit', NULL, NULL),
('bda844ac-5761-11df-819c-000ae4cc0097', 'Hmong', 'Hmoob', 'hmn', NULL, NULL),
('bda8451a-5761-11df-819c-000ae4cc0097', 'Hiri Motu', 'Hiri Motu', 'hmo', 'ho', NULL),
('bda84588-5761-11df-819c-000ae4cc0097', 'Upper Sorbian', 'hornjoserbsce', 'hsb', NULL, NULL),
('bda845f6-5761-11df-819c-000ae4cc0097', 'Hungarian', 'Magyar', 'hun', 'hu', NULL),
('bda8465a-5761-11df-819c-000ae4cc0097', 'Hupa', 'Na:tinixwe Mixine:whe', 'hup', NULL, NULL),
('bda846c8-5761-11df-819c-000ae4cc0097', 'Iban', '', 'iba', NULL, NULL),
('bda84736-5761-11df-819c-000ae4cc0097', 'Igbo', 'Igbo', 'ibo', 'ig', NULL),
('bda847a4-5761-11df-819c-000ae4cc0097', 'Icelandic', 'íslenska', 'ice/isl', 'is', NULL),
('bda84808-5761-11df-819c-000ae4cc0097', 'Ido', 'Ido', 'ido', 'io', NULL),
('bda84876-5761-11df-819c-000ae4cc0097', 'Sichuan Yi, Nuosu', 'ꆇꉙ', 'iii', 'ii', NULL),
('bda848e4-5761-11df-819c-000ae4cc0097', 'Ijo languages', '', 'ijo', NULL, NULL),
('bda84952-5761-11df-819c-000ae4cc0097', 'Inuktitut', 'ᐃᓄᒃᑎᑐᑦ', 'iku', 'iu', NULL),
('bda849c0-5761-11df-819c-000ae4cc0097', 'Interlingue, Occidental', 'Interlingue', 'ile', 'ie', NULL),
('bda84a2e-5761-11df-819c-000ae4cc0097', 'Iloko', '', 'ilo', NULL, NULL),
('bda86e6e-5761-11df-819c-000ae4cc0097', 'Interlingua (International Auxiliary Language Association)', 'interlingua', 'ina', 'ia', NULL),
('bda86ef0-5761-11df-819c-000ae4cc0097', 'Indic languages', '', 'inc', NULL, NULL),
('bda86f68-5761-11df-819c-000ae4cc0097', 'Indonesian', 'Bahasa Indonesia', 'ind', 'id', NULL),
('bda86fd6-5761-11df-819c-000ae4cc0097', 'Indo-European languages', '', 'ine', NULL, NULL),
('bda8704e-5761-11df-819c-000ae4cc0097', 'Ingush', 'гӀалгӀай мотт', 'inh', NULL, NULL),
('bda870bc-5761-11df-819c-000ae4cc0097', 'Inupiaq', 'Iñupiaq, Iñupiatun', 'ipk', 'ik', NULL),
('bda8712a-5761-11df-819c-000ae4cc0097', 'Iranian languages', '', 'ira', NULL, NULL),
('bda87a6c-5761-11df-819c-000ae4cc0097', 'Iroquoian languages', '', 'iro', NULL, NULL),
('bda87ae4-5761-11df-819c-000ae4cc0097', 'Italian', 'italiano', 'ita', 'it', NULL),
('bda87b52-5761-11df-819c-000ae4cc0097', 'Javanese', 'basa Jawa', 'jav', 'jv', NULL),
('bda87bc0-5761-11df-819c-000ae4cc0097', 'Lojban', 'lojban', 'jbo', NULL, NULL),
('bda87c24-5761-11df-819c-000ae4cc0097', 'Japanese', '日本語', 'jpn', 'ja', NULL),
('bda87c92-5761-11df-819c-000ae4cc0097', 'Judeo-Persian', '', 'jpr', NULL, NULL),
('bda87d0a-5761-11df-819c-000ae4cc0097', 'Judeo-Arabic', '', 'jrb', NULL, NULL),
('bda87d78-5761-11df-819c-000ae4cc0097', 'Kara-Kalpak', 'қарақалпақ тили', 'kaa', NULL, NULL),
('bda87de6-5761-11df-819c-000ae4cc0097', 'Kabyle', 'Taqbaylit', 'kab', NULL, NULL),
('bda87e4a-5761-11df-819c-000ae4cc0097', 'Kachin, Jingpho', 'Jingpho, Marip', 'kac', NULL, NULL),
('bda87ec2-5761-11df-819c-000ae4cc0097', 'Greenlandic, Kalaallisut', 'kalaallisut, kalaallit oqaasii', 'kal', 'kl', NULL),
('bda87f30-5761-11df-819c-000ae4cc0097', 'Kamba', '', 'kam', NULL, NULL),
('bda87f9e-5761-11df-819c-000ae4cc0097', 'Kannada', 'ಕನ್ನಡ', 'kan', 'kn', NULL),
('bda8800c-5761-11df-819c-000ae4cc0097', 'Karen languages', '', 'kar', NULL, NULL),
('bda8807a-5761-11df-819c-000ae4cc0097', 'Kashmiri', 'कॉशुर, <span style="direction:rtl">کٲشُر</span>', 'kas', 'ks', NULL),
('bda880e8-5761-11df-819c-000ae4cc0097', 'Kanuri', '', 'kau', 'kr', NULL),
('bda88160-5761-11df-819c-000ae4cc0097', 'Kawi', 'Bhāṣa Kawi', 'kaw', NULL, NULL),
('bda881c4-5761-11df-819c-000ae4cc0097', 'Kazakh', 'Қазақ тілі', 'kaz', 'kk', NULL),
('bda88232-5761-11df-819c-000ae4cc0097', 'Kabardian', 'къэбэрдеибзэ', 'kbd', NULL, NULL),
('bda882a0-5761-11df-819c-000ae4cc0097', 'Khasi', 'Khasi', 'kha', NULL, NULL),
('bda8830e-5761-11df-819c-000ae4cc0097', 'Khoisan languages', '', 'khi', NULL, NULL),
('bda8837c-5761-11df-819c-000ae4cc0097', 'Central Khmer', '', 'khm', 'km', NULL),
('bda883f4-5761-11df-819c-000ae4cc0097', 'Khotanese, Sakan', '', 'kho', NULL, NULL),
('bda88462-5761-11df-819c-000ae4cc0097', 'Kikuyu, Gikuyu', 'Gĩkũyũ', 'kik', 'ki', NULL),
('bda884d0-5761-11df-819c-000ae4cc0097', 'Kinyarwanda', 'kinyaRwanda', 'kin', 'rw', NULL),
('bda8853e-5761-11df-819c-000ae4cc0097', 'Kirghiz', 'кыргыз тили', 'kir', 'ky', NULL),
('bda885ac-5761-11df-819c-000ae4cc0097', 'Kimbundu', '', 'kmb/kim', NULL, NULL),
('bda88624-5761-11df-819c-000ae4cc0097', 'Konkani', 'कोंकणी', 'kok', NULL, NULL),
('bda88688-5761-11df-819c-000ae4cc0097', 'Komi', 'коми кыв', 'kom', 'kv', NULL),
('bda88ff2-5761-11df-819c-000ae4cc0097', 'Kongo', 'Kikongo', 'kon', 'kg', NULL),
('bda8906a-5761-11df-819c-000ae4cc0097', 'Korean', '한국어', 'kor', 'ko', NULL),
('bda890d8-5761-11df-819c-000ae4cc0097', 'Kosraean', 'Kosrae', 'kos', NULL, NULL),
('bda8913c-5761-11df-819c-000ae4cc0097', 'Kpelle', 'kpele', 'kpe', NULL, NULL),
('bda891aa-5761-11df-819c-000ae4cc0097', 'Karachay-Balkar', 'къарачай-малкъар тил', 'krc', NULL, NULL),
('bda89218-5761-11df-819c-000ae4cc0097', 'Karelian', 'karjalan kieli', 'krl', NULL, NULL),
('bda89286-5761-11df-819c-000ae4cc0097', 'Kru languages', '', 'kro', NULL, NULL),
('bda892fe-5761-11df-819c-000ae4cc0097', 'Kurukh', '', 'kru', NULL, NULL),
('bda8936c-5761-11df-819c-000ae4cc0097', 'Kuanyama, Kwanyama', '', 'kua', 'kj', NULL),
('bda893da-5761-11df-819c-000ae4cc0097', 'Kumyk', 'Кумык', 'kum', NULL, NULL),
('bda89560-5761-11df-819c-000ae4cc0097', 'Kurdish', 'Kurdî', 'kur', 'ku', NULL),
('bda895d8-5761-11df-819c-000ae4cc0097', 'Kutenai', 'Ktunaxa', 'kut', NULL, NULL),
('bda89646-5761-11df-819c-000ae4cc0097', 'Ladino', '<span style="direction:rtl">ודיאו-איספאנייול</span>', 'lad', NULL, NULL),
('bda896be-5761-11df-819c-000ae4cc0097', 'Lahnda', 'ਲਹਿੰਦੀ', 'lah', NULL, NULL),
('bda89736-5761-11df-819c-000ae4cc0097', 'Lamba', '', 'lam', NULL, NULL),
('bda897ae-5761-11df-819c-000ae4cc0097', 'Lao', 'ພາສາລາວ', 'lao', 'lo', NULL),
('bda89894-5761-11df-819c-000ae4cc0097', 'Latin', 'latine, lingua latina', 'lat', 'la', NULL),
('bda8990c-5761-11df-819c-000ae4cc0097', 'Latvian', 'latviešu valoda', 'lav', 'lv', NULL),
('bda8997a-5761-11df-819c-000ae4cc0097', 'Lezghian', 'лезги чӀал', 'lez', NULL, NULL),
('bda899e8-5761-11df-819c-000ae4cc0097', 'Limburgish, Limburger, Limburgan', 'Limburgs', 'lim', 'li', NULL),
('bda89a60-5761-11df-819c-000ae4cc0097', 'Lingala', 'lingála', 'lin', 'ln', NULL),
('bda89ace-5761-11df-819c-000ae4cc0097', 'Lithuanian', 'lietuvių kalba', 'lit', 'lt', NULL),
('bda89b3c-5761-11df-819c-000ae4cc0097', 'Mongo', '', 'lol', NULL, NULL),
('bda89baa-5761-11df-819c-000ae4cc0097', 'Lozi', 'siLozi', 'loz', NULL, NULL),
('bda89c18-5761-11df-819c-000ae4cc0097', 'Luxembourgish, Letzeburgesch', 'Lëtzebuergesch', 'ltz', 'lb', NULL),
('bda89c86-5761-11df-819c-000ae4cc0097', 'Luba-Lulua', 'lwaà:', 'lua', NULL, NULL),
('bda89cf4-5761-11df-819c-000ae4cc0097', 'Luba-Katanga', '', 'lub', 'lu', NULL),
('bda89d6c-5761-11df-819c-000ae4cc0097', 'Ganda', 'Luganda', 'lug', 'lg', NULL),
('bda89dda-5761-11df-819c-000ae4cc0097', 'Luiseño', '', 'lui', NULL, NULL),
('bda8ab54-5761-11df-819c-000ae4cc0097', 'Lunda', 'chiLunda', 'lun', NULL, NULL),
('bda8abcc-5761-11df-819c-000ae4cc0097', 'Luo (Kenya and Tanzania)', 'Dholuo', 'luo', NULL, NULL),
('bda8ac3a-5761-11df-819c-000ae4cc0097', 'Lushai', '', 'lus', NULL, NULL),
('bda8acb2-5761-11df-819c-000ae4cc0097', 'Macedonian', 'македонски јазик', 'mac/mkd', 'mk', NULL),
('bda8ad20-5761-11df-819c-000ae4cc0097', 'Madurese', '', 'mad', NULL, NULL),
('bda8ad98-5761-11df-819c-000ae4cc0097', 'Magahi', '', 'mag', NULL, NULL),
('bda8ae06-5761-11df-819c-000ae4cc0097', 'Marshallese', 'Kajin M̧ajeļ', 'mah', 'mh', NULL),
('bda8ae74-5761-11df-819c-000ae4cc0097', 'Maithili', 'मैथिली', 'mai', NULL, NULL),
('bda8aeec-5761-11df-819c-000ae4cc0097', 'Makasar', '', 'mak', NULL, NULL),
('bda8af5a-5761-11df-819c-000ae4cc0097', 'Malayalam', 'മലയാളം', 'mal', 'ml', NULL),
('bda8afc8-5761-11df-819c-000ae4cc0097', 'Mandingo', '', 'man', NULL, NULL),
('bda8b040-5761-11df-819c-000ae4cc0097', 'Māori', 'te reo Māori', 'mao/mri', 'mi', NULL),
('bda8b0ae-5761-11df-819c-000ae4cc0097', 'Austronesian languages', '', 'map', NULL, NULL),
('bda8b126-5761-11df-819c-000ae4cc0097', 'Marathi', 'मराठी', 'mar', 'mr', NULL),
('bda8b194-5761-11df-819c-000ae4cc0097', 'Masai', 'ɔl Maa', 'mas', NULL, NULL),
('bda8b202-5761-11df-819c-000ae4cc0097', 'Malay', 'bahasa Melayu, <span style="direction:rtl">بهاس ملايو</span>', 'may/msa', 'ms', NULL),
('bda8b27a-5761-11df-819c-000ae4cc0097', 'Moksha', 'мокшень кяль', 'mdf', NULL, NULL),
('bda8b2e8-5761-11df-819c-000ae4cc0097', 'Mandar', '', 'mdr', NULL, NULL),
('bda8b356-5761-11df-819c-000ae4cc0097', 'Mende', 'Mɛnde', 'men', NULL, NULL),
('bda8b3c4-5761-11df-819c-000ae4cc0097', 'Middle Irish (900–1200)', 'Gaoidhealg', 'mga', NULL, NULL),
('bda8b432-5761-11df-819c-000ae4cc0097', 'Mi''kmaq, Micmac', 'Míkmaq, Mi''gmaq', 'mic', NULL, NULL),
('bda8b4aa-5761-11df-819c-000ae4cc0097', 'Minangkabau', 'Baso Minangkabau', 'min', NULL, NULL),
('bda8b518-5761-11df-819c-000ae4cc0097', 'uncoded languages', '', 'mis', NULL, NULL),
('bda8b590-5761-11df-819c-000ae4cc0097', 'Mon-Khmer languages', '', 'mkh', NULL, NULL),
('bda8b608-5761-11df-819c-000ae4cc0097', 'Malagasy', 'Malagasy fiteny', 'mlg', 'mg', NULL),
('bda8b66c-5761-11df-819c-000ae4cc0097', 'Maltese', 'Malti', 'mlt', 'mt', NULL),
('bda8b6da-5761-11df-819c-000ae4cc0097', 'Manchu', 'ᠮᠠᠨᠵᡠ ᡤᡳᠰᡠᠨ ᠪᡝ', 'mnc', NULL, NULL),
('bda8b748-5761-11df-819c-000ae4cc0097', 'Manipuri', 'মৈইতৈইলোন', 'mni', NULL, NULL),
('bda8b7b6-5761-11df-819c-000ae4cc0097', 'Manobo languages', '', 'mno', NULL, NULL),
('bda8b82e-5761-11df-819c-000ae4cc0097', 'Mohawk', 'Kanien’keha', 'moh', NULL, NULL),
('bda8b89c-5761-11df-819c-000ae4cc0097', 'Mongolian', 'монгол хэл', 'mon', 'mn', NULL),
('bda8b90a-5761-11df-819c-000ae4cc0097', 'Mossi', 'Mòoré', 'mos', NULL, NULL),
('bda8b978-5761-11df-819c-000ae4cc0097', 'multiple languages', '', 'mul', NULL, NULL),
('bda8b9f0-5761-11df-819c-000ae4cc0097', 'Munda languages', '', 'mun', NULL, NULL),
('bda8ba5e-5761-11df-819c-000ae4cc0097', 'Creek', 'Maskoki, Mvskokē empunakv', 'mus', NULL, NULL),
('bda8bacc-5761-11df-819c-000ae4cc0097', 'Mirandese', 'Lhéngua Mirandesa', 'mwl', NULL, NULL),
('bda8bb44-5761-11df-819c-000ae4cc0097', 'Marwari', 'मारवाड़ी', 'mwr', NULL, NULL),
('bda8bbb2-5761-11df-819c-000ae4cc0097', 'Mayan languages', '', 'myn', NULL, NULL),
('bda8bc20-5761-11df-819c-000ae4cc0097', 'Erzya', 'эрзянь кель', 'myv', NULL, NULL),
('bda8bc8e-5761-11df-819c-000ae4cc0097', 'Nahuatl languages', 'nāhuatl, nawatlahtolli', 'nah', NULL, NULL),
('bda8bcfc-5761-11df-819c-000ae4cc0097', 'North American Indian languages', '', 'nai', NULL, NULL),
('bda8bd7e-5761-11df-819c-000ae4cc0097', 'Neapolitan', 'napulitano', 'nap', NULL, NULL),
('bda8cd14-5761-11df-819c-000ae4cc0097', 'Nauruan', 'Ekakairũ Naoero', 'nau', 'na', NULL),
('bda8cda0-5761-11df-819c-000ae4cc0097', 'Navajo, Navaho', 'Diné bizaad, Dinékʼehǰí', 'nav', 'nv', NULL),
('bda8ce18-5761-11df-819c-000ae4cc0097', 'South Ndebele', 'Ndébélé', 'nbl', 'nr', NULL),
('bda8ce86-5761-11df-819c-000ae4cc0097', 'North Ndebele', 'isiNdebele', 'nde', 'nd', NULL),
('bda8cefe-5761-11df-819c-000ae4cc0097', 'Ndonga', 'Owambo', 'ndo', 'ng', NULL),
('bda8cf6c-5761-11df-819c-000ae4cc0097', 'Low German, Low Saxon', 'Nederdüütsch, Plattdüütsch', 'nds', NULL, NULL),
('bda8cfda-5761-11df-819c-000ae4cc0097', 'Nepali', 'नेपाली', 'nep', 'ne', NULL),
('bda8d052-5761-11df-819c-000ae4cc0097', 'Nepal Bhasa, Newari', 'Nepal Bhasa', 'new', NULL, NULL),
('bda8d0c0-5761-11df-819c-000ae4cc0097', 'Nias', '', 'nia', NULL, NULL),
('bda8d12e-5761-11df-819c-000ae4cc0097', 'Niger-Kordofanian languages', '', 'nic', NULL, NULL),
('bda8d1b0-5761-11df-819c-000ae4cc0097', 'Niuean', 'ko e vagahau Niuē, faka-Niue', 'niu', NULL, NULL),
('bda8d21e-5761-11df-819c-000ae4cc0097', 'Norwegian Nynorsk', 'nynorsk', 'nno', 'nn', NULL),
('bda8d296-5761-11df-819c-000ae4cc0097', 'Norwegian Bokmål', 'bokmål', 'nob', 'nb', NULL),
('bda8d304-5761-11df-819c-000ae4cc0097', 'Nogai', 'ногай тили', 'nog', NULL, NULL),
('bda8d37c-5761-11df-819c-000ae4cc0097', 'Norse, Old', 'norskr', 'non', NULL, NULL),
('bda8d3ea-5761-11df-819c-000ae4cc0097', 'Norwegian', 'norsk', 'nor', 'no', NULL),
('bda8d458-5761-11df-819c-000ae4cc0097', 'N''Ko', '', 'nqo', NULL, NULL),
('bda8d4c6-5761-11df-819c-000ae4cc0097', 'Northern Sotho, Pedi, Sepedi', 'sePêdi', 'nso', NULL, NULL),
('bda8d53e-5761-11df-819c-000ae4cc0097', 'Nubian languages', '', 'nub', NULL, NULL),
('bda8d5b6-5761-11df-819c-000ae4cc0097', 'Classical Newari, Old Newari, Classical Nepal Bhasa', '', 'nwc', NULL, NULL),
('bda8d624-5761-11df-819c-000ae4cc0097', 'Chichewa, Chewa, Nyanja', 'chiCheŵa, chinyanja', 'nya', 'ny', NULL),
('bda8d69c-5761-11df-819c-000ae4cc0097', 'Nyamwezi', 'Kinyamwezi', 'nym', NULL, NULL),
('bda8d70a-5761-11df-819c-000ae4cc0097', 'Nyankole', 'Lounyankolé', 'nyn', NULL, NULL),
('bda8d778-5761-11df-819c-000ae4cc0097', 'Nyoro', 'Runyoro', 'nyo', NULL, NULL),
('bda8d7e6-5761-11df-819c-000ae4cc0097', 'Nzima', '', 'nzi', NULL, NULL),
('bda8d854-5761-11df-819c-000ae4cc0097', 'Occitan (post 1500), Provençal', 'occitan', 'oci', 'oc', NULL),
('bda8d8cc-5761-11df-819c-000ae4cc0097', 'Ojibwa', 'ᐊᓂᔑᓇᐯᒧᐏᐣ', 'oji', 'oj', NULL),
('bda8d93a-5761-11df-819c-000ae4cc0097', 'Oriya', 'ଓଡ଼ିଆ', 'ori', 'or', NULL),
('bda8d9a8-5761-11df-819c-000ae4cc0097', 'Oromo', 'Afaan Oromoo', 'orm', 'om', NULL),
('bda8da16-5761-11df-819c-000ae4cc0097', 'Osage', '', 'osa', NULL, NULL),
('bda8da84-5761-11df-819c-000ae4cc0097', 'Ossetian, Ossetic', 'ирон ӕвзаг', 'oss', 'os', NULL),
('bda8dafc-5761-11df-819c-000ae4cc0097', 'Ottoman Turkish (1500–1928)', '', 'ota', NULL, NULL),
('bda8db74-5761-11df-819c-000ae4cc0097', 'Otomian languages', '', 'oto', NULL, NULL),
('bda8dbe2-5761-11df-819c-000ae4cc0097', 'Papuan languages', '', 'paa', NULL, NULL),
('bda8e5ba-5761-11df-819c-000ae4cc0097', 'Pangasinan', '', 'pag', NULL, NULL),
('bda8e632-5761-11df-819c-000ae4cc0097', 'Pahlavi (Middle Persian)', '', 'pal', NULL, NULL),
('bda8e6a0-5761-11df-819c-000ae4cc0097', 'Pampanga, Kapampangan', 'Kapampangan', 'pam', NULL, NULL),
('bda8e718-5761-11df-819c-000ae4cc0097', 'Punjabi, Panjabi', 'ਪੰਜਾਬੀ, <span style="direction:rtl">پنجابی</span>', 'pan', 'pa', NULL),
('bda8e790-5761-11df-819c-000ae4cc0097', 'Papiamento', 'Papiamentu', 'pap', NULL, NULL),
('bda8e7fe-5761-11df-819c-000ae4cc0097', 'Palauan', 'tekoi ra Belau', 'pau', NULL, NULL),
('bda8e86c-5761-11df-819c-000ae4cc0097', 'Persian', 'فارسی', 'per/fas', 'fa', NULL),
('bda8e952-5761-11df-819c-000ae4cc0097', 'Phoenician', '', 'phn', NULL, NULL),
('bda8e9c0-5761-11df-819c-000ae4cc0097', 'Pali', 'पालि', 'pli', 'pi', NULL),
('bda8ea2e-5761-11df-819c-000ae4cc0097', 'Polish', 'polski', 'pol', 'pl', NULL),
('bda8ea9c-5761-11df-819c-000ae4cc0097', 'Pohnpeian', '', 'pon', NULL, NULL),
('bda8eb14-5761-11df-819c-000ae4cc0097', 'Portuguese', 'português', 'por', 'pt', NULL),
('bda8eb82-5761-11df-819c-000ae4cc0097', 'Prakrit languages', '', 'pra', NULL, NULL),
('bda8ebf0-5761-11df-819c-000ae4cc0097', 'Pushto, Pashto', 'پښت', 'pus', 'ps', NULL),
('bda8ec5e-5761-11df-819c-000ae4cc0097', 'Quechua', 'Runa Simi, Kichwa', 'que', 'qu', NULL),
('bda8ecd6-5761-11df-819c-000ae4cc0097', 'Rajasthani', 'राजस्थानी', 'raj', NULL, NULL),
('bda8ed44-5761-11df-819c-000ae4cc0097', 'Rapanui', 'rapanui, pepito ote henua', 'rap', NULL, NULL),
('bda8edb2-5761-11df-819c-000ae4cc0097', 'Rarotongan, Cook Islands Maori', '', 'rar', NULL, NULL),
('bda8ee34-5761-11df-819c-000ae4cc0097', 'Romance languages', '', 'roa', NULL, NULL),
('bda8eea2-5761-11df-819c-000ae4cc0097', 'Romansh', 'rumantsch grischun', 'roh', 'rm', NULL),
('bda8ef1a-5761-11df-819c-000ae4cc0097', 'Romany', 'romani ćhib, Romani šib, Romanó', 'rom', NULL, NULL),
('bda8ef88-5761-11df-819c-000ae4cc0097', 'Romanian, Moldavian, Moldovan', 'română', 'rum/ron', 'ro', NULL),
('bda8f000-5761-11df-819c-000ae4cc0097', 'Rundi', 'kiRundi', 'run', 'rn', NULL),
('bda8f064-5761-11df-819c-000ae4cc0097', 'Aromanian, Arumanian, Macedo-Romanian', 'Armãneashce, Armãneashti, Limba armãneascã', 'rup', NULL, NULL),
('bda8f0e6-5761-11df-819c-000ae4cc0097', 'Russian', 'русский язык', 'rus', 'ru', NULL),
('bda8f154-5761-11df-819c-000ae4cc0097', 'Sandawe', '', 'sad', NULL, NULL),
('bda8f1c2-5761-11df-819c-000ae4cc0097', 'Sango', 'yângâ tî sängö', 'sag', 'sg', NULL),
('bda8f230-5761-11df-819c-000ae4cc0097', 'Yakut', 'Саха тыла', 'sah', NULL, NULL),
('bda8f302-5761-11df-819c-000ae4cc0097', 'South American Indian languages', '', 'sai', NULL, NULL),
('bda8f384-5761-11df-819c-000ae4cc0097', 'Salishan languages', '', 'sal', NULL, NULL),
('bda8f3f2-5761-11df-819c-000ae4cc0097', 'Samaritan Aramaic', '<span style="direction:rtl">ארמית, ܐܪܡܝܐ</span>', 'sam', NULL, NULL),
('bda8f46a-5761-11df-819c-000ae4cc0097', 'Sanskrit', 'संस्कृतम्', 'san', 'sa', NULL),
('bda8f4e2-5761-11df-819c-000ae4cc0097', 'Sasak', '', 'sas', NULL, NULL),
('bda900e0-5761-11df-819c-000ae4cc0097', 'Santali', 'संथाली', 'sat', NULL, NULL),
('bda90158-5761-11df-819c-000ae4cc0097', 'Serbian', 'српски језик', 'scc/srp', 'sr', NULL),
('bda901d0-5761-11df-819c-000ae4cc0097', 'Sicilian', 'Sicilianu', 'scn', NULL, NULL),
('bda9023e-5761-11df-819c-000ae4cc0097', 'Scots', 'Scoats leid, Lallans', 'sco', NULL, NULL),
('bda902ac-5761-11df-819c-000ae4cc0097', 'Croatian', 'hrvatski jezik', 'scr/hrv', 'hr', NULL),
('bda9031a-5761-11df-819c-000ae4cc0097', 'Selkup', 'шӧльӄумыт әты', 'sel', NULL, NULL),
('bda90388-5761-11df-819c-000ae4cc0097', 'Semitic languages', '', 'sem', NULL, NULL),
('bda903f6-5761-11df-819c-000ae4cc0097', 'Sign languages', '', 'sgn', NULL, NULL),
('bda9046e-5761-11df-819c-000ae4cc0097', 'Serbo-Croatian', 'Српскохрватски / Srpskohrvatski', 'hbs', 'sh', NULL),
('bda904dc-5761-11df-819c-000ae4cc0097', 'Shan', '', 'shn', NULL, NULL),
('bda90554-5761-11df-819c-000ae4cc0097', 'Sidamo', 'Sidámo/Afó', 'sid', NULL, NULL),
('bda905c2-5761-11df-819c-000ae4cc0097', 'Sinhalese, Sinhala', 'සිංහල', 'sin', 'si', NULL),
('bda90630-5761-11df-819c-000ae4cc0097', 'Siouan languages', '', 'sio', NULL, NULL),
('bda906a8-5761-11df-819c-000ae4cc0097', 'Sino-Tibetan languages', '', 'sit', NULL, NULL),
('bda90720-5761-11df-819c-000ae4cc0097', 'Slavic languages', '', 'sla', NULL, NULL),
('bda9078e-5761-11df-819c-000ae4cc0097', 'Slovak', 'slovenčina', 'slo/slk', 'sk', NULL),
('bda907fc-5761-11df-819c-000ae4cc0097', 'Slovenian', 'slovenščina', 'slv', 'sl', NULL),
('bda9086a-5761-11df-819c-000ae4cc0097', 'Southern Sami', 'saemien giele', 'sma', NULL, NULL),
('bda909f0-5761-11df-819c-000ae4cc0097', 'Northern Sami', 'sámi, sámegiella', 'sme', 'se', NULL),
('bda90a72-5761-11df-819c-000ae4cc0097', 'Sami languages', '', 'smi', NULL, NULL),
('bda90aea-5761-11df-819c-000ae4cc0097', 'Lule Sami', 'sámegiella', 'smj', NULL, NULL),
('bda90b62-5761-11df-819c-000ae4cc0097', 'Inari Sami', 'säämegiella', 'smn', NULL, NULL),
('bda90bda-5761-11df-819c-000ae4cc0097', 'Samoan', 'gagana fa''a Samoa', 'smo', 'sm', NULL),
('bda90c52-5761-11df-819c-000ae4cc0097', 'Skolt Sami', 'sääʼmǩiõll', 'sms', NULL, NULL),
('bda90cc0-5761-11df-819c-000ae4cc0097', 'Shona', 'chiShona', 'sna', 'sn', NULL),
('bda90d38-5761-11df-819c-000ae4cc0097', 'Sindhi', '<span style="direction:rtl">سنڌي، سندھی, सिन्धी</span>', 'snd', 'sd', NULL),
('bda90da6-5761-11df-819c-000ae4cc0097', 'Soninke', 'Soninkanxaane', 'snk', NULL, NULL),
('bda90e1e-5761-11df-819c-000ae4cc0097', 'Sogdian', '', 'sog', NULL, NULL),
('bda90e8c-5761-11df-819c-000ae4cc0097', 'Somali', 'Soomaaliga, af Soomaali', 'som', 'so', NULL),
('bda90f04-5761-11df-819c-000ae4cc0097', 'Songhai languages', '', 'son', NULL, NULL),
('bda90f7c-5761-11df-819c-000ae4cc0097', 'Southern Sotho', 'seSotho', 'sot', 'st', NULL),
('bda90fea-5761-11df-819c-000ae4cc0097', 'Spanish', 'español', 'spa', 'es', NULL),
('bda91062-5761-11df-819c-000ae4cc0097', 'Sardinian', 'sardu', 'srd', 'sc', NULL),
('bda910d0-5761-11df-819c-000ae4cc0097', 'Sranan Tongo', '', 'srn', NULL, NULL),
('bda91148-5761-11df-819c-000ae4cc0097', 'Serer', '', 'srr', NULL, NULL),
('bda911c0-5761-11df-819c-000ae4cc0097', 'Nilo-Saharan languages', '', 'ssa', NULL, NULL),
('bda91238-5761-11df-819c-000ae4cc0097', 'Swati', 'siSwati', 'ssw', 'ss', NULL),
('bda912a6-5761-11df-819c-000ae4cc0097', 'Sukuma', '', 'suk', NULL, NULL),
('bda9131e-5761-11df-819c-000ae4cc0097', 'Sundanese', 'basa Sunda', 'sun', 'su', NULL),
('bda9205c-5761-11df-819c-000ae4cc0097', 'Susu', '', 'sus', NULL, NULL),
('bda920de-5761-11df-819c-000ae4cc0097', 'Sumerian', 'eme-ĝir', 'sux', NULL, NULL),
('bda92156-5761-11df-819c-000ae4cc0097', 'Swahili', 'kiswahili', 'swa', 'sw', NULL),
('bda921c4-5761-11df-819c-000ae4cc0097', 'Swedish', 'svenska', 'swe', 'sv', NULL),
('bda92232-5761-11df-819c-000ae4cc0097', 'Classical Syriac', '', 'syc', NULL, NULL),
('bda922aa-5761-11df-819c-000ae4cc0097', 'Syriac', 'ܣܘܪܝܝܐ', 'syr', NULL, NULL),
('bda92322-5761-11df-819c-000ae4cc0097', 'Tahitian', 'te reo Tahiti, te reo Māʼohi', 'tah', 'ty', NULL),
('bda92390-5761-11df-819c-000ae4cc0097', 'Tai languages', '', 'tai', NULL, NULL),
('bda92408-5761-11df-819c-000ae4cc0097', 'Tamil', 'தமிழ்', 'tam', 'ta', NULL),
('bda92476-5761-11df-819c-000ae4cc0097', 'Tatar', 'татарча, tatarça, <span style="direction:rtl">تاتارچا</span>', 'tat', 'tt', NULL),
('bda924ee-5761-11df-819c-000ae4cc0097', 'Telugu', 'తెలుగు', 'tel', 'te', NULL),
('bda9255c-5761-11df-819c-000ae4cc0097', 'Timne', '', 'tem', NULL, NULL),
('bda925ca-5761-11df-819c-000ae4cc0097', 'Tereno', '', 'ter', NULL, NULL),
('bda92642-5761-11df-819c-000ae4cc0097', 'Tetum', 'Tetun', 'tet', NULL, NULL),
('bda926ba-5761-11df-819c-000ae4cc0097', 'Tajik', 'тоҷикӣ, <span style="direction:rtl">تاجیکی</span>', 'tgk', 'tg', NULL),
('bda92728-5761-11df-819c-000ae4cc0097', 'Tagalog', 'Tagalog', 'tgl', 'tl', NULL),
('bda92796-5761-11df-819c-000ae4cc0097', 'Thai', 'ภาษาไทย', 'tha', 'th', NULL),
('bda9280e-5761-11df-819c-000ae4cc0097', 'Tibetan', 'བོད་ཡིག', 'tib/bod', 'bo', NULL),
('bda9287c-5761-11df-819c-000ae4cc0097', 'Tigre', 'Tigré, Khasa', 'tig', NULL, NULL),
('bda928f4-5761-11df-819c-000ae4cc0097', 'Tigrinya', 'ትግርኛ', 'tir', 'ti', NULL),
('bda92962-5761-11df-819c-000ae4cc0097', 'Tiv', '', 'tiv', NULL, NULL),
('bda929d0-5761-11df-819c-000ae4cc0097', 'Tokelau', 'Tokelau', 'tkl', NULL, NULL),
('bda92a48-5761-11df-819c-000ae4cc0097', 'Klingon', 'tlhIngan Hol', 'tlh', NULL, NULL),
('bda92ab6-5761-11df-819c-000ae4cc0097', 'Tlingit', 'Lingít', 'tli', NULL, NULL),
('bda92b24-5761-11df-819c-000ae4cc0097', 'Tamashek', 'Tamajeq, ɫ[ǂ…', 'tmh', NULL, NULL),
('bda92b92-5761-11df-819c-000ae4cc0097', 'Tonga (Nyasa)', 'chiTonga', 'tog', NULL, NULL),
('bda92c0a-5761-11df-819c-000ae4cc0097', 'Tongan (Tonga Islands)', 'faka-Tonga', 'ton', 'to', NULL),
('bda92c78-5761-11df-819c-000ae4cc0097', 'Tok Pisin', 'Tok Pisin', 'tpi', NULL, NULL),
('bda92ce6-5761-11df-819c-000ae4cc0097', 'Tsimshian', '', 'tsi', NULL, NULL),
('bda92d5e-5761-11df-819c-000ae4cc0097', 'Tswana', 'seTswana', 'tsn', 'tn', NULL),
('bda92dd6-5761-11df-819c-000ae4cc0097', 'Tsonga', 'xiTsonga', 'tso', 'ts', NULL),
('bda92e44-5761-11df-819c-000ae4cc0097', 'Turkmen', 'Түркмен', 'tuk', 'tk', NULL),
('bda92eb2-5761-11df-819c-000ae4cc0097', 'Tumbuka', 'chiTumbuka', 'tum', NULL, NULL),
('bda92f20-5761-11df-819c-000ae4cc0097', 'Tupi languages', 'Nheengatu', 'tup', NULL, NULL),
('bda92f98-5761-11df-819c-000ae4cc0097', 'Turkish', 'Türkçe', 'tur', 'tr', NULL),
('bda93006-5761-11df-819c-000ae4cc0097', 'Altaic languages', '', 'tut', NULL, NULL),
('bda9307e-5761-11df-819c-000ae4cc0097', 'Tuvalu', 'gana Tuvalu', 'tvl', NULL, NULL),
('bda930ec-5761-11df-819c-000ae4cc0097', 'Twi', '', 'twi', 'tw', NULL),
('bda9315a-5761-11df-819c-000ae4cc0097', 'Tuvinian', 'тыва дыл', 'tyv', NULL, NULL),
('bda931d2-5761-11df-819c-000ae4cc0097', 'Udmurt', 'удмурт кыл', 'udm', NULL, NULL),
('bda93240-5761-11df-819c-000ae4cc0097', 'Ugaritic', '', 'uga', NULL, NULL),
('bda932b8-5761-11df-819c-000ae4cc0097', 'Uighur, Uyghur', 'Uyƣurqə, Uyğurçe, <span style="direction:rtl">ئۇيغۇرچ</span>', 'uig', 'ug', NULL),
('bda93330-5761-11df-819c-000ae4cc0097', 'Ukrainian', 'українська мова', 'ukr', 'uk', NULL),
('bda933a8-5761-11df-819c-000ae4cc0097', 'Umbundu', 'úmbúndú', 'umb', NULL, NULL),
('bda93416-5761-11df-819c-000ae4cc0097', 'Undetermined language', '', 'und', NULL, NULL),
('bda93542-5761-11df-819c-000ae4cc0097', 'Urdu', '<span style="direction:rtl">اردو</span>', 'urd', 'ur', NULL),
('bda935ba-5761-11df-819c-000ae4cc0097', 'Uzbek', 'O''zbek, Ўзбек, <span style="direction:rtl">أۇزبېك</span>', 'uzb', 'uz', NULL),
('bda93632-5761-11df-819c-000ae4cc0097', 'Vai', '', 'vai', NULL, NULL),
('bda9432a-5761-11df-819c-000ae4cc0097', 'Venda', 'tshiVenḓa', 'ven', 've', NULL),
('bda943a2-5761-11df-819c-000ae4cc0097', 'Vietnamese', 'Tiếng Việt', 'vie', 'vi', NULL),
('bda9441a-5761-11df-819c-000ae4cc0097', 'Volapük', 'Volapük', 'vol', 'vo', NULL),
('bda94488-5761-11df-819c-000ae4cc0097', 'Votic', 'vaďďa tšeeli', 'vot', NULL, NULL),
('bda944f6-5761-11df-819c-000ae4cc0097', 'Wakashan languages', '', 'wak', NULL, NULL),
('bda94578-5761-11df-819c-000ae4cc0097', 'Wolaitta, Wolaytta', '', 'wal', NULL, NULL),
('bda945f0-5761-11df-819c-000ae4cc0097', 'Waray', 'Winaray, Lineyte-Samarnon', 'war', NULL, NULL),
('bda9465e-5761-11df-819c-000ae4cc0097', 'Washo', '', 'was', NULL, NULL),
('bda946d6-5761-11df-819c-000ae4cc0097', 'Welsh', 'Cymraeg', 'wel/cym', 'cy', NULL),
('bda94744-5761-11df-819c-000ae4cc0097', 'Sorbian languages', '', 'wen', NULL, NULL),
('bda947bc-5761-11df-819c-000ae4cc0097', 'Walloon', 'walon', 'wln', 'wa', NULL),
('bda9482a-5761-11df-819c-000ae4cc0097', 'Wolof', 'Wolof', 'wol', 'wo', NULL),
('bda94898-5761-11df-819c-000ae4cc0097', 'Kalmyk, Oirat', 'хальмг келн', 'xal', NULL, NULL),
('bda94906-5761-11df-819c-000ae4cc0097', 'Xhosa', 'isiXhosa', 'xho', 'xh', NULL),
('bda9497e-5761-11df-819c-000ae4cc0097', 'Yao', '', 'yao', NULL, NULL),
('bda949ec-5761-11df-819c-000ae4cc0097', 'Yapese', '', 'yap', NULL, NULL),
('bda94a5a-5761-11df-819c-000ae4cc0097', 'Yiddish', '<span style="direction:rtl">ייִדיש</span>', 'yid', 'yi', NULL),
('bda94ad2-5761-11df-819c-000ae4cc0097', 'Yoruba', 'Yorùbá', 'yor', 'yo', NULL),
('bda94b40-5761-11df-819c-000ae4cc0097', 'Yupik languages', '', 'ypk', NULL, NULL),
('bda94bb8-5761-11df-819c-000ae4cc0097', 'Zapotec', '', 'zap', NULL, NULL),
('bda94c30-5761-11df-819c-000ae4cc0097', 'Blissymbols, Blissymbolics, Bliss ', '', 'zbl', NULL, NULL),
('bda94ca8-5761-11df-819c-000ae4cc0097', 'Zenaga', 'Tuḍḍungiyya', 'zen', NULL, NULL),
('bda94d16-5761-11df-819c-000ae4cc0097', 'Zhuang, Chuang', 'Saɯ cueŋƅ, Saw cuengh', 'zha', 'za', NULL),
('bda94d84-5761-11df-819c-000ae4cc0097', 'Zande languages', '', 'znd', NULL, NULL),
('bda94dfc-5761-11df-819c-000ae4cc0097', 'Zulu', 'isiZulu', 'zul', 'zu', NULL),
('bda94e6a-5761-11df-819c-000ae4cc0097', 'Zuni', 'Shiwi', 'zun', NULL, NULL),
('bda94ed8-5761-11df-819c-000ae4cc0097', 'no linguistic content, not applicable', '', 'zxx', NULL, NULL),
('bda94f5a-5761-11df-819c-000ae4cc0097', 'Zaza, Dimili, Dimli, Kirdki, Kirmanjki, Zazaki', '', 'zza', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `offices`
--

CREATE TABLE IF NOT EXISTS `offices` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `acronym` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `region` enum('EMEA','AMER','APAC') COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` enum('international','national','regional','local','ship','political','scientific','virtual') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'national',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `offices`
--

INSERT INTO `offices` (`id`, `parent_id`, `name`, `acronym`, `region`, `type`, `created`, `modified`) VALUES
('5d88fd44-59f7-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Malta', NULL, NULL, 'national', '2010-05-12 18:41:11', '2010-05-12 18:41:11'),
('5d88ffd8-59f7-11df-9ccf-000ae4cc0097', 'd1784e40-59ec-11df-9ccf-000ae4cc0097', 'Greenpeace Romania', NULL, NULL, 'national', '2010-05-12 18:41:11', '2010-05-12 18:41:11'),
('d1784666-59ec-11df-9ccf-000ae4cc0097', 'f375fcec-59d1-11df-9ccf-000ae4cc0097', 'Greenpeace Ireland', NULL, 'EMEA', 'virtual', '2010-05-07 14:13:23', '2010-05-07 14:13:26'),
('d1784706-59ec-11df-9ccf-000ae4cc0097', 'f375fcec-59d1-11df-9ccf-000ae4cc0097', 'Greenpeace Portugal', NULL, 'EMEA', 'virtual', '2010-05-07 14:13:23', '2010-05-07 14:13:26'),
('d1784792-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace EU Unit', 'GPEU', 'EMEA', 'political', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784814-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Research Laboratories', 'GPLAB', 'EMEA', 'scientific', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784896-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Africa', 'GPAFRIC', 'EMEA', 'regional', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784918-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Argentina', NULL, 'AMER', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178499a-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Australia Pacific', 'GPAUSPAC', 'APAC', 'regional', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784a1c-59ec-11df-9ccf-000ae4cc0097', 'd178499a-59ec-11df-9ccf-000ae4cc0097', 'Greenpeace Fiji', NULL, 'APAC', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784a94-59ec-11df-9ccf-000ae4cc0097', 'd178499a-59ec-11df-9ccf-000ae4cc0097', 'Greenpeace Papua New Guinea', 'GPPNG', 'APAC', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784b0c-59ec-11df-9ccf-000ae4cc0097', 'd178499a-59ec-11df-9ccf-000ae4cc0097', 'Greenpeace Solomon Islands', NULL, 'APAC', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784b84-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Belgium', 'GPBE', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784bez-59ec-11df-9ccf-000ae4cc0097', 'd1784bfc-59ec-11df-9ccf-000ae4cc0097', 'Amazon Office', 'Amazon', 'AMER', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784bfc-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Brazil', 'GPBR', 'AMER', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784c6a-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Canada', 'GPCA', 'AMER', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784ce2-59ec-11df-9ccf-000ae4cc0097', 'd1784c6a-59ec-11df-9ccf-000ae4cc0097', 'Edmonton Office', NULL, 'AMER', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784d50-59ec-11df-9ccf-000ae4cc0097', 'd1784c6a-59ec-11df-9ccf-000ae4cc0097', 'Montreal Office', NULL, 'AMER', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784dc8-59ec-11df-9ccf-000ae4cc0097', 'd1784c6a-59ec-11df-9ccf-000ae4cc0097', 'Vancouver Office', NULL, 'AMER', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784e40-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Central And Eastern Europe (Austria)', 'GPCEE', 'EMEA', 'regional', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1784eb8-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Hungary', NULL, 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17851ec-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Poland', NULL, 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178526e-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Slovakia', NULL, 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17852e6-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Slovenia', NULL, 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1785354-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Chile', NULL, 'AMER', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17853c2-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace China (Hong-Kong)', 'GPCN', 'APAC', 'regional', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178543a-59ec-11df-9ccf-000ae4cc0097', 'd178543a-59ec-11df-9ccf-000ae4cc0097', 'Beijing Office', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17854b2-59ec-11df-9ccf-000ae4cc0097', 'd178543a-59ec-11df-9ccf-000ae4cc0097', 'Guangzhou Unit', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178552a-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Czech Republic', 'GPCZ', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1785598-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace France', 'GPFR', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1785610-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Germany', 'GPDE', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178567e-59ec-11df-9ccf-000ae4cc0097', 'd1785610-59ec-11df-9ccf-000ae4cc0097', 'Berlin Political Office', NULL, 'EMEA', 'political', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17856f6-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Greece', NULL, 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178576e-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace India (Bangalore)', NULL, 'APAC', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1785854-59ec-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'Chandigarh Office', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17858cc-59ec-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'Chennai Office', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178593a-59ec-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'Delhi Office', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17859b2-59ec-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'Hyderabad Office', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1785a2a-59ec-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'Kolkata Office', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1785a98-59ec-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'Mumbai Office', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1786042-59ec-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'Navi Mumbai Office', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17860c4-59ec-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'Noida Office ', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178613c-59ec-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'Pune Office', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17861aa-59ec-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'Cochin Office', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1786222-59ec-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'Goa Office', NULL, 'APAC', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178629a-59ec-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'Ahmedabad Office', NULL, NULL, 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1786308-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Italy', NULL, 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1786376-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Japan', 'GPJ', 'APAC', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17863ee-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Luxembourg', 'GPLUX', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1786466-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Israel', 'GPMED', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17864d4-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Lebanon', 'GPMED', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178654c-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Mediterranean (Turkey)', 'GPMED', 'EMEA', 'regional', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17865c4-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Mexico', NULL, 'AMER', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1786632-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Netherlands', 'GPN', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17866aa-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace New Zealand', 'GPNZ', 'APAC', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1786722-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Nordic (Sweden)', 'GP Nordic', 'EMEA', 'regional', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1786790-59ec-11df-9ccf-000ae4cc0097', 'd1786722-59ec-11df-9ccf-000ae4cc0097', 'Greenpeace Denmark', 'GP Nordic', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1786808-59ec-11df-9ccf-000ae4cc0097', 'd1786722-59ec-11df-9ccf-000ae4cc0097', 'Greenpeace Finland', 'GP Nordic', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1786876-59ec-11df-9ccf-000ae4cc0097', 'd1786722-59ec-11df-9ccf-000ae4cc0097', 'Greenpeace Norway', 'GP Nordic', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17868ee-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Portugal', NULL, 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178695c-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Russia', NULL, 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17870c8-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace SEA (Thailand)', 'GPSEA', 'APAC', 'regional', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178714a-59ec-11df-9ccf-000ae4cc0097', 'd17870c8-59ec-11df-9ccf-000ae4cc0097', 'Greenpeace Indonesia', 'GPSEA', 'APAC', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17871c2-59ec-11df-9ccf-000ae4cc0097', 'd17870c8-59ec-11df-9ccf-000ae4cc0097', 'Greenpeace Philippines', 'GPSEA', 'APAC', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178723a-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Spain', 'GPSPAIN', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17872a8-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Switzerland', 'GPSWISS', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1787320-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace United Kingdom', 'GPUK', 'EMEA', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178738e-59ec-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace Usa', 'GPUSA', 'AMER', 'national', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1787406-59ec-11df-9ccf-000ae4cc0097', 'd178738e-59ec-11df-9ccf-000ae4cc0097', 'San Franciso Office', 'GPSF', 'AMER', 'local', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d1787474-59ec-11df-9ccf-000ae4cc0097', 'f375fcec-59d1-11df-9ccf-000ae4cc0097', 'Rainbow Warrior II', 'RWII', NULL, 'ship', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17874ec-59ec-11df-9ccf-000ae4cc0097', 'f375fcec-59d1-11df-9ccf-000ae4cc0097', 'MV Esperanza', NULL, NULL, 'ship', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d178755a-59ec-11df-9ccf-000ae4cc0097', 'f375fcec-59d1-11df-9ccf-000ae4cc0097', 'Artic Sunrise', NULL, NULL, 'ship', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('d17875c8-59ec-11df-9ccf-000ae4cc0097', 'f375fcec-59d1-11df-9ccf-000ae4cc0097', 'Rainbow Warrior III', 'RWIII', NULL, 'ship', '2010-05-07 17:25:50', '2010-05-07 17:25:50'),
('f375fcec-59d1-11df-9ccf-000ae4cc0097', NULL, 'Greenpeace International', 'GPI', 'EMEA', 'international', '2010-05-07 14:13:23', '2010-05-07 14:13:26');

-- --------------------------------------------------------

--
-- Table structure for table `offices_languages`
--

CREATE TABLE IF NOT EXISTS `offices_languages` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `office_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `language_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `offices_languages`
--

INSERT INTO `offices_languages` (`id`, `office_id`, `language_id`) VALUES
('02501a9e-59f1-11df-9ccf-000ae4cc0097', 'd1784918-59ec-11df-9ccf-000ae4cc0097', 'bda90fea-5761-11df-819c-000ae4cc0097'),
('02501cb0-59f1-11df-9ccf-000ae4cc0097', 'd17865c4-59ec-11df-9ccf-000ae4cc0097', 'bda90fea-5761-11df-819c-000ae4cc0097'),
('28ba8186-59f8-11df-9ccf-000ae4cc0097', 'd178526e-59ec-11df-9ccf-000ae4cc0097', 'bda9078e-5761-11df-819c-000ae4cc0097'),
('2e0fd652-59f0-11df-9ccf-000ae4cc0097', 'd1785598-59ec-11df-9ccf-000ae4cc0097', 'bda812a2-5761-11df-819c-000ae4cc0097'),
('36aac20e-59f5-11df-9ccf-000ae4cc0097', 'd17871c2-59ec-11df-9ccf-000ae4cc0097', 'bda92728-5761-11df-819c-000ae4cc0097'),
('384ff822-59f5-11df-9ccf-000ae4cc0097', 'd17871c2-59ec-11df-9ccf-000ae4cc0097', 'bda810f4-5761-11df-819c-000ae4cc0097'),
('384ffa34-59f5-11df-9ccf-000ae4cc0097', 'd17871c2-59ec-11df-9ccf-000ae4cc0097', 'bda80d48-5761-11df-819c-000ae4cc0097'),
('3dafc3bc-59f8-11df-9ccf-000ae4cc0097', 'd1784eb8-59ec-11df-9ccf-000ae4cc0097', 'bda845f6-5761-11df-819c-000ae4cc0097'),
('4368d2aa-59f1-11df-9ccf-000ae4cc0097', 'd1784896-59ec-11df-9ccf-000ae4cc0097', 'bda812a2-5761-11df-819c-000ae4cc0097'),
('4368d4c6-59f1-11df-9ccf-000ae4cc0097', 'd17863ee-59ec-11df-9ccf-000ae4cc0097', 'bda812a2-5761-11df-819c-000ae4cc0097'),
('467f9e3c-59f2-11df-9ccf-000ae4cc0097', 'd1785354-59ec-11df-9ccf-000ae4cc0097', 'bda90fea-5761-11df-819c-000ae4cc0097'),
('467fa08a-59f2-11df-9ccf-000ae4cc0097', 'd178654c-59ec-11df-9ccf-000ae4cc0097', 'bda92f98-5761-11df-819c-000ae4cc0097'),
('4803e9f4-59f0-11df-9ccf-000ae4cc0097', 'f375fcec-59d1-11df-9ccf-000ae4cc0097', 'bda80d48-5761-11df-819c-000ae4cc0097'),
('4cfc6cfc-59f4-11df-9ccf-000ae4cc0097', 'd17853c2-59ec-11df-9ccf-000ae4cc0097', '87dd54e6-5781-11df-819c-000ae4cc0097'),
('4cfc6f18-59f4-11df-9ccf-000ae4cc0097', 'd17853c2-59ec-11df-9ccf-000ae4cc0097', 'bda7e4b2-5761-11df-819c-000ae4cc0097'),
('5cf6bbd4-59f5-11df-9ccf-000ae4cc0097', 'd178714a-59ec-11df-9ccf-000ae4cc0097', 'bda86f68-5761-11df-819c-000ae4cc0097'),
('645bc544-59f1-11df-9ccf-000ae4cc0097', 'd1786308-59ec-11df-9ccf-000ae4cc0097', 'bda87ae4-5761-11df-819c-000ae4cc0097'),
('6668e274-59f4-11df-9ccf-000ae4cc0097', 'd178576e-59ec-11df-9ccf-000ae4cc0097', 'bda80d48-5761-11df-819c-000ae4cc0097'),
('8114ded0-59f3-11df-9ccf-000ae4cc0097', 'd178695c-59ec-11df-9ccf-000ae4cc0097', 'bda8f0e6-5761-11df-819c-000ae4cc0097'),
('82a2355c-59f5-11df-9ccf-000ae4cc0097', 'd178552a-59ec-11df-9ccf-000ae4cc0097', 'bda7f81c-5761-11df-819c-000ae4cc0097'),
('8a31408e-59f4-11df-9ccf-000ae4cc0097', 'd17870c8-59ec-11df-9ccf-000ae4cc0097', 'bda80d48-5761-11df-819c-000ae4cc0097'),
('8a3142d2-59f4-11df-9ccf-000ae4cc0097', 'd17870c8-59ec-11df-9ccf-000ae4cc0097', 'bda92796-5761-11df-819c-000ae4cc0097'),
('949da2fe-59f1-11df-9ccf-000ae4cc0097', 'd1784706-59ec-11df-9ccf-000ae4cc0097', 'bda8eb14-5761-11df-819c-000ae4cc0097'),
('949da51a-59f1-11df-9ccf-000ae4cc0097', 'd1784bfc-59ec-11df-9ccf-000ae4cc0097', 'bda8eb14-5761-11df-819c-000ae4cc0097'),
('989ebe9a-59f8-11df-9ccf-000ae4cc0097', 'd1784e40-59ec-11df-9ccf-000ae4cc0097', 'bda826f2-5761-11df-819c-000ae4cc0097'),
('98a4c694-59f5-11df-9ccf-000ae4cc0097', 'bda8ea2e-5761-11df-819c-000ae4cc0097', 'd17851ec-59ec-11df-9ccf-000ae4cc0097'),
('9ff22f38-59f8-11df-9ccf-000ae4cc0097', '5d88ffd8-59f7-11df-9ccf-000ae4cc0097', 'bda8ef88-5761-11df-819c-000ae4cc0097'),
('ab81d6dc-59f3-11df-9ccf-000ae4cc0097', 'd17863ee-59ec-11df-9ccf-000ae4cc0097', 'bda89c18-5761-11df-819c-000ae4cc0097'),
('ab81d90c-59f3-11df-9ccf-000ae4cc0097', 'd17863ee-59ec-11df-9ccf-000ae4cc0097', 'bda80d48-5761-11df-819c-000ae4cc0097'),
('ab81d98e-59f3-11df-9ccf-000ae4cc0097', 'd17863ee-59ec-11df-9ccf-000ae4cc0097', 'bda826f2-5761-11df-819c-000ae4cc0097'),
('b3852292-59f0-11df-9ccf-000ae4cc0097', 'd178723a-59ec-11df-9ccf-000ae4cc0097', 'bda90fea-5761-11df-819c-000ae4cc0097'),
('b3852530-59f0-11df-9ccf-000ae4cc0097', 'd1786376-59ec-11df-9ccf-000ae4cc0097', 'bda87c24-5761-11df-819c-000ae4cc0097'),
('ccd4287c-59f2-11df-9ccf-000ae4cc0097', 'd1786466-59ec-11df-9ccf-000ae4cc0097', 'bda8420e-5761-11df-819c-000ae4cc0097'),
('ccd42aca-59f2-11df-9ccf-000ae4cc0097', 'd17864d4-59ec-11df-9ccf-000ae4cc0097', 'bda7c0d6-5761-11df-819c-000ae4cc0097'),
('cea26822-59f1-11df-9ccf-000ae4cc0097', 'd1784666-59ec-11df-9ccf-000ae4cc0097', 'bda80d48-5761-11df-819c-000ae4cc0097'),
('cea26a48-59f1-11df-9ccf-000ae4cc0097', 'd1784666-59ec-11df-9ccf-000ae4cc0097', 'bda828aa-5761-11df-819c-000ae4cc0097'),
('dfdf97c0-59f3-11df-9ccf-000ae4cc0097', 'd17856f6-59ec-11df-9ccf-000ae4cc0097', 'bda83502-5761-11df-819c-000ae4cc0097');

-- --------------------------------------------------------

--
-- Table structure for table `offices_projects`
--

CREATE TABLE IF NOT EXISTS `offices_projects` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `commitment` enum('sure','not first','maybe','unlikely') COLLATE utf8_unicode_ci DEFAULT NULL,
  `pilot` tinyint(4) DEFAULT NULL,
  `office_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `project_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `offices_projects`
--

INSERT INTO `offices_projects` (`id`, `commitment`, `pilot`, `office_id`, `project_id`) VALUES
('932f009c-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, '5d88ffd8-59f7-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f02d6-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd1784666-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f034e-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd1784706-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f03b2-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd1784896-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0416-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd1784918-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f047a-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd1784bfc-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f04e8-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd1784e40-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f057e-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd1784eb8-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f05ec-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd17851ec-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0646-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd1785354-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f06aa-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd17853c2-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0704-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd178552a-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0768-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd1785598-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f07c2-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd17856f6-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0826-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd178576e-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f088a-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd1786308-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f08e4-59fc-11df-9ccf-000ae4cc0097', 'not first', 0, 'd1786376-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0948-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd17863ee-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f09ac-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd17864d4-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0cea-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd178654c-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0d4e-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd17865c4-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0db2-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd17868ee-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0e0c-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd178695c-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0e70-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd17870c8-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0eca-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd178714a-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0f2e-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd17871c2-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0f92-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'd178723a-59ec-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('932f0fec-59fc-11df-9ccf-000ae4cc0097', 'sure', 0, 'f375fcec-59d1-11df-9ccf-000ae4cc0097', '7f0f593c-4ee8-11df-bb97-000ae4cc0097'),
('eb0d238a-59fb-11df-9ccf-000ae4cc0097', NULL, 0, 'eb0d23f8-59fb-11df-9ccf-000ae4cc0097', 'eb0d240c-59fb-11df-9ccf-000ae4cc0097'),
('f845b260-59fb-11df-9ccf-000ae4cc0097', 'sure', 1, 'f845b2ba-59fb-11df-9ccf-000ae4cc0097', 'f845b2ce-59fb-11df-9ccf-000ae4cc0097');

-- --------------------------------------------------------

--
-- Table structure for table `offices_requirements`
--

CREATE TABLE IF NOT EXISTS `offices_requirements` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `office_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `requirement_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `priority` enum('must have','should have','could have','would like') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `offices_requirements`
--


-- --------------------------------------------------------

--
-- Table structure for table `office_groups`
--

CREATE TABLE IF NOT EXISTS `office_groups` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `acronym` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` tinyint(4) NOT NULL COMMENT '1=Global, 2=International, 3=National, 4=Regional, etc.',
  `head_office_id` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `office_groups`
--

INSERT INTO `office_groups` (`id`, `name`, `acronym`, `level`, `head_office_id`, `created`, `modified`) VALUES
('14beddf0-59e2-11df-9ccf-000ae4cc0097', 'Central and Eastern Europe', 'CEE', 2, NULL, '2010-05-07 16:08:25', '2010-05-07 16:08:25'),
('14bee08e-59e2-11df-9ccf-000ae4cc0097', 'Germany', NULL, 3, NULL, '2010-05-07 16:08:25', '2010-05-07 16:08:25'),
('5d2b90ce-59e2-11df-9ccf-000ae4cc0097', 'United States', 'USA', 3, NULL, '2010-05-07 16:10:34', '2010-05-07 16:10:36'),
('5d2b9326-59e2-11df-9ccf-000ae4cc0097', 'China', NULL, 3, NULL, '2010-05-07 16:10:45', '2010-05-07 16:10:48'),
('75fb4570-59b7-11df-9ccf-000ae4cc0097', 'International', 'GPI', 1, NULL, '2010-05-07 11:03:37', '2010-05-07 11:03:37'),
('75fc45b0-59b7-11df-9ccf-000ae4cc0097', 'Mediteranee', 'MED', 2, NULL, '2010-05-07 11:03:37', '2010-05-07 11:03:37'),
('75fc4790-59b7-11df-9ccf-000ae4cc0097', 'South East Asia', 'SEA', 2, NULL, '2010-05-07 11:03:37', '2010-05-07 11:03:37'),
('75fc48bc-59b7-11df-9ccf-000ae4cc0097', 'Australia Pacific', 'AUSPAC', 2, NULL, '2010-05-07 11:03:37', '2010-05-07 11:03:37'),
('75fc49f2-59b7-11df-9ccf-000ae4cc0097', 'Nordic', 'Nordic', 2, NULL, '2010-05-07 11:03:37', '2010-05-07 11:03:37');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE IF NOT EXISTS `payment_methods` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `name`, `created`, `modified`) VALUES
('55fe97a4-520a-11df-952d-000ae4cc0097', 'credit card', '2010-04-27 16:35:40', '2010-04-27 16:35:40'),
('55fe9a10-520a-11df-952d-000ae4cc0097', 'debit card', '2010-04-27 16:35:40', '2010-04-27 16:35:40'),
('8152176e-520a-11df-952d-000ae4cc0097', 'cheque', '2010-04-27 16:35:40', '2010-04-27 16:35:40'),
('8152198a-520a-11df-952d-000ae4cc0097', 'giro', '2010-04-27 16:35:40', '2010-04-27 16:35:40'),
('81521a0c-520a-11df-952d-000ae4cc0097', 'standing orders', '2010-04-27 16:35:40', '2010-04-27 16:35:40'),
('81521a84-520a-11df-952d-000ae4cc0097', 'premium sms', '2010-04-27 16:35:40', '2010-04-27 16:35:40'),
('81521af2-520a-11df-952d-000ae4cc0097', 'cash', '2010-04-27 16:35:40', '2010-04-27 16:35:40'),
('81521b88-520a-11df-952d-000ae4cc0097', 'in-kind', '2010-04-27 16:35:40', '2010-04-27 16:35:40');

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE IF NOT EXISTS `people` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `fname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `salutation` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `people`
--

INSERT INTO `people` (`id`, `fname`, `lname`, `salutation`, `title`) VALUES
('5fbdd0d2-72ff-11df-a593-000ae4cc0097', 'remy', 'bertot', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `phones`
--

CREATE TABLE IF NOT EXISTS `phones` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `foreign_key` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `number` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('landline','mobile','fax') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'landline',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `phones`
--

INSERT INTO `phones` (`id`, `foreign_key`, `model`, `number`, `type`, `created`, `modified`) VALUES
('a1f0feca-59d7-11df-9ccf-000ae4cc0097', 'f375fcec-59d1-11df-9ccf-000ae4cc0097', 'offices', '+31 20 718 2000', 'landline', '2010-05-07 14:53:54', '2010-05-07 14:53:54'),
('a1f10172-59d7-11df-9ccf-000ae4cc0097', 'f375fcec-59d1-11df-9ccf-000ae4cc0097', 'offices', '+31 20 718 2002', 'fax', '2010-05-07 14:53:54', '2010-05-07 14:53:54');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `archived` tinyint(1) NOT NULL,
  `completed` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `name`, `description`, `archived`, `completed`, `created`, `modified`) VALUES
('4c174cdc-d134-4733-804f-050dae790e16', 'White Rabbit', 'This is dead rabbit... with a very very long description that doesn''t really mean anything but that makes me happy because I can test text-overflow stuffs.', 0, 0, '2010-06-15 11:50:20', '2010-07-15 17:23:35'),
('7f0f593c-4ee8-11df-bb97-000ae4cc0097', 'Boost!', '<strong>Test</strong>', 1, 0, '2010-04-23 16:56:57', '2010-07-06 18:06:50'),
('7f0f5db0-4ee8-11df-bb97-000ae4cc0097', 'Planet3', NULL, 0, 0, '2010-04-23 16:56:57', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `requirements`
--

CREATE TABLE IF NOT EXISTS `requirements` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `requirements`
--

INSERT INTO `requirements` (`id`, `parent_id`, `serial`, `name`, `description`, `created`, `modified`) VALUES
('1d2a031c-5211-11df-952d-000ae4cc0097', NULL, '1.0.0', 'General Functionality', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a0736-5211-11df-952d-000ae4cc0097', '1d2a30c6-5211-11df-952d-000ae4cc0097', '4.4.0', 'Workflow', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a09c0-5211-11df-952d-000ae4cc0097', '1d2a031c-5211-11df-952d-000ae4cc0097', '1.1.0', 'Ease of Use', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a0c40-5211-11df-952d-000ae4cc0097', '1d2a031c-5211-11df-952d-000ae4cc0097', '1.2.0', 'Flexibility', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a0f38-5211-11df-952d-000ae4cc0097', '1d2a031c-5211-11df-952d-000ae4cc0097', '1.3.0', 'Data Maintenance', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a11ae-5211-11df-952d-000ae4cc0097', '1d2a031c-5211-11df-952d-000ae4cc0097', '1.4.0', 'Data Integrity', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a1460-5211-11df-952d-000ae4cc0097', '1d2a031c-5211-11df-952d-000ae4cc0097', '1.5.0', 'Document Management', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a1712-5211-11df-952d-000ae4cc0097', '1d2a031c-5211-11df-952d-000ae4cc0097', '1.6.0', 'Documentation', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a199c-5211-11df-952d-000ae4cc0097', NULL, '2.0.0', 'Fundraising', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a1c94-5211-11df-952d-000ae4cc0097', '1d2a199c-5211-11df-952d-000ae4cc0097', '2.1.0', 'Direct Dialogue/Sustainers', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a1f0a-5211-11df-952d-000ae4cc0097', '1d2a199c-5211-11df-952d-000ae4cc0097', '2.2.0', 'Major Gifts/Foundations', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a2194-5211-11df-952d-000ae4cc0097', '1d2a199c-5211-11df-952d-000ae4cc0097', '2.3.0', 'Volunteer Management', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a2432-5211-11df-952d-000ae4cc0097', '1d2a199c-5211-11df-952d-000ae4cc0097', '2.4.0', 'Events', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a26c6-5211-11df-952d-000ae4cc0097', NULL, '3.0.0', 'Supporter Relations', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a2932-5211-11df-952d-000ae4cc0097', '1d2a26c6-5211-11df-952d-000ae4cc0097', '3.1.0', 'Supporter Activity', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a2b94-5211-11df-952d-000ae4cc0097', '1d2a26c6-5211-11df-952d-000ae4cc0097', '3.2.0', 'Supporter Communication', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a2e64-5211-11df-952d-000ae4cc0097', '1d2a26c6-5211-11df-952d-000ae4cc0097', '3.3.0', 'Supporter Services', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a30c6-5211-11df-952d-000ae4cc0097', NULL, '4.0.0', 'Marketing', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a3328-5211-11df-952d-000ae4cc0097', '1d2a30c6-5211-11df-952d-000ae4cc0097', '4.1.0', 'Campaign Management', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a35f8-5211-11df-952d-000ae4cc0097', '1d2a30c6-5211-11df-952d-000ae4cc0097', '4.2.0', 'Direct Marketing', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('1d2a3882-5211-11df-952d-000ae4cc0097', '1d2a30c6-5211-11df-952d-000ae4cc0097', '4.3.0', 'Segmentations', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12ee55c-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.1', 'Customizable Views of the supporter record', 'System allows for customizable views, e.g. one person wants to view the constituent as a volunteer, another as a Direct Dialogue donor, another as a major gift prospects, that could be created by a GPI developer.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12ee64c-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.2', 'Cut/Paste', 'Has the ability to copy/cut/paste from desktop applications to and from any text field in the system, including name/address and retain formatting.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12ee71e-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.3', 'Reminders at Start-Up', 'System displays a "to-do" list for each user at sign-on.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12ee7e6-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.4', 'Dashboard', 'Desktop dashboards are provided and can be customized by user, or user group.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12ee890-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.5', 'Former Staff', 'Database can track former staff and solicitors for an account.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12ee93a-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.6', 'Minimal Training Required', 'Basic tasks are self-explanatory and can be performed with minimal training.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12ee9ee-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.7', 'Multiple Open Records', 'Able to have more than one record open at a time and toggle back and forth between records.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12eea98-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.8', 'Search & Retrieve Function', 'Ability to search and retrieve a record by any name, bank account, credit card number and address as a minimum', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12eecbe-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.9', 'OpenOffice Mail Integration', 'Provides email integration based on open protocols (ex: IMAP/POP,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12eed9a-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.1', 'Phonetic Search', 'Supports a phonetic search, such as Soundex (e.g. Smith will also find Smythe,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12eeea8-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.1', 'Quick Fill', 'Table look-up fields support "quick fill" with a user preference to enable/disable.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12eef84-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.1', 'Table Lookups', 'All codes fields have ''pop-up'' table lookups with incremental search that supports entering more than one character.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12ef060-52a5-11df-84e5-000ae4cc0097', '1d2a09c0-5211-11df-952d-000ae4cc0097', '1.1.1', 'Wildcards', 'Supports searches with wildcards in any part of the search string.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12ef1fa-52a5-11df-84e5-000ae4cc0097', '1d2a0c40-5211-11df-952d-000ae4cc0097', '1.2.1', 'Add Columns', 'Data structure would allow GP to add additional columns to an existing table.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12ef308-52a5-11df-84e5-000ae4cc0097', '1d2a0c40-5211-11df-952d-000ae4cc0097', '1.2.2', 'Additional Fields', 'An individual NRO will have the ability to define up to 20 additional fields, that will be supported for on-screen entry, batch upload, query and reporting.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12ef416-52a5-11df-84e5-000ae4cc0097', '1d2a0c40-5211-11df-952d-000ae4cc0097', '1.2.3', 'Customizable User Interface', 'Customizable User Interface (GP logo but no vendor logo, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f02ee-52a5-11df-84e5-000ae4cc0097', '1d2a0c40-5211-11df-952d-000ae4cc0097', '1.2.4', 'Customized Screens', 'An NRO can alter the list of fields on data entry screens, as well as their appearance and the order in which they are visited.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f042e-52a5-11df-84e5-000ae4cc0097', '1d2a0c40-5211-11df-952d-000ae4cc0097', '1.2.5', 'End-User Extracts', 'The end-user has the ability to create data extracts, with the contents (fields and sequence,NOW(),NOW()) in either CSV or fixed record length format, without a knowledge of programming or SQL.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f0668-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.1', 'Address Parsing', 'International addresses are parsed into separate fields, appropriate to that country, to facilitate searching and sorting (e.g. all accounts in the same County in the UK, or with the same building name in Hong Kong, or on the same street in Spain,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f078a-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.2', 'Two Addresses', 'Maintains a minimum of two active addresses, retaining date updated, start/end dates, and fields indicating when a particular address is to be used.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f0898-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.3', 'Address History', 'An unlimited number of former addresses with the date can be retained in history.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f09ba-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.4', 'Automatic ID Creation', 'New IDs can be automatically generated.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f0ae6-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.5', 'Automatic Salutations', 'A default salutation is automatically generated based on user-defined rules.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f0c1c-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.6', 'Bar Code Scanning', 'System provides support for scanning bar codes on returned mail and directly retrieving the record.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f0cee-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.7', 'Behavior Tracking', 'Can display user behavior, either quantitative (origin, bounce rate, UV, etc. ,NOW(),NOW()) or qualitative (their level of passion for a cause, or effectiveness as a volunteer,NOW(),NOW()) on a demographic base (age, gender, Activism level, FR level, etc,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f0de8-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.8', 'Birthdate Source', 'System captures when, and how, a birth date was obtained.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f0eb0-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.9', 'Comments Everywhere', 'Multiple comments allowed on account, prospect tracking, and transaction records.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f0f82-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.1', 'Searchable Text Fields', 'Unlimited comment fields, of unlimited length, that are searchable.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f1216-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.1', 'Core Information', 'Fundraisers can directly enter and view organization contacts, funding interests, and contact reports.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f132e-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.1', 'Data Overlays', 'System supports the import and appending of geographic, demographic, and socioeconomic indicators.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f140a-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.1', 'Demographic Data', 'Has the ability to collect comprehensive demographic data such as birthdate, spouse name, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f1522-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.1', 'Demographic Data Source', 'For demographic data that is captured the system provides a mechanism to identify the source of the information (verbal, data overlay,NOW(),NOW()), and the date it was obtained.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f161c-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.1', 'Do Not Merge', 'Records can be marked as "Do Not Merge" to prevent detection by duplicate checking routines.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f16f8-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.1', 'E-mail Address', 'An unlimited number of e-mail addresses can be tracked for each supporter.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f17d4-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.1', 'Email Address Independent', 'Email addresses do not need to be linked to postal addresses.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f3566-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.1', 'Email Address Source', 'Each email address captures when, and how, it was obtained.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f364c-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.1', 'Global Updates', 'Ability to globally update data based on a search.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f371e-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.2', 'Heads-down Entry', 'Supports rapid data entry (also called heads-down entry,NOW(),NOW()) without the need to touch a mouse. ', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f37fa-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.2', 'Mapping Software', 'System provides integrated mapping software (e.g. Google Map,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f38d6-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.2', 'Merged ID Numbers', 'Has the ability to search on ID''s that have been merged into another record.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f39a8-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.2', 'Valid records on single data source', 'Records can be set up using a single data source e.g. telephone number, twitter account, email address and be validated against the existing database', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f3a8e-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.2', 'Multiple Credit/Debit Cards', 'System can store a minimum of two Credit or Debit card numbers for each constituent and multiple bank account numbers and auto payment contracts.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f3b7e-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.2', 'Multiple Phone Numbers', 'Multiple phone numbers (voice, fax, mobile, pager,NOW(),NOW()) for each record', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f3c5a-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.2', 'Record Navigation', 'The system provides the ability to easily view related records and then return to the original record with one or two clicks.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f3d36-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.2', 'Remote Access', 'Remote access is supported for the maintenance of constituent data by volunteers', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f3e08-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.2', 'Retrieve by Bank Account', 'Records can be retrieved directly by entering a constituentâ€™s bank account number.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f3ee4-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.2', 'Retrieve by E-mail', 'Records can be quickly retrieved by entering a constituentâ€™s E-mail address.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f3fca-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.3', 'Retrieve by Phone Number', 'Records can be quickly retrieved by entering a constituentâ€™s phone number.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f409c-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.3', 'Seasonal Addresses', 'Allows a seasonal or temporary address to automatically become primary during designated date ranges.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f4178-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.3', 'Survey Responses', 'System provides for the capture of survey responses.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f4254-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.3', 'Survey Engine', 'System includes full survey functionality including template creation and ability to serve the survey form.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f433a-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.3', 'Tax ID Number', 'Caters for viewing of private data e.g. where data such as tax file number, credit card number or telephone and address is only available to certain roles or security levels. Data would have to be printable when authorised by the appropriate security level', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f4434-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.3', 'Telemarketing Results', 'System can capture telemarketing response, including tracking hang-ups, no answer, message left, number disconnected, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f4510-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.3', 'Telemarketing Tracking', 'System integrates with common telemarketing hardware to provide auto-tracking of response.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f45f6-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.3', 'Telemarketing Scripts', 'System supports telemarketing scripts customized with data retrieved from a constituent''s record.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f46d2-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.3', 'Un-do Function', 'All screens have an ''un-do'' function to reverse the last change.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f771a-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.3', 'Unlimited Merge Templates', 'System supports an unlimited number of mail merge templates.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f780a-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.4', 'Unlimited Relationships', 'An unlimited number of relationships can be maintained for each record.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f78e6-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.4', 'Web Site Address', 'Maintains at least two web site address for each record with corresponding label (blog, twitter, etc.,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f79cc-52a5-11df-84e5-000ae4cc0097', '1d2a0f38-5211-11df-952d-000ae4cc0097', '1.3.4', 'Word Processing Merge', 'Directly produces a formatted Merge File for Word and Open Office including signature driven salutation, conditional statements, etc., as defined by the user - for acknowledgements or set of records that might be selected.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f7c06-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.1', 'Audit Trail', 'System maintains an audit trail of activity including date, time, source of change and user identification, along with old and new values.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f7d1e-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.2', 'Audit Trail Rollback', 'Audit trail of transactions can be rolled back by an NRO system administrator.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f86ce-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.3', 'Data Validation', 'The system provides verification of data entered against a table of values for applicable table-driven fields.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f8912-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.4', 'Deleted Ids', 'System prevents re-using deleted IDs.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f8a84-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.5', 'Duplicates: Detection', 'System has strong duplicate detection algorithm where a data base administrator can adjust the criteria for the match logic.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f8ba6-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.6', 'Duplicates: Detection Batch', 'Can check for suspected duplicates in batch mode for all or groups of records.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f8c78-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.7', 'Duplicates: Detection Input', 'Identical duplicate detection is available at keyboard data entry, lockbox upload, or web system interface.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f8d2c-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.8', 'Duplicates: External Process', 'Has the ability to import a list of pairs of ID numbers from external de-duplication services, and process them the same way that two records identified manually could be merged.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f8dfe-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.9', 'Duplicates: Merging Transactions', 'When duplicate records are merged, all transactions (financial and non financial,NOW(),NOW()) will be moved to the retained record.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f8ec6-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.1', 'Duplicates: Processing', 'The NRO has the option of viewing all detected duplicates with both names and addresses displayed together on the screen, and individually approving the change before it is made.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f8fa2-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.1', 'Duplicates: Review', 'New records that are potential duplicates can be viewed side-by-side with the existing record and the user can accept, reject, or mark the records for further research.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f906a-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.1', 'Field Verification', 'All transactions, whether entered on-line or in batch, go through system edits for field verification and transactions with errors can be printed or placed in an error file..', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f9132-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.1', 'Postcode Verification', 'Upon data input, postcodes are verified against a table of legal values.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f91f0-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.1', 'Field Change Date', 'Maintains date and user for date last changed for each, or selected, fields.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f92ea-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.1', 'Table Change Date', 'Maintains date and user for date last changed for each table.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f9394-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.1', 'Record Creation Date', 'Maintains user and date for date record created.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12f943e-52a5-11df-84e5-000ae4cc0097', '1d2a11ae-5211-11df-952d-000ae4cc0097', '1.4.1', 'Validation Tools', 'System contains extensive validation tools which are customizable by the NRO.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fc1ca-52a5-11df-84e5-000ae4cc0097', '1d2a1460-5211-11df-952d-000ae4cc0097', '1.5.1', 'Attach DD Contracts', 'Electronic copies of Direct Dialogue contracts can be attached to constituent''s records.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fc2ba-52a5-11df-84e5-000ae4cc0097', '1d2a1460-5211-11df-952d-000ae4cc0097', '1.5.2', 'Attach Scanned Docs', 'An unlimited number of Office documents and graphics files, including scanned document images, can be attached to a constituent''s record.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fc3a0-52a5-11df-84e5-000ae4cc0097', '1d2a1460-5211-11df-952d-000ae4cc0097', '1.5.3', 'Document Management', 'System provides integrated document management including key word searching and bar codes.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fc486-52a5-11df-84e5-000ae4cc0097', '1d2a1460-5211-11df-952d-000ae4cc0097', '1.5.4', 'Hyperlinked Documents', 'Records can be hyperlinked to an unlimited number of documents.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fc576-52a5-11df-84e5-000ae4cc0097', '1d2a1460-5211-11df-952d-000ae4cc0097', '1.5.5', 'PDF Format', 'The system supports rendering documents in Acrobat PDF format.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fc67a-52a5-11df-84e5-000ae4cc0097', '1d2a1460-5211-11df-952d-000ae4cc0097', '1.5.6', 'XML Format', 'The system supports rendering documents in XML.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fc81e-52a5-11df-84e5-000ae4cc0097', '1d2a1712-5211-11df-952d-000ae4cc0097', '1.6.1', 'Modify Documentation', 'GP can define & modify documentation that will be available to users on-line, including Help Files.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fc8f0-52a5-11df-84e5-000ae4cc0097', '1d2a1712-5211-11df-952d-000ae4cc0097', '1.6.2', 'Training Manual', 'A train-the-trainer training manual is provided', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fc9b8-52a5-11df-84e5-000ae4cc0097', '1d2a1712-5211-11df-952d-000ae4cc0097', '1.6.3', 'eLearning', 'eLearning training is provided', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fca9e-52a5-11df-84e5-000ae4cc0097', '1d2a1712-5211-11df-952d-000ae4cc0097', '1.6.4', 'Technical Documentation', 'Comprehensive technical documentation is provided including code documentation, release notes, unit test results, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fcb8e-52a5-11df-84e5-000ae4cc0097', '1d2a1712-5211-11df-952d-000ae4cc0097', '1.6.5', 'On-line Documentation', 'All user documentation is available on-line.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fce04-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.1', 'Automatic Form', 'Changes in autopay plans can generate an automated E-mail with an attached form that needs to be filled out, signed, and sent back.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fcecc-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.2', 'DD Batch Review', 'A batch of Direct Dialogue transactions can be held in suspension until it is reviewed and accepted by the recruiter or supervisor.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fcf94-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.3', 'DD Information', 'System can capture the venue (where the DD occurred,NOW(),NOW()), recruiter, team leader, GP manager, date, and shift (e.g. 8-12,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fd07a-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.4', 'DD Staff Data', 'For each recruiter the system tracks: name, gender, role, age, address, phone, e-mail, skills, start date, end date, languages, comments (e.g. performance assessments,NOW(),NOW()) shift data, allowances paid, travel time etc', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fd32c-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.5', 'DD Remote Access', 'Remote access is supported for the entry of Direct Dialogue donations, as well as general constituent service tasks.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fd3fe-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.6', 'DD Shift Data', 'For each shift, the system captures venue(s,NOW(),NOW()) worked, team(s,NOW(),NOW()) working, date, shift(s,NOW(),NOW()), expenses (travel, remuneration,NOW(),NOW()), hours recruited per recruiter, paid briefing/training time, and weather conditions.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fd4da-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.7', 'DD Team Data', 'For each team, system tracks: name, where the team works, assigned code, leader''s name, member availability.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fd5a2-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.8', 'DD Venue', 'For each venue, the system can store: country, city, address or intersection, contact person''s name and title, permission(s,NOW(),NOW()) obtained to use the venue, and comments about the venue (e.g. problems,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b12fd688-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.9', 'Development Plan', 'System tracks goals/actuals for number of supporters, hours, average donation, budget for annual, monthly, and weekly.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13034fc-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.1', 'Hierarchy Goals', 'A hierarchy of recruiters can have its own goals, and goals and results must roll up the hierarchy to each level.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1303600-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.1', 'Membership Program', 'Has the ability to implement a membership type program within the database to programmatically flag/identify different classifications for members (i.e.; expires in 3 months, 2 months, 1 month, etc.,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13036e6-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.1', 'Multiple Sustainer Programs', 'System could support quarterly or semi-annual sustainer programs simultaneously with the monthly program.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13037b8-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.1', 'Recruiter Hierarchy', 'System supports tracking a hierarchy of recruiters using the terminology common to the particular NRO office. E.g., Permission Coordinators, Group Coordinators.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1303894-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.1', 'Recruiter History', 'A history of a recruiter''s involvement with GP is captured including join date, how long they worked, how much they have been paid, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1303966-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.1', 'Recruiter Schedule', 'System supports schedule preparation and printout.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1303a1a-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.1', 'Salary/Bonus Calculations', 'System calculates salary and bonus for a recruiter based on an NRO-defined formula.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1303ae2-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.1', 'Scan Direct Dialogue Forms', 'System integrates with scanning and OCR systems for processing of Direct Dialogue forms used by each NRO.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1303baa-52a5-11df-84e5-000ae4cc0097', '1d2a1c94-5211-11df-952d-000ae4cc0097', '2.1.1', 'Sustainer Groups', 'Has the ability to segment monthly givers into appropriate sub-groups (New, Upgrade, Downgrade, Renewal,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1303d44-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.1', 'Assignment Date', 'Captures the date a Greenpeace staff member (e.g. prospect manager,NOW(),NOW()) was assigned to a supporter.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1303e20-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.2', 'Calendar Integration', 'Tickler events can integrate with a fundraiser''s calendar in either/both Outlook and Google Calendar', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1303efc-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.3', 'Closed-End Pledges', 'Closed-end pledges (fixed amount and timetable of payments,NOW(),NOW()) are supported by the system, including the production of pledge reminders and the tracking of fulfillment rates and missed payments.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1304000-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.4', 'Contact History', 'Has the ability to capture complete contact history including inbound and outbound contacts via all channels.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13040f0-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.5', 'Cultivation Templates', 'Has the ability to have templates of standard cultivation plans that can be modified and tailored.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13041fe-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.6', 'Duplicate Proposal Warning', 'An automatic on-screen warning is generated if a user attempts to create a new proposal when there is an active proposal for that donor.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13042bc-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.7', 'E-mail Reminders', 'System can send tickler reminders to staff by E-mail.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130437a-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.8', 'Filtered Ticklers', 'Ticklers can be filtered (e.g. only ticklers due in the next two weeks are shown at login,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130442e-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.9', 'Formal Address', 'The system maintains a formal address for an individual (e.g. upper/lower case, abbreviations are optional,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13044ec-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.1', 'Foundation Codes', 'Rating codes, such as Capacity and Inclination, can be captured for a Foundation.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13045a0-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.1', 'Foundation Details', 'Funding interests, typical grant size, and deadline dates can be captured for a Foundation.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1304672-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.1', 'Foundation Records', 'Has the ability to capture comprehensive foundation information with links to staff and trustees.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130473a-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.1', 'Funding Interests', 'System relates constituent interests to possible specific proposals', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1304802-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.1', 'Fundraiser Performance', 'System tracks goals/actuals for development officer''s activities.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13048ca-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.1', 'Gifts Linked to Proposals', 'System can link a gift to the proposal that solicited it.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1304988-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.1', 'History of Stewardship', 'Stewardship activities can be captured in the individual''s contact history.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1304a50-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.1', 'Incomplete Tasks', 'System can generate reports of incomplete stewardship activities.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1304b36-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.1', 'Moves Management', 'System provides support for major donor â€œmoves managementâ€ by tracking the "stage" of each prospect.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1304c08-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.1', 'Multiple Cultivation Plans', 'Maintains an unlimited number of cultivation/solicitation plans for a prospect. ', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1304cc6-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.2', 'Organization Search', 'System supports searching for organizations by either contact or organization name.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1304d8e-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.2', 'Proposal Analysis', 'Includes a tool for tracking proposals and whether they were funded, including the ask amount, % likelihood of receiving the ask amount, and the actual gift amount.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1309550-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.2', 'Proposal Development', 'Tracks each stage of proposal development, including staff assignments, due dates, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1309618-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.2', 'Proposal History', 'System produces a history of past proposals and activities on those proposals, both of which are searchable.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13096d6-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.2', 'Proposal Reporting', 'Proposal reports can be run at the prospect level (e.g. progress report, activity chronology, etc.,NOW(),NOW()) and at the program level (e.g. what proposals have been sent to solicit support for this area?,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130979e-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.2', 'Rating Codes', 'Captures several GP-defined rating codes for each prospect including capability & likelihood.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1309852-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.2', 'Reciprocal Relationships', 'When a relationship between two records is entered, system creates a reciprocal entry.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1309906-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.2', 'Replacing Staff Member', 'System can reassign prospects to a different staff member or solicitor along with all pending actions.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13099ba-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.2', 'Target Amount', 'Stores goal or target amount for each prospect.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1309a64-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.2', 'Three Salutations', 'The system maintains at least three salutations for each record.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1309b0e-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.3', 'Ticklers', 'Provides a tickler file for tracking future stewardship steps.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1309bc2-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.3', 'Ticklers can be Assigned', 'Ticklers can be assigned to another staff member (e.g., to an assistant,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1309c76-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.3', 'Unlimited Contacts', 'Contact management component allows for unlimited past & future contacts.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1309d20-52a5-11df-84e5-000ae4cc0097', '1d2a1f0a-5211-11df-952d-000ae4cc0097', '2.2.3', 'Varied Payment Schedule', 'The system supports the management of multi-year pledges where the dollar amount and due date for each payment varies.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1309e9c-52a5-11df-84e5-000ae4cc0097', '1d2a2194-5211-11df-952d-000ae4cc0097', '2.3.1', 'Topic Expertise', 'Captures topic areas for those willing to do speaking engagements, displays, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1309f5a-52a5-11df-84e5-000ae4cc0097', '1d2a2194-5211-11df-952d-000ae4cc0097', '2.3.2', 'Tracking Hours', 'History of start & end dates for each volunteer period with an on-going tally of the total number of hours worked.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130a036-52a5-11df-84e5-000ae4cc0097', '1d2a2194-5211-11df-952d-000ae4cc0097', '2.3.3', 'Volunteer Availability', 'Captures when volunteers are available.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130a0fe-52a5-11df-84e5-000ae4cc0097', '1d2a2194-5211-11df-952d-000ae4cc0097', '2.3.4', 'Volunteer History', 'Supports tracking both current and past volunteer involvement with GP with start & end dates.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130a1e4-52a5-11df-84e5-000ae4cc0097', '1d2a2194-5211-11df-952d-000ae4cc0097', '2.3.5', 'Volunteer Impact', 'Captures quantitative and qualitative measures of volunteer''s work to support analysis of a volunteer''s effectiveness/impact.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130a2de-52a5-11df-84e5-000ae4cc0097', '1d2a2194-5211-11df-952d-000ae4cc0097', '2.3.6', 'Volunteer Interests', 'Captures type of volunteer activity they want to do.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130a392-52a5-11df-84e5-000ae4cc0097', '1d2a2194-5211-11df-952d-000ae4cc0097', '2.3.7', 'Volunteer Profile', 'Tracks a volunteer''s interests, skills and experiences.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130a43c-52a5-11df-84e5-000ae4cc0097', '1d2a2194-5211-11df-952d-000ae4cc0097', '2.3.8', 'Volunteer Recognition', 'Tracks awards or recognition given to volunteers.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130a4e6-52a5-11df-84e5-000ae4cc0097', '1d2a2194-5211-11df-952d-000ae4cc0097', '2.3.9', 'Volunteer Scheduling', 'Can create a schedule of when volunteers will work.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130a586-52a5-11df-84e5-000ae4cc0097', '1d2a2194-5211-11df-952d-000ae4cc0097', '2.3.1', 'Volunteer Personal Data', 'Can browse and select on a volunteer''s personal information (skills, interests, contact, groups, actions, newsletters, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130a716-52a5-11df-84e5-000ae4cc0097', '1d2a2432-5211-11df-952d-000ae4cc0097', '2.4.1', 'Events - Basic', 'System provides basic support for fundraising and stewardship events: ability to segment invitation lists, track RSVPs and attendance.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130a7d4-52a5-11df-84e5-000ae4cc0097', '1d2a2432-5211-11df-952d-000ae4cc0097', '2.4.2', 'Events - Budget/Expenses', 'System captures budget and projected and actual expenses for events', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130fb08-52a5-11df-84e5-000ae4cc0097', '1d2a2432-5211-11df-952d-000ae4cc0097', '2.4.3', 'Events - Table Seating', 'System provides management of table seating for events', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130fc0c-52a5-11df-84e5-000ae4cc0097', '1d2a2432-5211-11df-952d-000ae4cc0097', '2.4.4', 'Events - Venues', 'System tracks event venues, including capacity, facilities, cost, contact info', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130fd10-52a5-11df-84e5-000ae4cc0097', '1d2a2432-5211-11df-952d-000ae4cc0097', '2.4.5', 'Ticket Sales', 'Support for simple ticket sales (e.g. number of tickets, types (adult, children,NOW(),NOW()),NOW(),NOW()). It is not necessary to support sales of reserved seats.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b130ff72-52a5-11df-84e5-000ae4cc0097', '1d2a2932-5211-11df-952d-000ae4cc0097', '3.1.1', 'Action List', 'Ability to manage list of supporters related to an action (browse, import, export, merge,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310210-52a5-11df-84e5-000ae4cc0097', '1d2a2932-5211-11df-952d-000ae4cc0097', '3.1.2', 'Action Results', 'System manages action results (view/segment/export,NOW(),NOW()) - overall result (total number signed, etc,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131030a-52a5-11df-84e5-000ae4cc0097', '1d2a2932-5211-11df-952d-000ae4cc0097', '3.1.3', 'Browse Results', 'System captures and allows browsing of results of number of signups, process completion, etc. by city, region, country, date, month, year, age, interest, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310404-52a5-11df-84e5-000ae4cc0097', '1d2a2932-5211-11df-952d-000ae4cc0097', '3.1.4', 'Contact Preferences', 'Provides comprehensive tracking of contact preferences (newsletters, calls, reminders, SMS alerts, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310508-52a5-11df-84e5-000ae4cc0097', '1d2a2932-5211-11df-952d-000ae4cc0097', '3.1.5', 'Login Creation', 'Can automatically create logins for all existing cyber activists and supporters and mail them their login details', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310698-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.1', 'Browse Lists', 'Provides ability to browse all lists (global supporter list, action-related list, target group lists, newsletters lists, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310774-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.2', 'Classic Subscribe', 'Captures subscribe/Unsubscribe for standard communication channels (phone call, paper mail,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310850-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.3', 'Email Format Preference', 'Captures email format preferences (Text or HTML, etc.,NOW(),NOW()) for each email address.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310972-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.4', 'Email Response Statistics', 'Provides view/export reporting at messaging campaign level (number of opened, bounced, fwd msg, clicked, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310a8a-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.5', 'Email Responses', 'Manages emails direct replies (view, reply, delete,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310b8e-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.6', 'Email Verification', 'If a constituent makes a change to their information via the web, an email verification of the change can be sent automatically.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310c4c-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.7', 'Messaging Templates', 'Supports management of messaging templates', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310d0a-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.8', 'Newsletter Subscriptions', 'Tracks subscribe/unsubscribe to multiple newsletters', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310de6-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.9', 'Newsletter Tracking', 'Supports receive/Read newsletter', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310e90-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.1', 'One-off E-Mail', 'Can reply to a message (email, etc.,NOW(),NOW()) and engage a conversation with appropriate GP staff', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310f44-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.1', 'Reminders', 'Supports subscribe/Unsubscribe emails alerts (reminders and call to actions,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1310ff8-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.1', 'White Listing Service', 'Email system support white listing services (ISP complaint handling,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13110ac-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.1', 'Reply Forwarding Configuration', 'Manages direct reply forwarding rules configuration', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1311160-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.1', 'SMS Keywords', 'Manages SMS keywords that will trigger activities/workflows', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1311214-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.1', 'SMS Subscribe', 'Supports subscribe/Unsubscribe for SMS messages (call-to-action/reminders,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13112c8-52a5-11df-84e5-000ae4cc0097', '1d2a2b94-5211-11df-952d-000ae4cc0097', '3.2.1', 'SMS Templates', 'Manages SMS message templates', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1317b82-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.1', 'Activity Tracking', 'Contains integrated reporting on constituent services activity, by staff member, type, and time period.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1317c68-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.2', 'Automatic Birthday Greetings', 'System can send an email message at a predefined date (such as a birthday greetings,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03');
INSERT INTO `requirements` (`id`, `parent_id`, `serial`, `name`, `description`, `created`, `modified`) VALUES
('b1317d4e-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.3', 'Capture Entire Relationship', 'System provides an easy method to capture a constituent''s complete relationship with GP, including donations, actions, volunteering, petitions, interests, source of entry, and participation in events.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1317e52-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.4', 'Capture Other Relationships', 'System can capture a constituent''s relationships outside of GP, such as spousal, employment, board service, etc,', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1317f60-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.5', 'Communications Preferences', 'System contains comprehensive support for tracking communication preferences, such as using one address for mailing list subscriptions, a different one for financial reports, an E-mail address for solicitations, a different E-mail address for cyber-activism, etc. and other preferences as languages, frequency (only once a year,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13180b4-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.6', 'Complaints', 'Captures complaints from donor and what action was taken.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13181a4-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.7', 'Contact Management', 'System has generalized contact management system for both constituent- and GP-initiated contacts.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1318276-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.8', 'Create Merge Contact', 'When a word processing merge file is produced the system can automatically create an outbound contact record for each constituent.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131833e-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.9', 'Fulfillment Date', 'Date & time of fulfillment (e.g. literature, merchandise, etc.,NOW(),NOW()) is captured.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1318424-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.1', 'Inbound E-mail Processing', 'Support for inbound E-mail response management is provided, including automatically retrieving the supporter record by searching all email addresses..', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1318500-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.1', 'Live Chat', 'System supports a ''Live Chat'' function', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13185c8-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.1', 'Interests', 'Has the ability to track an individualâ€™s interest(s,NOW(),NOW()) as well as exclusion(s,NOW(),NOW()) from any interest or campaign (e.g. someone might indicate that they want no contact concerning the nuclear campaign,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13186ae-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.1', 'Literature Request', 'Supports orders for publications, and is able to process fee-based and free publications along with a donation in one transaction.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1318fb4-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.1', 'Non-Donor Management', 'System supports the management of non-donors such as: Activists, Special interest group, Media, Vendors, VIPs, Government official, Corporate partners, Board members.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131911c-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.1', 'On-Screen Profile', 'System provides an on-screen summary profile of an individual without visiting multiple screens.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131922a-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.1', 'Opt In/Out Handling', 'System maintains a list of constituent permissions for opt-in or opt-out, along with date and how obtained, for each item in a table controlled by the NRO.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1319360-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.1', 'Preferred Communication', 'Tracks preferred communication channels (phone, E-mail and postal mail,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1319496-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.1', 'Request Date', 'Date changes in communication preferences are made is captured.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1319554-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.1', 'Request Processing', 'Can produce mailing labels indicating what information is required for fulfillment.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1319612-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.2', 'Request Source', 'Tracks the request channel, e.g., by mail, E-mail, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13196c6-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.2', 'Service Requests', 'Supports customer service requests, e.g., requests for information, literature, etc. and provides appropriate management reporting of activity.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131978e-52a5-11df-84e5-000ae4cc0097', '1d2a2e64-5211-11df-952d-000ae4cc0097', '3.3.2', 'Unlimited Notes', 'System tracks unlimited notes on constituents including separate fields for the date and author (that can be searched,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131996e-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.1', 'Attachments', 'Allow attachments to be sent as part of an e-mail', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1319a0e-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.2', 'Automated Processes', 'Ability to automate marketing processes through triggers and workflows', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1319ac2-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.3', 'Browse Campaigns', 'Supports browsing campaigns code, name, description', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1319b76-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.4', 'Calendar Support', 'System maintains a Master calendar of campaigns (across all projects,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1319c20-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.5', 'Campaign Coding', 'Can store both campaign codes and descriptions for ease of search and reporting/analysis.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1319d06-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.6', 'Campaign Dates', 'Has the ability to record and report on a beginning and end dates for a Campaign.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1319e1e-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.7', 'Campaign Overview', 'Has the ability to create a campaign, with reference to the channel and method (e.g. collateral/mail package to be sent,NOW(),NOW()), the list to be used, the theme of the campaign, goal of the campaign, money invested and anticipated.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1319efa-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.8', 'Campaign Planning', 'System includes a campaign planning tool that can track and execute all the stages of a campaign.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131d9e2-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.9', 'Campaign Templates', 'Campaigns can be created and saved as templates', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131dad2-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.1', 'Campaign Tracking', 'Has the ability to look at a campaign and segment and see income to date and response statistics.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131dbae-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.1', 'Campaign Type', 'Has the ability to record the type of Campaign; acquisition, sustainer, renewal.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131dc76-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.1', 'Copy Campaign Specs', 'Has the ability to easily copy a prior campaign and change the type.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131dd48-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.1', 'Create Contact Record', 'When a campaign is executed, a contact record is automatically created (an ''opportunity '' or ''interaction '',NOW(),NOW()) for each constituent contacted.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131de1a-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.1', 'Cross-Channel Campaign', 'System supports multi-wave, cross-channel campaigns', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131dee2-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.1', 'Dynamic Content', 'Support dynamic content generation of e-mails for customized newsletters, promotions, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131dfaa-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.1', 'Inbound Email', 'Handle inbound processing of e-mails (for both hard and soft bounces,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131e072-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.1', 'Integrated Marketing', 'Provides support for integrated marketing campaigns across multiple channels, including mail, DRTV, telemarketing, direct dialogue, E-mail, and SMS.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131e14e-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.1', 'Multiple Data Source', 'Allow use of multiple data sources simultaneously (including flat files,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131e216-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.1', 'Multi-Stage Campaigns', 'User can select simple, single-stage or a complex, multi-stage campaign', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131e2de-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.2', 'Outlook Integration', 'Integration with Outlook calendars, to do lists, and e-mail', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131e3b0-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.2', 'Output to Third Parties', 'Ability to send properly formatted files of selected customers directly to third parties in support of marketing efforts (direct mail houses, telemarketing firms, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131e644-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.2', 'Outside Access', 'Outside vendors can have access to the product without having visibility into all scheduled activities', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131e72a-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.2', 'Overlapping Campaigns', 'Has the ability to create campaigns that overlap with other campaign dates.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131e7fc-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.2', 'Promotion History', 'Ability to capture promotion history and use in future campaigns', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131e8ce-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.2', 'Repeat Campaigns', 'Campaigns can be created to automatically repeat.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131e9a0-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.2', 'Response Alert', 'System can create an alert when the first response is received to a campaign.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131ea72-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.2', 'Scheduled Campaigns', 'An NRO can schedule a campaign to run automatically', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131eb44-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.2', 'Scheduling', 'Provide flexible scheduling capabilities', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131ec0c-52a5-11df-84e5-000ae4cc0097', '1d2a3328-5211-11df-952d-000ae4cc0097', '4.1.2', 'Unique Identified', 'Support a unique identifier on each outbound communication which contains donor identification and segment information.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131ed9c-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.1', 'Acknowledgement Code', 'System source file stores the acknowledgement letter code.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131ee82-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.2', 'Acquisition File Detail', 'Has the ability to store the list code/name, source of the list, list date, list quantity and to search for same.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131ef7c-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.3', 'Cost Detail', 'Has the ability to capture actual costs for a campaign in detail.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131f076-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.4', 'Cross Channel Move', 'Can track moves from one channel to another, including the date of the move, and the source code of contacts made with the constituent between steps.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131f184-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.5', 'Cyber Activist', 'Provides support for managing a segment of the file who are cyber activists (an attribute on the supporter record,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131f2a6-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.6', 'End-User Extract', 'The end-user can define the output file configurations, automatically generate the file, download into a user-defined deliverable (CD, DVD, ftp, E-mail, Excel, etc,NOW(),NOW()) and send it to a specified vendor.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131f38c-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.7', 'Field Descriptions', 'Can click on Source/Fund code for description.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131f454-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.8', 'Life Cycle Tracking', 'Provides the ability to independently track the life cycle of any defined segment, such as cyber activist or mobile activist.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131f51c-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.9', 'Linking Viral Response', 'System supports sending an SMS message to a mobile requesting three mobile numbers (or E-mail addresses,NOW(),NOW()) of possible new constituents. New constituents can be automatically linked back to the original individual and message.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131f602-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.1', 'Marketing Segmentation', 'System supports segmentation based on RFM, prior donor actions, inbound and outbound contacts, cyber activist actions, events attended, interests.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b131f6e8-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.1', 'Mobile Activists', 'Provides support for managing a segment of the file who are mobile activists.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1322d0c-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.1', 'Original Source', 'System captures the source code associated with the first gift for each individual and stores it in a field in the main bio record as the originating source code.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1322de8-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.1', 'Personalized Campaigns', 'Direct mail pulls and E-mail campaigns can be personalized, and can include the name, date, and amount of their last gift.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1322eba-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.1', 'Prospect Original Source', 'An origin code is retained for each record that came onto the file other than via a gift indicating the source of the name (e.g. for a prospect,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1322f8c-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.1', 'Saved Criteria', 'Ha the ability to save the selected criteria. Saved selections can be reused, or modified, for a subsequent segmentation.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323054-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.1', 'Segmentation De-Dupe', 'There is automatic de-duping during the selection so a potential donor only comes up once in the selection.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132311c-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.1', 'Segmentation Options', 'Will allow Greenpeace to segment appeals and analyze results based on flexible combinations of criteria such as: Recency and Frequency (calendar or fiscal year, first gift date, last gift date, years of consecutive giving, Money: (highest previous, most recent, lifetime,NOW(),NOW()), Other (campaign, channel, package, segment,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323202-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.1', 'Segregated Acquisition Files', 'System supports acquisition (or finder,NOW(),NOW()) files, including segregating the record outside of the main database, and supporting an alternate ID structure that can be retrieved via use of a scan-line or during manual data entry.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13232de-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.1', 'Source Description', 'The system has the ability to store descriptive information about the source code assigned to any fundraising effort. Including but not limited to, text descriptions, segment code, package code, acquisition list information, broker, mail date, and quantity mailed.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13233c4-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.2', 'Test Segments', 'Has the ability to easily identify and link test segments to their corresponding control segments for easy tracking within a campaign and through a query.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132348c-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.2', 'Unlimited Segments', 'The system has the ability to identify, select and apply source codes to an unlimited number of segments per mailing or initiative.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323554-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.2', 'Viral Marketing Benefits', 'The ability to track the â€˜benefitâ€™ sent to a constituent for complying with a viral message request (e.g. a T-shirt for sending in three mobile numbers,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323626-52a5-11df-84e5-000ae4cc0097', '1d2a35f8-5211-11df-952d-000ae4cc0097', '4.2.2', 'Viral Marketing Results', 'System can track the results of a viral marketing campaign, such as Member-get-a-member program and link new member to the first.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13237b6-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.1', 'Analyze Group', 'A set of people selected for a segment can be followed across future campaigns for analysis.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323888-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.2', 'Ask Strings', 'System will create an â€œask stringâ€ calculated based on either the last gift or largest gift', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323964-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.3', 'Deduplicated Output', 'Output file is deduplicated', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323a4a-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.4', 'Email Testing on Content', 'A/B testing on content', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323b30-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.5', 'Email Testing on Sender', 'A/B testing on sender email address', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323c2a-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.6', 'Email Testing on Subject', 'A/B testing on subject line', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323cd4-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.7', 'Large Segmentations', 'Ability to run a large population, 500 segments and not require an overnight run', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323d88-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.8', 'List Management', 'Supports duplicate, segment, merge, export and import (new or fusion,NOW(),NOW()) the lists', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323e46-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.9', 'Random Selects', 'System supports randomized or Nth record selects.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1323efa-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.1', 'Relative Dates', 'System supports â€œrelative datesâ€, so the user can use things like â€œmonths pastâ€ or â€œToday â€“ 6 monthsâ€ rather than having to specify specific start and end dates.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1324062-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.1', 'Reorder Segments', 'Segments can be easily re-ordered, e.g. so that a particular program could be forced to be at the top of the waterfall of segments.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132413e-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.1', 'Reusable Segments', 'Supports use of reusable static segments', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1324206-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.1', 'Scoring', 'Models and scores can be incorporated and used in segmentation', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13242ce-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.1', 'Seeds Support', 'System supports ability to incorporate seeds and to calculate results and analysis ignoring the seeds.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1324396-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.1', 'Segment & Test', 'Allows user to segment audience and test performance of different messages', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1324468-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.1', 'Segment Drilldown', 'Ability to drill down in segment reports to select groups to include within a campaign', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132453a-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.1', 'Segment History', 'Ability to analyze a segment across mailings to develop historical response statistics.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1324602-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.1', 'Segment Migration', 'System supports tracking segment migration.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13246ca-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.1', 'Segment Names', 'An individual segment can be named both with a code (e.g. GH237Z,NOW(),NOW()) as well as a text description that identifies the criteria for that segment (e.g. â€œ3+ yrs, 2+ gifts, LT $5+â€,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13247b0-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.2', 'Segment Refresh', 'Segments can be refreshed at any time interval, separately from campaign execution', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1324882-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.2', 'Segments Over Time', 'Maintains a history to track the performance of segments over time', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132494a-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.2', 'Test/Control Groups', 'Test and control groups can be dynamically generated', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132d2f2-52a5-11df-84e5-000ae4cc0097', '1d2a3882-5211-11df-952d-000ae4cc0097', '4.3.2', 'Unlimited Packages', 'An unlimited number of packages (treatments,NOW(),NOW()) can be used in a campaign.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132d4b4-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.1', 'Graphical Workflow', 'System provides a graphical display of the business processes and activities allowing the processes to be defined or mapped into the system', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132d59a-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.2', 'Automatic Notification', 'System workflow supports the automatic notification of donors when credit card is expiring, Direct Debit stops, credit card doesnâ€™t go through, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132d68a-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.3', 'Integrated Process Workflow', 'Supports integrated process workflow, e.g. an upgrade might generate a thank you E-mail.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132d784-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.4', 'Multi-step Workflow', 'System workflow supports a multi-step sequence, such as notify by E-mail, if no response, SMS, if no response, telemarketing, if no response, direct mail.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132d892-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.5', 'User-Defined Triggers', 'End-users can define triggers or alerts, such as when a gift is received from a Board member, Major Gift prospect, or over a specified amount, the capacity for event registrations is reached, or the goal for a campaign is been achieved, etc. The alert can be sent as either an E-mail or SMS message.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132d9d2-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.6', 'Alert Mechanism', 'System supports multiple alerts - sending an email, sent via SMS, shown as a pop-up window or created and routed as a special workflow action.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132dc7a-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.7', 'Campaign Trigger', 'A project workflow can be created to kick off a campaign.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132dd4c-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.8', 'Triggered messages', 'There is support for configurable auto-responders / triggered messages (ex: subscription confirmation, goodbye messages, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132de28-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.9', 'Deadline Triggers', 'A specific deadline (date and time,NOW(),NOW()) can be defined for a workflow.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132df04-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.1', 'Relative Dates', 'Can us either absolute or relative dates when activities must be completed', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132dfe0-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.1', 'Reusable Processes', 'Can reuse an activity already defined in the process without having to define it again.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132e0bc-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.1', 'Scheduled Triggers', 'Scheduled triggers can be created to repeat based on a timer (every 4 hours, weekly, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132e1a2-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.1', 'Task Creation', 'A user can create tasks for another user that will be accessible by workflow.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132e27e-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.1', 'Specified Times', 'Tasks can be scheduled to start automatically at a specified time', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132e350-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.1', 'Task Escalation', 'System provides support for alerts and escalations of incomplete tasks', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132e422-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.1', 'Threshold Triggers', 'Threshold triggers (e.g., based on predefined attribute values for work-items, such as gift over 1000 Euro should generate alerts,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132e508-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.1', 'Time-Based', 'Ability to define time-based workflow steps.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132e5da-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.1', 'Variety of Triggers', 'System supports a variety of types of triggers of automatic actions, including triggers that occur based on a timer expiring.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132e6b6-52a5-11df-84e5-000ae4cc0097', '1d2a0736-5211-11df-952d-000ae4cc0097', '4.4.1', 'Workflow Design', 'Workflow design supports a visual, drag-and-drop method to display rules and routing logic.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132e8a0-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.1', 'Acknowledging E-mail', 'Provides automatic acknowledgement of E-mail messages that are received, and saves a record of the acknowledgement that was sent along with the date and time.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132e986-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.2', 'Acknowledging SMS', 'Provides automatic acknowledgement of SMS messages that are received, and saves a record of the acknowledgement that was sent along with the date and time.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132ea6c-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.3', 'Attach E-mail Attachment', 'If an inbound e-mail has an attachment, it can be automatically attached to the record.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132eb5c-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.4', 'Attach Inbound E-mail', 'An inbound e-mail can be automatically attached to a constituent''s record.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132ec6a-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.5', 'E-mail Acknowledgements', 'E-mail acknowledgements can be automatically generated for constituents that have E-mail as their preferred method of communication.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132ed82-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.6', 'In bound communication creates record (email, SMS, twitter, facebook etc,NOW(),NOW())', 'If an inbound communication cannot be matched to an existing constituent, the system can create a new record with that field as the key.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132ee54-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.7', 'E-mail Merge', 'Records can be selected using criteria or by ID and used for mail merge, resulting in a personalized E-mail message with variable fields in the text of the message.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132ef1c-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.8', 'Group Emails', 'System supports producing outbound e-mails to a group of selected records, and automatically creates a contact record.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132efee-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.9', 'Group SMS', 'System supports producing outbound SMS messages to a group of selected records, and automatically creates a contact record.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132f0b6-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.1', 'Inbound E-mail', 'Automatically captures inbound E-mail messages and creates a history of such transactions including the date & time received.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132f2e6-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.1', 'Inbound E-mail Contact', 'Inbound e-mail can automatically create a contact record with the constituent.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132f3cc-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.1', 'Inbound SMS', 'Automatically captures inbound SMS messages and creates a history of such transactions including the date & time received.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132f4a8-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.1', 'One-off E-mail', 'One-off outbound E-mails can be launched by double-clicking on any E-mail address in the system', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132f5a2-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.1', 'Personalized E-mail', 'E-mail can be personalized with a salutation.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132f69c-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.1', 'Personalized SMS', 'Outbound SMS messages can be personalized.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b132f764-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.1', 'SMS Merge', 'Records can be selected using criteria or by ID and used for mail merge, resulting in a personalized SMS message with variable fields in the text of the message.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13313b6-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.1', 'Donation accepted via SMS', 'Record premium SMS or credit card donation via SMS as source', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1331492-52a5-11df-84e5-000ae4cc0097', 'f1dfadc0-52a0-11df-84e5-000ae4cc0097', '4.5.1', 'MMS management', 'Ability to internationally receive & send MMS, store MMS files, send files via MMS', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1331a00-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.1', 'Bounced', 'Tracks how many emails bounced back because of bad email addresses.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1331ad2-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.2', 'Dynamic Content', 'The ability to reuse/insert dynamic data in the messages (ex: name, number of subscribers, etc,NOW(),NOW()) is supported.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1331bb8-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.3', 'Email config', 'System manages email message fields configuration (from, reply-to, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1331c8a-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.4', 'Email preview', 'Preview messages as it will be rendered in the main systems (Gmail, Hotmail, Outlook, Thunderbird...,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1331d5c-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.5', 'Email templates', 'System manages reminders, call-to-action, act.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1331e2e-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.6', 'Expert editor', 'System supports managing look & feel with HTML/CSS code editor', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1331eec-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.7', 'Forwarded', 'Insert forward-to-friend links into messages and track total times forwarded', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1331faa-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.8', 'HTML Format', 'HTML format content is supported for email messages.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1332068-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.9', 'HTML/CSS Fixer', 'System points out errors in the code', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133211c-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.1', 'Image Hosting', 'Free and unlimited image hosting is provided (if not, specify limit size in comment,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13321e4-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.1', 'Links tracking', 'Tracks the link they clicked on to go on the website', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13322ac-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.1', 'Opened', 'Tracks how many recipients opened ', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133236a-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.1', 'RSS to email', 'Triggered emails based on RSS feeds is supported.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1332432-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.1', 'Scheduling', 'Schedule campaigns for a later date and time (according to admin time zone,NOW(),NOW()) is supported.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13324fa-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.1', 'Spam score', 'System checks the spam score', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13325c2-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.1', 'Text Format', 'Text format content is supported for email messages.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1332680-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.1', 'Unsubscribed', 'Tracks unsubscribed contacts', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133273e-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.1', 'Visited', 'Tracks how many visited the website', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1332806-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.1', 'Web publishing', 'Messages that can''t be viewed in email client can be accessed as a webpage', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13328ce-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.2', 'Wizard', 'System provides list + email setup wizard (cf. usability,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1332996-52a5-11df-84e5-000ae4cc0097', 'f1dfbffe-52a0-11df-84e5-000ae4cc0097', '4.6.2', 'WYSIWYG editor', 'Built-in WYSIWYG editor', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1332bf8-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.1', 'Cleaning', 'System provides cleaning for imported text (clean typos / capitalization,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1332cb6-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.2', 'Deduplication', 'De-duplicate checking and merging of records supported during import', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1332d7e-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.3', 'Dynamic Content', 'Ability to reuse/insert dynamic data (ex: number of subscribers, etc,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1332e50-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.4', 'Dynamic Content', 'Ability to reuse/insert user data in the messages (ex: name, dob, etc,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1332f22-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.5', 'Export', 'Provides ability to export ALL database data using copy-pasting and files (ex: csv, txt,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1332ff4-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.6', 'Fields management', 'Can edit the default record fields and associated property (cf. unique, required, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13330bc-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.7', 'Flexible database', 'Ability to modify supporters data and record structure (ex: add/remove fields and labels, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1333274-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.8', 'Folder management', 'Can organize lists and contents by folders.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1333332-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.9', 'Import data', 'Can import database data (cf. supporters,NOW(),NOW()) using copy-pasting and files (ex: csv, txt,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13333f0-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.1', 'Multiple list mgmt', 'Allow setting up an unlimited number of lists', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13334b8-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.1', 'Relational database', 'System will store interests, action taken, donations, location, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1333576-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.1', 'Segment against..', 'Can segment/purge based on people who are/not on another list, a previous mailing campaign, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133363e-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.1', 'Segmentation', 'Segmentation available for all data (statuses, preferences, actions, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1337338-52a5-11df-84e5-000ae4cc0097', 'f1dfc706-52a0-11df-84e5-000ae4cc0097', '4.7.1', 'Test lists', 'Supports test/seed lists for implementing an internal validation cycle', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13374fa-52a5-11df-84e5-000ae4cc0097', 'f1dfcda0-52a0-11df-84e5-000ae4cc0097', '4.8.1', 'Replies/Answers', 'System manages emails direct replies (view, reply, delete,NOW(),NOW()) .', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13375c2-52a5-11df-84e5-000ae4cc0097', 'f1dfcda0-52a0-11df-84e5-000ae4cc0097', '4.8.2', 'Replies/Answers', 'Manages direct reply forwarding rules configuration (cf. multi-account set-up,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1337842-52a5-11df-84e5-000ae4cc0097', 'f1dfcda0-52a0-11df-84e5-000ae4cc0097', '4.8.3', 'Reply forwarding', 'Allow setting up reply handling cycle (cf. no no-reply policy but filtering and contextual forwarding,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1337ac2-52a5-11df-84e5-000ae4cc0097', 'f1dfcda0-52a0-11df-84e5-000ae4cc0097', '4.8.4', 'Soft bounce', 'Can filter soft bounces (ex: out of office message,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1337b8a-52a5-11df-84e5-000ae4cc0097', 'f1dfcda0-52a0-11df-84e5-000ae4cc0097', '4.8.5', 'Spam', 'System filters spam messages', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1337c3e-52a5-11df-84e5-000ae4cc0097', 'f1dfcda0-52a0-11df-84e5-000ae4cc0097', '4.8.6', 'Unsubscribe', 'Can filter/process unsubscribe requests', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1337e1e-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.1', 'Auto-Payer Time Periods', 'Functionality to support auto-payer will support any regular payment schedule, such as monthly, bi-monthly, 3 months, 6 months, or annual payments.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1337ef0-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.2', 'Batch Entry', 'All types of transactions are supported by batch entry, including gifts, closed-end pledges, payments, open-end (sustainer,NOW(),NOW()) pledges & payments, tribute gifts, merchandise purchase, event registration, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1337fc2-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.3', 'Batch Field Defaults', 'All fields in batch entry can be set to default for that batch.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1338080-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.4', 'Batch Posting', 'A batch can be posted from a different terminal than where it was entered.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133813e-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.5', 'Batch Security', 'Batch entry can be set up so a different person creates header and posts the batch from that entering the detail.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13381fc-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.6', 'Bequest Amount', 'System can capture the estimated amount of someoneâ€™s potential bequest gift.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13382ba-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.7', 'Bequest Information', 'System can track if someone has requested information about leaving a bequest (or legacy,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1338382-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.8', 'Bequest Intention', 'System can track if someone has indicated that they have left GP in their will.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1338436-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.9', 'Closed Funds', 'System capable of locking out any additional donations to a specific project that has reached its funding goal - transactions cannot be entered to the locked or closed fund, and imported batches cannot be posted .', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1338508-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.1', 'Currency Conversion', 'System maintains a currency conversion table that can be updated with an automatic daily feed.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13385d0-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.1', 'Display of Project Goals', 'Current progress toward project goals can be displayed on screen (directly, not by report,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13386a2-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.1', 'Gift Audit Trail', 'There is a full audit trail for all transactions, batch & on-line.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133876a-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.1', 'Gift Comments', 'There is a free-form comment line on each gift transaction.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1338832-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.1', 'Gift Dates', 'Gift transactions can include a Gift Date and a separate Deposit Date.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13388f0-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.1', 'In-Kind Valuations', 'System has an option to book in-kind gifts at either "Fair Market Value" or at 0 value (but retaining the FMV for calculating the total estimated value,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13389cc-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.1', 'International Currency', 'Gift transaction can capture both a native currency as well as the currency of record for the NRO.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1338a94-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.1', 'Click for Detail', 'Users can click on summarized gift data (such as total giving to a campaign by year,NOW(),NOW()) and view the associated detail (e.g., individual donors to that campaign and year,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1338b70-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.1', 'Irregular Sustainer Payments', 'System supports prepayment and partial payment transactions.', '2010-04-28 11:09:03', '2010-04-28 11:09:03');
INSERT INTO `requirements` (`id`, `parent_id`, `serial`, `name`, `description`, `created`, `modified`) VALUES
('b1338c2e-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.1', 'Joint/Individual Giving', 'If two individuals have a couple record, joint gifts can be credited as well as individual gifts from one individual without having to create a separate record for the individual.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1338d0a-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.2', 'Maintenance During Entry', 'During gift batch entry, the system allows other donor file maintenance on fields not in the gift transaction, such as changing an address, without leaving the gift entry procedure.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1338ddc-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.2', 'Merchandise Transaction', 'Supports a financial transaction for merchandise purchase, including capturing sales tax and shipping.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1338ea4-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.2', 'Mixed Transactions', 'Support for a mixed transaction where one payment (check, credit card, etc.,NOW(),NOW()) might include a mixture of philanthropic donations to multiple designations combined with registration for an event and a merchandise purchase.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1338f80-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.2', 'Multiple Payment Contracts', 'System supports multiple simultaneous sustainer payment contracts.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1339048-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.2', 'Multiple Pledges', 'Donors can have more than one open pledge. ', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1339106-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.2', 'New Record During Entry', 'During gift entry, if a name is not found, a new record can be created without leaving gift entry or the current batch.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13391d8-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.2', 'Payments: Cash', 'System provides comprehensive support for accepting payment in cash', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13392a0-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.2', 'Payments: Covenants', 'System provides comprehensive support for accepting payment by covenant.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1339368-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.2', 'Payments: In-Kind Gifts', 'System provides comprehensive support for accepting in-kind gifts.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1339426-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.2', 'Personal Check Payments', 'System provides comprehensive support for accepting payment by personal check.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13394ee-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.3', 'Pledge Adjustments', 'Can adjust pledge amount or payment schedule - while maintaining an audit trail - without deleting entire pledge/payment history.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13395c0-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.3', 'Project Report', 'Project Report shows all current fund designations, amount of goal, amount raised to date, pledged and paid and balance to be raised.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1339692-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.3', 'Prompt for Open Pledges', 'If a donor has open pledges, the pledges are displayed during gift entry.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133975a-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.3', 'Refunded Gift', 'If a gift is refunded, it is excluded from all financial reporting.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1339822-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.3', 'Scanning & Gift Processing', 'System supports linking a scanned image of a check or donor letter to an individual gift transaction.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133d1b6-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.3', 'Scheduling Posting', 'Posting of batches can either be run automatically when balanced or can be scheduled to run at any time by the client.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133d29c-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.3', 'Soft Credit Adjustment', 'If adjustments are made to a hard credit transaction, the user will be prompted to make any corresponding adjustments in the soft credit.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133d36e-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.3', 'Soft Credits', 'There can be an unlimited number of soft credit entries for an individual gift.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133d436-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.3', 'Sustainer Credit Cards', 'System supports automatic real-time processing of credit cards', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133d4f4-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.3', 'Sustainer EFT Payment', 'System supports EFT transactions for sustainer gifts.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133d5bc-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.4', 'Track Revenue', 'Has the ability to track all revenue (including non-fund raising,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133d67a-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.4', 'Tribute Gifts', 'System can track tribute gifts (â€œIn honor ofâ€ or memorial,NOW(),NOW()), and supports sending a notification to the family with listing of donors.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133d74c-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.4', 'Unlimited Designations', 'Supports an unlimited number of designations on a gift.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133d80a-52a5-11df-84e5-000ae4cc0097', 'f1dfd930-52a0-11df-84e5-000ae4cc0097', '5.1.4', 'Workplace Giving', 'System supports workplace giving where a gift is received from the employer, but can be associated with individuals who made the contributions.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133d9a4-52a5-11df-84e5-000ae4cc0097', 'f1dfdef8-52a0-11df-84e5-000ae4cc0097', '5.2.1', 'Account ID Quick Lists', 'A short list of receipts can be produced by entering a list of Account ID numbers.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133da80-52a5-11df-84e5-000ae4cc0097', 'f1dfdef8-52a0-11df-84e5-000ae4cc0097', '5.2.2', 'Acknowledgement Rules', 'Can support GP-specific rules for determining the type of acknowledgement to be sent.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133db66-52a5-11df-84e5-000ae4cc0097', 'f1dfdef8-52a0-11df-84e5-000ae4cc0097', '5.2.3', 'Gift Donation', 'A gift donation can be processed and the newsletter, or other response, will be sent to the donee based on a set of user-defined business rules.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133dc4c-52a5-11df-84e5-000ae4cc0097', 'f1dfdef8-52a0-11df-84e5-000ae4cc0097', '5.2.4', 'Gift Donations', 'The system can process gift donations (the gift recipient as well as the donor will receive GP''s newsletter, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133dd50-52a5-11df-84e5-000ae4cc0097', 'f1dfdef8-52a0-11df-84e5-000ae4cc0097', '5.2.5', 'Receipt Listing', 'When annual receipts are printed, the system can produce a file (to be sent to the tax authority,NOW(),NOW()) of all names, address, tax ID #s, and amounts.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133de5e-52a5-11df-84e5-000ae4cc0097', 'f1dfdef8-52a0-11df-84e5-000ae4cc0097', '5.2.6', 'Receipt PDFs', 'If a constituentâ€™s communication preference is E-mail, the system can automatically produce individual PDFs for the E-mail receipt, rather than printing a single PDF for all receipts.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133df30-52a5-11df-84e5-000ae4cc0097', 'f1dfdef8-52a0-11df-84e5-000ae4cc0097', '5.2.7', 'Receipts', 'Has the ability to produce receipts, including daily receipts, annual (end of year,NOW(),NOW()) receipts, or based on an ID.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133e0c0-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.1', 'Adjusting Rejects', 'Direct Debits that are rejected can be entered into the fundraising system, which can feed the appropriate adjusting transactions to Finance.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133e19c-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.2', 'Bank Account Format', 'The system allows for complete flexibility when recording international bank account numbers, e.g. two groups of eight digits, three groups of eight digits, or nine and sixteen.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133e28c-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.3', 'Banking System Interfaces', 'System has integrated tools to facilitate creating custom interfaces for national and post-bank systems.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133e386-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.4', 'Credit Card Processing', 'The system has integrated credit card processing.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133e46c-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.5', 'Credit Card Verification', 'System verifies credit card numbers using check-sum algorithms.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133e570-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.6', 'Direct Debit Batch', 'System provides the ability to process a mixed batch of Direct Debits against multiple banks, producing separate files for each.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133e638-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.7', 'Direct Debit Rejects', 'Efficient procedures for handling Direct Debit rejects.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133e6f6-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.8', 'Payments: Credit Card', 'System can bill credit cards for donations.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133e7aa-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.9', 'Payments: Debit Card', 'System provides comprehensive support for accepting payment by debit card.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133e9f8-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.1', 'Payments: Direct Debit', 'System provides comprehensive support for accepting payment by Direct Debit.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133eaca-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.1', 'Payments: Standing Orders', 'System provides comprehensive support for accepting payment by Standing Order.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133ebc4-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.1', 'Reject Causes SMS', 'When a Direct Debit is rejected (or a check with insufficient funds, or a bad bank account number,NOW(),NOW()), the system can automatically send an SMS message, and/or E-mail message to the constituent based on their communications preferences.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133ecaa-52a5-11df-84e5-000ae4cc0097', 'f1dfe4b6-52a0-11df-84e5-000ae4cc0097', '5.3.1', 'Reject Failure Codes', 'If a payment is rejected, the system will capture the failure codes.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133ee62-52a5-11df-84e5-000ae4cc0097', 'f1dfea74-52a0-11df-84e5-000ae4cc0097', '5.4.1', 'Adjusting Designations', 'When a change is made to gift designation, system generates offsetting entries for the G/L feed.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133ef3e-52a5-11df-84e5-000ae4cc0097', 'f1dfea74-52a0-11df-84e5-000ae4cc0097', '5.4.2', 'Chart of Accounts', 'Financial transactions transfer to the G/L following the Greenpeace Common Chart of Accounts standard (COCOA,NOW(),NOW()) in a format directly accessible by Sun Systems accounting software.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133f038-52a5-11df-84e5-000ae4cc0097', 'f1dfea74-52a0-11df-84e5-000ae4cc0097', '5.4.3', 'Designation to Credit Account', 'The fundraising system contains a mapping of funding designations to the corresponding G/L credit account.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133f128-52a5-11df-84e5-000ae4cc0097', 'f1dfea74-52a0-11df-84e5-000ae4cc0097', '5.4.4', 'G/L Interface', 'The system can feed both sides (credit & debit,NOW(),NOW()) of a transaction to the G/L.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133f218-52a5-11df-84e5-000ae4cc0097', 'f1dfea74-52a0-11df-84e5-000ae4cc0097', '5.4.5', 'Posted Transactions', 'Once a financial transaction has been posted to the G/L, it is locked against further changes. All alterations must be made by an adjusting transactions.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133f330-52a5-11df-84e5-000ae4cc0097', 'f1dfea74-52a0-11df-84e5-000ae4cc0097', '5.4.6', 'Refund Processing', 'A refund can be entered in a donor''s record and the appropriate transactions will be generated for G/L and A/P to generated a refund check.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133f3f8-52a5-11df-84e5-000ae4cc0097', 'f1dfea74-52a0-11df-84e5-000ae4cc0097', '5.4.7', 'Reversing Transactions', 'When a donation is reversed, the offsetting transaction is generated for finance system, the reason is captured.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133f52e-52a5-11df-84e5-000ae4cc0097', 'f1dfea74-52a0-11df-84e5-000ae4cc0097', '5.4.8', 'Subledger', 'Donor database can function as a true subledger to the G/L, including the retention of detail, capture of an audit trail, security on the batch entry of financial transactions, etc.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133f704-52a5-11df-84e5-000ae4cc0097', 'f1dff028-52a0-11df-84e5-000ae4cc0097', '5.5.1', 'Batch Import', 'Gift transactions in the feed will flow into input batch & await operator action prior to posting.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133f7f4-52a5-11df-84e5-000ae4cc0097', 'f1dff028-52a0-11df-84e5-000ae4cc0097', '5.5.2', 'Changes During Upload', 'If during an upload, an existing record is detected and it contains an address change, the change can be automatically made to the main database.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133f902-52a5-11df-84e5-000ae4cc0097', 'f1dff028-52a0-11df-84e5-000ae4cc0097', '5.5.3', 'File Verification', 'System has a method to automatically compare activity reports from outsource vendors with import/export files and report discrepancies.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133fa06-52a5-11df-84e5-000ae4cc0097', 'f1dff028-52a0-11df-84e5-000ae4cc0097', '5.5.4', 'Import Header Data', 'In-bound feed will accept batch reconciliation data contained in header.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133fb0a-52a5-11df-84e5-000ae4cc0097', 'f1dff028-52a0-11df-84e5-000ae4cc0097', '5.5.5', 'Import Report', 'Provides detail and summary reports of data imported.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b133fc4a-52a5-11df-84e5-000ae4cc0097', 'f1dff028-52a0-11df-84e5-000ae4cc0097', '5.5.6', 'Modify Import Format', 'GP will be able to modify format of inbound data feed.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13434d0-52a5-11df-84e5-000ae4cc0097', 'f1dff028-52a0-11df-84e5-000ae4cc0097', '5.5.7', 'New Donors Created', 'New donors can be added via import feed.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134358e-52a5-11df-84e5-000ae4cc0097', 'f1dff028-52a0-11df-84e5-000ae4cc0097', '5.5.8', 'Web Interface', 'System supports a bi-directional feed interface with the system containing web marketing and on-line transactions.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1343778-52a5-11df-84e5-000ae4cc0097', 'f1dffb86-52a0-11df-84e5-000ae4cc0097', '6.1.1', 'Base 64 Encoding', 'Supports Base 64 Encoding, such as Japan: ISO-2022-JP charset for mobile/email, especially subject line', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1343836-52a5-11df-84e5-000ae4cc0097', 'f1dffb86-52a0-11df-84e5-000ae4cc0097', '6.1.2', 'Double Byte', 'Provides double byte character support (ex: Russian,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1343a16-52a5-11df-84e5-000ae4cc0097', 'f1dffb86-52a0-11df-84e5-000ae4cc0097', '6.1.3', 'Japanese charset', 'Supports ISO-2022-JP charset', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1343ad4-52a5-11df-84e5-000ae4cc0097', 'f1dffb86-52a0-11df-84e5-000ae4cc0097', '6.1.4', 'Language Display', 'Able to display all supported languages properly (on all supported devices,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1343b92-52a5-11df-84e5-000ae4cc0097', 'f1dffb86-52a0-11df-84e5-000ae4cc0097', '6.1.5', 'Multi-language support', 'The admin interface is available in several languages', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1343c50-52a5-11df-84e5-000ae4cc0097', 'f1dffb86-52a0-11df-84e5-000ae4cc0097', '6.1.6', 'QP Encoding', 'Supports QP Encoding (another MIME encoding format,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1343d0e-52a5-11df-84e5-000ae4cc0097', 'f1dffb86-52a0-11df-84e5-000ae4cc0097', '6.1.7', 'AOL Format', 'Support AOL format for email (see: http://articles.sitepoint.com/article/format-html-email-aol#,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1343dcc-52a5-11df-84e5-000ae4cc0097', 'f1dffb86-52a0-11df-84e5-000ae4cc0097', '6.1.8', 'Support for i18n', 'Supports i18n and the ability to edit all user facing text (ex: form label, error messages, auto reply, etc.,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1343e94-52a5-11df-84e5-000ae4cc0097', 'f1dffb86-52a0-11df-84e5-000ae4cc0097', '6.1.9', 'Unicode', 'Provides support for Unicode (UTF8,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1344006-52a5-11df-84e5-000ae4cc0097', 'f1e0013a-52a0-11df-84e5-000ae4cc0097', '6.2.1', 'International Address Standards', 'System supports international address formatting using the standards of the Universal Postal Union (UPU,NOW(),NOW()) for all BOOST NRO sites', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13440d8-52a5-11df-84e5-000ae4cc0097', 'f1e0013a-52a0-11df-84e5-000ae4cc0097', '6.2.2', 'International Name Formats', 'Support for various name formats, such as a Chinese name written in English where the surname is displayed first.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13441b4-52a5-11df-84e5-000ae4cc0097', 'f1e0013a-52a0-11df-84e5-000ae4cc0097', '6.2.3', 'International Postal & Phone', 'International addresses correctly format all international postal codes & phone numbers.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134429a-52a5-11df-84e5-000ae4cc0097', 'f1e0013a-52a0-11df-84e5-000ae4cc0097', '6.2.4', 'Language Preferences', 'System can capture a constituentsâ€™ ethnic origin and language preferences (e.g., Spanish, Catalan, Vasque, Gallego,NOW(),NOW()) â€” both written and spoken.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13443a8-52a5-11df-84e5-000ae4cc0097', 'f1e0013a-52a0-11df-84e5-000ae4cc0097', '6.2.5', 'Multiple Entities', 'System can support multiple legal entities or organizations within one office.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13444ac-52a5-11df-84e5-000ae4cc0097', 'f1e0013a-52a0-11df-84e5-000ae4cc0097', '6.2.6', 'Multiple Languages', 'System supports multiple different languages, currencies, and character sets within one NRO.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134456a-52a5-11df-84e5-000ae4cc0097', 'f1e0013a-52a0-11df-84e5-000ae4cc0097', '6.2.7', 'Multiple Languages on Screens', 'Data entry screens (field names, commands, etc. ,NOW(),NOW()) can be displayed in an NRO''s preferred language.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1344628-52a5-11df-84e5-000ae4cc0097', 'f1e0013a-52a0-11df-84e5-000ae4cc0097', '6.2.8', 'Multiple Character Sets', 'Constituent data can be stored in more than one character set in the same data base, e.g. the Hong Kong office can store some name and address information in Traditional Chinese, and others in English.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1344790-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.0', 'End-User Reporting', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1344830-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.1', 'Benchmarking Across NROs', 'System analytics and reporting support benchmarking across NROs.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13448f8-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.2', 'Calculated Fields', 'An NRO can define its own calculated fields on financial information that can be stored in a constituent''s record and used in a query and a report (e.g., constituent''s YTD donations to a fund or campaign,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13449ca-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.3', 'Currency Formats', 'Currency amounts are properly formatted for all standard international currencies.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1344a88-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.4', 'Custom Reports', 'Can build / export custom analytics reports', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1344b46-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.5', 'Custom Fields in Reports', 'User-defined fields and calculated fields are available for use in any query or end-user designed report.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1344c0e-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.6', 'Data Mining', 'Vendor solution contains data mining capability.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1344cc2-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.7', 'DD Average Donation', 'System can calculate the average donation per shift, venue, recruiter, and leader.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1344d80-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.8', 'Dynamic Queries', 'Query results sets can be saved as dynamic sets that are automatically refreshed by the system on a periodic basis.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1344e48-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.9', 'End-User Query', 'System contains an integrated end-user query tool with â€˜drag-and-dropâ€™ functionality when selecting fields.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1344f10-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.1', 'End-User Query Tool', 'The system''s query tool is provided to allow selecting on any data about a donor, including donor type, biographical and demographical characteristics, and all contributions (both in summary and in detail,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1344fec-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.1', 'Exception Reporting', 'Exception-based reporting: exceeded thresholds trigger alerts', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13450aa-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.1', 'Export Formats', 'Export reports to MS Excel, CSV, or other formats', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1345172-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.1', 'Formatted Reports', 'Users can format reports with variable fonts and other formatting features as part of the report design process.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134523a-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.1', 'Full Text Search', 'System provides a full-text search on all data in constituents '' records.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1345302-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.1', 'HTML Output', 'Deliver reports via HTML e-mail (no application access required,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13453ca-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.1', 'Portable Queries', 'Query specifications are portable and can be shared with other NROs using the system.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134549c-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.1', 'Portable Reports', 'Report specifications are portable and can be shared with other NROs using the system.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134555a-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.1', 'Query Views', 'Queries can be run directly against the database or against custom views created to simplify end-user query & reporting.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134562c-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.1', 'Real-Time Data', 'Reports are generated based on real-time data', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13456ea-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.2', 'Recruiter Goals', 'The tracking of recruiters includes capturing goals for number of sign-ups as well as revenue, and producing reports comparing actual performance to goal by recruiter and rolled up to the team, etc., in the hierarchy.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13457da-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.2', 'Recruiter Performance Tracking', 'The tracking of recruiter performance includes the number of hours, location, number signed up, amount raised.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13458a2-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.2', 'Report Distribution', 'End-user reports can be set to run automatically at specific times and the output can be automatically posted to a portal or E-mailed to a distribution list.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134960a-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.2', 'Report Formats', 'All reports can be produced in a variety of formats including Word, Excel, Open Office, PDF, and html.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13497cc-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.2', 'Report Outputs', 'End-user reports can be printed locally, on a network printer, on screen, or to a file.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13498bc-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.2', 'Report Sharing', 'Reports can be bookmarked, exported, and shared across the organization (to other NROs,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1349b82-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.2', 'Report Writer Data', 'All data that has been entered into the system is accessible via the report writer.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1349c72-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.2', 'Report/Query History', 'System can maintain a record of queries and reports â€“ when run, by whom, and search criteria.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1349d58-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.2', 'Reporting Currency', 'Financial data can be reported in a currency different than how it is stored.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1349e3e-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.2', 'Reporting Tools', 'Ability to define reports in third-party environment (e.g., Crystal,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1349f2e-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.3', 'Saved Queries', 'End-user designed queries can be given a name, saved on the system, and used again at a later time and re-run as a dynamic query.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134a014-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.3', 'Saved Reports', 'Reports can be designed by the end-user and saved as menu items with run-time parameters (e.g., gift ranges, gift dates, postal code range,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134a0fa-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.3', 'Scheduled Reports', 'Scheduled report generation and delivery', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134a1cc-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.3', 'Standard Reporting Tool', 'The end-user tool is an industry standard report writer for which instruction manuals, tutorials, and training are readily available in each of the NRO''s preferred languages.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134a2ee-52a5-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.1.3', 'Static Queries', 'Query results sets can be saved as a static set and reused.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134a456-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.1', 'Analytics', 'Supports analytics of a campaign at the campaign and appeal level (cf. appeal aggregate,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134a514-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.2', 'Break Even Analysis', 'Supports break-even analysis on campaigns.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134a5d2-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.3', 'Budget Comparison', 'Has the ability to report on budget to actual and forecast to budget for each campaign at the relevant detail level.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134a69a-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.4', 'Budget Level', 'System contains the ability to incorporate budget lines at the Source Code Level and show budget vs. actual variances.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134a762-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.5', 'Campaign Expense Tracking', 'Expenses for a campaign can be captured within the system to facilitate calculating ROI and lifetime (or â€˜long-termâ€™,NOW(),NOW()) value.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134a834-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.6', 'Campaign Reports', 'Operational and performance based reports as well as supporter analysis reports', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134a8f2-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.7', 'Campaign ROI Reports', 'Can view return on investment for one campaign', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134a9c4-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.8', 'Constituent Life Cycle', 'System tracks a constituent''s life cycle.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134aa82-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.9', 'Cross-Channel Reporting', 'Can report on cross-channel and cross-category campaigns', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134ab4a-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.1', 'Distributing Invoices', 'Has the ability to charge vendor invoices to relevant detail level of the source code.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134ac12-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.1', 'Email Response Tracking', 'Provide the flexibility to define and track various levels of response (i.e., e-mail opens, e-mail click-throughs, and donations associated with the e-mail,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134acee-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.1', 'Expense Tracking', 'System supports the ability to track revenue and expenses at the source code level.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134adde-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.1', 'Key Performance Indicators', 'System has the ability to select multiple KPIâ€™s (key performance indicators,NOW(),NOW()), e.g. total mailed, total responded, total donations, or total cost, and easily produce formulated KPIâ€™s (average gift, response rate, etc,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134b036-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.1', 'Lifetime Value', 'System can produces a lifetime value analysis that includes a user-defined subpopulation (i.e., individual, acquisition list, acquisition mailing, premium level, theme level,NOW(),NOW()) based on the lifetime year (from anniversary date of the first gift,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134b144-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.1', 'Market Type Analysis', 'System provides a report displaying Market Type Level (direct mail, telemarketing, e-mail,NOW(),NOW()) and budget vs. actual information YTD, with drill-down capabilities to an individual Market Type activity and then individual mail activity.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134b248-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.1', 'Query of Source', 'The end-user has a query tool to allow ad hoc analysis of the source code file (or its equivalent,NOW(),NOW()) providing reporting on segments of the code, with field breaks and subtotals.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134b356-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.1', 'Response Analysis', 'Has the ability to monitor the number of responses to a campaign to measure effectiveness.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134b45a-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.1', 'Response Tracking', 'Can track response to a message in a specific campaign as well as across campaigns over a period of time', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134b540-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.1', 'Response/ROI Tracking', 'System tracks response rates, costs and ROI for a campaign or program.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134b612-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.2', 'Retention Analysis', 'Has the ability to report on the trends of retention with ability to drill down to type of mailing by lifetime year (based on anniversary date of first gift,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134b702-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.2', 'ROI Analysis', 'Provide post-campaign ROI analysis', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134b7d4-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.2', 'Scoring', 'System can score donors for probability of response, probability of defection, program affinity.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134b8b0-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.2', 'Source Code Detail', 'System source file stores cost of mailing or initiative, cost per piece, net income, net per thousand, cost of funds and net per donor.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134b996-52a5-11df-84e5-000ae4cc0097', 'f1e01198-52a0-11df-84e5-000ae4cc0097', '7.2.2', 'Source Data Detail', 'Has the ability to capture a snapshot of characteristics such as lifetime giving, recency, postal code, etc. as they existed at the time of a mailing for subsequent campaign or source code analysis.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134bbb2-52a5-11df-84e5-000ae4cc0097', 'f1e01c9c-52a0-11df-84e5-000ae4cc0097', '8.1.1', 'Donation in Dashboard', 'Supporter can set up a requiring donation in dashboard, including the amount, frequency, and duration.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134bc70-52a5-11df-84e5-000ae4cc0097', 'f1e01c9c-52a0-11df-84e5-000ae4cc0097', '8.1.2', 'Donation Receipts', 'Supporter can see and print a receipt for their donation on line.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134bd2e-52a5-11df-84e5-000ae4cc0097', 'f1e01c9c-52a0-11df-84e5-000ae4cc0097', '8.1.3', 'On-Line Donations', 'Can manage pledges and donation transactions, as well as supporter signups coming from online forms page', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134be00-52a5-11df-84e5-000ae4cc0097', 'f1e01c9c-52a0-11df-84e5-000ae4cc0097', '8.1.4', 'Recurring Maintenance', 'Self-service function allows a supporter to change or stop a recurring donation', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134bec8-52a5-11df-84e5-000ae4cc0097', 'f1e01c9c-52a0-11df-84e5-000ae4cc0097', '8.1.5', 'Services Donations', 'Can manage donations of services', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134bf7c-52a5-11df-84e5-000ae4cc0097', 'f1e01c9c-52a0-11df-84e5-000ae4cc0097', '8.1.6', 'Mobile technology compatible', 'Enables interaction with mobile technology sources such as mobile optimised webpages', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134c0f8-52a5-11df-84e5-000ae4cc0097', 'f1e02264-52a0-11df-84e5-000ae4cc0097', '8.2.1', 'Double opt-in', 'Opt-in with confirmation by email (cf. spam-law compliance,NOW(),NOW()) is provided.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134c1ca-52a5-11df-84e5-000ae4cc0097', 'f1e02264-52a0-11df-84e5-000ae4cc0097', '8.2.2', 'Form data persistence', 'Support for form auto-refill, cookie or ticket based', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134c29c-52a5-11df-84e5-000ae4cc0097', 'f1e02264-52a0-11df-84e5-000ae4cc0097', '8.2.3', 'Opt-in forms', 'System allows setting up several opt-in forms for the same list', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134c382-52a5-11df-84e5-000ae4cc0097', 'f1e02264-52a0-11df-84e5-000ae4cc0097', '8.2.4', 'Single opt-in list', 'Systems provides opt-in with no confirmation by email (cf. spam-free database import,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134c47c-52a5-11df-84e5-000ae4cc0097', 'f1e02264-52a0-11df-84e5-000ae4cc0097', '8.2.5', 'Single opt-out', 'One click unsubscribe link is supported.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134c576-52a5-11df-84e5-000ae4cc0097', 'f1e02264-52a0-11df-84e5-000ae4cc0097', '8.2.6', 'Survey', 'System supports managing surveys.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134c634-52a5-11df-84e5-000ae4cc0097', 'f1e02264-52a0-11df-84e5-000ae4cc0097', '8.2.7', 'WebPages', 'Set up thank you pages, goodbye landing pages, etc. can be created.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134fb68-52a5-11df-84e5-000ae4cc0097', 'f1e02f20-52a0-11df-84e5-000ae4cc0097', '9.1.1', 'Ad Hoc Upload', 'Has the ability for an NRO to do ad hoc data file imports. The NRO can define the import data format and the mapping to records and fields without the assistance of the vendor.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134fc3a-52a5-11df-84e5-000ae4cc0097', 'f1e02f20-52a0-11df-84e5-000ae4cc0097', '9.1.2', 'Add a Table', 'Data structure would allow GP to add a table.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134fcf8-52a5-11df-84e5-000ae4cc0097', 'f1e02f20-52a0-11df-84e5-000ae4cc0097', '9.1.3', 'All Fields Available', 'All data fields in a constituent record, or financial transaction, can be imported by the system.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134fdc0-52a5-11df-84e5-000ae4cc0097', 'f1e02f20-52a0-11df-84e5-000ae4cc0097', '9.1.4', 'Preserves Customizations', 'Customizations created by the vendor, or created by Greenpeace using a vendor-approved methodology, will be carried forward through subsequent software releases.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b134ff50-52a5-11df-84e5-000ae4cc0097', 'f1e0342a-52a0-11df-84e5-000ae4cc0097', '9.2.1', 'API login', 'Provides an API login that restricts API usage by IP range and requires authentication (can be deactivated by default,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1350022-52a5-11df-84e5-000ae4cc0097', 'f1e0342a-52a0-11df-84e5-000ae4cc0097', '9.2.2', 'Google Analytics', 'Google Analytics Integration to track conversions and activity from email to website.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13500fe-52a5-11df-84e5-000ae4cc0097', 'f1e0342a-52a0-11df-84e5-000ae4cc0097', '9.2.3', 'LDAP', 'System supports LDAP integration', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13501e4-52a5-11df-84e5-000ae4cc0097', 'f1e0342a-52a0-11df-84e5-000ae4cc0097', '9.2.4', 'Library wrappers', 'A class/library is available in several programming languages (Java, PHP, .Net, Python,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13502de-52a5-11df-84e5-000ae4cc0097', 'f1e0342a-52a0-11df-84e5-000ae4cc0097', '9.2.5', 'XML/RPC', 'Provides basic API facilities with access to ALL objects and data', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13504a0-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.1', 'Donor Self-Service', 'System provides an API, Web Services, or other interface facilitating on-line donor self-service.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1350572-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.2', 'Export Reporting', 'System provides detail and summary reports of data exported.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b135070c-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.3', 'Flat-File Interfacing', 'System has comprehensive support for creating and importing flat-file constituent and transaction data with other systems.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13507fc-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.4', 'GIS Upload', 'System supports the automatic upload of GIS coordinates (in countries where they can be obtained,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1350900-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.5', 'Import Editing', 'Data can be altered (by NRO-authored routines,NOW(),NOW()) at data import (e.g. to change an incorrect source code,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1350a0e-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.6', 'Import Errors are Logged', 'During imports, records that do not meet data integrity rules are logged for review.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1350ad6-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.7', 'Import Formats', 'Import files can be in CSV, fixed length, or XML format.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1350b94-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.8', 'Online Community Participation', 'If an online community is established, the system can reflect participation in a donorâ€™s record.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1350c5c-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.9', 'Output Formats', 'Output files can be in CSV, fixed length, or XML format.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1350ec8-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.1', 'Real-Time Integration', 'Supports open database standards such as SQL, ODBC, XML, and Web Services.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1350fa4-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.1', 'REST Date Exchange', 'System supports data exchange using REST (Representational State Transfer,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1351076-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.1', 'Reviewing Import Files', 'Import files can be viewed and edited before committing to the import.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b135113e-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.1', 'SOAP Data Exchange', 'System supports data exchange using SOAP (Simple Object Access Protocol,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b135121a-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.1', 'Source Code Import', 'Campaign and source codes can be imported from an Excel spreadsheet.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13512ec-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.1', 'Telephone Interface', 'System interfaces with all common telephone systems and provides outbound dialing, automatic creation of a call record, and the result of the call.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13513d2-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.1', 'Touch Point Integration', 'Has the ability to import contacts, or "touch points", from other databases.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13514a4-52a5-11df-84e5-000ae4cc0097', 'f1e03920-52a0-11df-84e5-000ae4cc0097', '9.3.1', 'Web Activity', 'Web activity can be captured for an individual including web page visits, click-throughs, E-mail opening, etc., and can be used to segment file as well as provide overall statistics.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1351652-52a5-11df-84e5-000ae4cc0097', 'f1e03eca-52a0-11df-84e5-000ae4cc0097', '9.4.1', 'Query Performance', 'Multiple end-user queries can be run during peak usage hours without impacting system performance.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1351742-52a5-11df-84e5-000ae4cc0097', 'f1e03eca-52a0-11df-84e5-000ae4cc0097', '9.4.2', 'Scalability', 'Demonstrated ability to support at least 1 million active constituent records while providing acceptable response time. ', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1351828-52a5-11df-84e5-000ae4cc0097', 'f1e03eca-52a0-11df-84e5-000ae4cc0097', '9.4.3', 'Simultaneous Users', 'Supports at least 50 simultaneous users with acceptable performance.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1351922-52a5-11df-84e5-000ae4cc0097', 'f1e03eca-52a0-11df-84e5-000ae4cc0097', '9.4.4', 'Table Locking', 'All system processes, except backup and restore functions, can be performed without locking tables or files or otherwise preventing other users from continuing to work.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1351b02-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.1', 'Account', 'Native built-in account concept that allow sharing content (across NROs,NOW(),NOW())', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1351bd4-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.2', 'Constituent Segments', 'System provides support for tracking all constituents (financial and non,NOW(),NOW()) with strong role-based security restricting what users can see and change based on the type of constituent. An individual constituent might be in multiple groups.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1351cd8-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.3', 'Data Sharing', 'Lists, contacts, etc. can be shared or made private across accounts', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1351dbe-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.4', 'EU Data Protection', 'The system is fully compliant with the EU data protection act.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1351eb8-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.5', 'EU Safe Harbor', 'System has achieved Safe Harbor status for EU data.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1351fc6-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.6', 'NRO Controls Tables', 'NROs can maintain their own code tables including those for Origin, Source Code, Campaigns, Fund (or Designation,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1352098-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.7', 'Record Ownership', 'System security allows groups of users to be able to add/update records that they "own", but might only permit view-only access to other records.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b135216a-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.8', 'Right management', 'Multi-user, multi-role, multi-resources right management (cf. ACL-like,NOW(),NOW()) is supported.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b135223c-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.9', 'Security Levels', 'Supports security levels including "No access", "View only" and "Write".', '2010-04-28 11:09:03', '2010-04-28 11:09:03');
INSERT INTO `requirements` (`id`, `parent_id`, `serial`, `name`, `description`, `created`, `modified`) VALUES
('b1352304-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.1', 'Security: Field Level', 'Security level can be set at the field level.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13523d6-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.1', 'Security: Import/Export', 'Data files imported or exported can be encrypted.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b135249e-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.1', 'Security: Record Level', 'Record level security is provided limiting access to the record to an individual user or group of users.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b135257a-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.1', 'Security: Report Writer', 'All security carries over to reporting tools, so if a user does not have view access to a particular data element, they cannot see that data in a report that they run.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1352660-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.1', 'Security: Role Based', 'System provides role based security to control access by a remote agency in which all individual-specific information is shielded, or a telemarketer to only be able to log the results of a call, but not to view personal information.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1352746-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.1', 'Single Sign-On', 'System supports single sign-on authentication.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b135280e-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.1', 'Spanish Data Protection', 'The system is fully compliant with the Spanish data protection law (LODP,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13528e0-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.1', 'Table Level Security', 'Security can be set at the table level.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b13529a8-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.1', 'Table Security', 'Table lookup values can be restricted by access level.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1352a70-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.1', 'Thin Client', 'All functions in the system can be accessed using a thin client (zero foot-print,NOW(),NOW()).', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('b1356abc-52a5-11df-84e5-000ae4cc0097', 'f1e044c4-52a0-11df-84e5-000ae4cc0097', '9.5.2', 'User Table Values', 'Table values displayed for a user are controlled by that user''s access security.', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1dfadc0-52a0-11df-84e5-000ae4cc0097', '1d2a30c6-5211-11df-952d-000ae4cc0097', '4.5.0', 'E-Mail and SMS', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1dfbffe-52a0-11df-84e5-000ae4cc0097', '1d2a30c6-5211-11df-952d-000ae4cc0097', '4.6.0', 'Email Campaigns', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1dfc706-52a0-11df-84e5-000ae4cc0097', '1d2a30c6-5211-11df-952d-000ae4cc0097', '4.7.0', 'List Management', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1dfcda0-52a0-11df-84e5-000ae4cc0097', '1d2a30c6-5211-11df-952d-000ae4cc0097', '4.8.0', 'Reply Handling', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1dfd368-52a0-11df-84e5-000ae4cc0097', NULL, '5.0.0', 'Financial', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1dfd930-52a0-11df-84e5-000ae4cc0097', 'f1dfd368-52a0-11df-84e5-000ae4cc0097', '5.1.0', 'Gift Processing', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1dfdef8-52a0-11df-84e5-000ae4cc0097', 'f1dfd368-52a0-11df-84e5-000ae4cc0097', '5.2.0', 'Receipts/Acknowledgements', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1dfe4b6-52a0-11df-84e5-000ae4cc0097', 'f1dfd368-52a0-11df-84e5-000ae4cc0097', '5.3.0', 'Banking Interface', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1dfea74-52a0-11df-84e5-000ae4cc0097', 'f1dfd368-52a0-11df-84e5-000ae4cc0097', '5.4.0', 'General Ledger Interface', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1dff028-52a0-11df-84e5-000ae4cc0097', 'f1dfd368-52a0-11df-84e5-000ae4cc0097', '5.5.0', 'Outsourced Processing', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1dff5dc-52a0-11df-84e5-000ae4cc0097', NULL, '6.0.0', 'Internationalization', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1dffb86-52a0-11df-84e5-000ae4cc0097', 'f1dff5dc-52a0-11df-84e5-000ae4cc0097', '6.1.0', 'Coding', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1e0013a-52a0-11df-84e5-000ae4cc0097', 'f1dff5dc-52a0-11df-84e5-000ae4cc0097', '6.2.0', 'Data Maintenance', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1e006e4-52a0-11df-84e5-000ae4cc0097', NULL, '7.0.0', 'Analytics and Reporting', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1e01198-52a0-11df-84e5-000ae4cc0097', 'f1e006e4-52a0-11df-84e5-000ae4cc0097', '7.2.0', 'Campaign/Appeal Analytics', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1e0168e-52a0-11df-84e5-000ae4cc0097', NULL, '8.0.0', 'Web', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1e01c9c-52a0-11df-84e5-000ae4cc0097', 'f1e0168e-52a0-11df-84e5-000ae4cc0097', '8.1.0', 'Supporter Donation', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1e02264-52a0-11df-84e5-000ae4cc0097', 'f1e0168e-52a0-11df-84e5-000ae4cc0097', '8.2.0', 'Webpage & Processes', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1e0294e-52a0-11df-84e5-000ae4cc0097', NULL, '9.0.0', 'Technical Considerations', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1e02f20-52a0-11df-84e5-000ae4cc0097', 'f1e0294e-52a0-11df-84e5-000ae4cc0097', '9.1.0', 'Flexibility', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1e0342a-52a0-11df-84e5-000ae4cc0097', 'f1e0294e-52a0-11df-84e5-000ae4cc0097', '9.2.0', 'Integration', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1e03920-52a0-11df-84e5-000ae4cc0097', 'f1e0294e-52a0-11df-84e5-000ae4cc0097', '9.3.0', 'Interfaces', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1e03eca-52a0-11df-84e5-000ae4cc0097', 'f1e0294e-52a0-11df-84e5-000ae4cc0097', '9.4.0', 'Performance', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03'),
('f1e044c4-52a0-11df-84e5-000ae4cc0097', 'f1e0294e-52a0-11df-84e5-000ae4cc0097', '9.5.0', 'Security', '', '2010-04-28 11:09:03', '2010-04-28 11:09:03');

-- --------------------------------------------------------

--
-- Table structure for table `risks`
--

CREATE TABLE IF NOT EXISTS `risks` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `serial` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `project_id` char(36) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ref user_id',
  `risk_category_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` tinytext COLLATE utf8_unicode_ci,
  `probability` enum('high','medium','low') COLLATE utf8_unicode_ci NOT NULL,
  `proximity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `counter_measure` text COLLATE utf8_unicode_ci NOT NULL,
  `current_status` enum('open','increasing','reducing','closed') COLLATE utf8_unicode_ci NOT NULL,
  `created_by` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified_by` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `risks`
--


-- --------------------------------------------------------

--
-- Table structure for table `risk_categories`
--

CREATE TABLE IF NOT EXISTS `risk_categories` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `risk_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` varchar(900) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `office_id` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'null == global scope',
  `created` datetime NOT NULL,
  `created_by` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` char(36) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `permissions`, `description`, `office_id`, `created`, `created_by`, `modified`, `modified_by`) VALUES
('4aaf92da-2268-4cf3-ae3d-461aa7f05a6e', 'admin', '*:*', NULL, '', '2009-09-28 11:45:00', '4aa65fb5-ec64-48ca-a68e-444fa7f05a6e', '2009-09-28 11:45:00', '4aa65fb5-ec64-48ca-a68e-444fa7f05a6e'),
('4aaf92da-b930-4da3-9fa8-4909a7f05a6e', 'root', '*:*', NULL, '', '2009-09-28 11:45:00', '4aa65fb5-ec64-48ca-a68e-444fa7f05a6e', '2009-09-28 11:45:00', '4aa65fb5-ec64-48ca-a68e-444fa7f05a6e'),
('4aaf92da-d574-4b33-a02f-4566a7f05a6e', 'user', '*:*,!*:admin_*,!projects:add,!projects:edit', NULL, '', '2009-09-28 11:45:00', '4aa65fb5-ec64-48ca-a68e-444fa7f05a6e', '2009-09-28 11:45:00', '4aa65fb5-ec64-48ca-a68e-444fa7f05a6e'),
('55f09a6a-7d1a-11df-b17c-000ae4cc0097', 'guest', '!*:*,users:login,users:forgot_password,sidebar:help', 'default account for the public section', NULL, '2010-06-21 11:47:09', '009d4872-68e0-11df-88bf-000ae4cc0097', '2010-06-21 11:47:09', '009d4872-68e0-11df-88bf-000ae4cc0097');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` blob,
  `expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `key`, `user_id`, `data`, `expires`) VALUES
('n7vshbig26ojnkccna87njtjs6', '', NULL, 0x436f6e6669677c613a333a7b733a393a22757365724167656e74223b733a33323a223032386264336336643331396466663666353937663763623736346231353837223b733a343a2274696d65223b693a313237393232303038323b733a373a2274696d656f7574223b693a31303b7d417574687c613a313a7b733a383a227265646972656374223b733a393a222f70726f6a65637473223b7d557365727c613a323a7b733a343a2255736572223b613a373a7b733a323a226964223b733a33363a2234663235303537652d376431642d313164662d623137632d303030616534636330303937223b733a383a22757365726e616d65223b733a353a226775657374223b733a31313a227065726d697373696f6e73223b733a333a222a3a2a223b733a363a226c6f63616c65223b733a323a22656e223b733a383a226c616e6775616765223b733a333a22656e67223b733a363a22616374697665223b733a313a2231223b733a373a22726f6c655f6964223b733a33363a2235356630396136612d376431612d313164662d623137632d303030616534636330303937223b7d733a343a22526f6c65223b613a323a7b733a31313a227065726d697373696f6e73223b733a35313a22212a3a2a2c75736572733a6c6f67696e2c75736572733a666f72676f745f70617373776f72642c736964656261723a68656c70223b733a343a226e616d65223b733a353a226775657374223b7d7d, 1279220082);

-- --------------------------------------------------------

--
-- Table structure for table `software`
--

CREATE TABLE IF NOT EXISTS `software` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `open_source` tinyint(1) NOT NULL,
  `as_a_service` tinyint(1) NOT NULL,
  `vendor_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `software`
--


-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `country_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `country_id`, `name`) VALUES
('728fb3a2-59d6-11df-9ccf-000ae4cc0097', 'c5cf7076-5110-11df-9f9e-000ae4cc0097', 'north holland');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `person_id` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role_id` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '4aaf92da-d574-4b33-a02f-4566a7f05a6e',
  `permissions` varchar(900) COLLATE utf8_unicode_ci DEFAULT '*:*',
  `username` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `language` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'eng',
  `office_id` char(36) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `public_key` text COLLATE utf8_unicode_ci,
  `created` datetime NOT NULL,
  `created_by` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` char(36) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `person_id`, `role_id`, `permissions`, `username`, `password`, `active`, `language`, `office_id`, `locale`, `public_key`, `created`, `created_by`, `modified`, `modified_by`) VALUES
('009d4872-68e0-11df-88bf-000ae4cc0097', '5fbdd0d2-72ff-11df-a593-000ae4cc0097', '4aaf92da-b930-4da3-9fa8-4909a7f05a6e', '*:*', 'root@greenpeace.org', '26f2cc8a22381cafbeae7dd282f1ec1de407207f', 1, 'eng', 'f375fcec-59d1-11df-9ccf-000ae4cc0097', '', NULL, '2010-05-26 00:00:00', '009d4872-68e0-11df-88bf-000ae4cc0097', '2010-05-26 00:00:00', '009d4872-68e0-11df-88bf-000ae4cc0097'),
('1fe04230-8b58-11df-b4d7-000ae4cc0097', '5fbdd0d2-72ff-11df-a593-000ae4cc0097', '4aaf92da-d574-4b33-a02f-4566a7f05a6e', '*:*', 'remy.bertot@greenpeace.org', '26f2cc8a22381cafbeae7dd282f1ec1de407207f', 1, 'eng', NULL, '', NULL, '2010-07-09 14:47:07', '009d4872-68e0-11df-88bf-000ae4cc0097', '2010-07-09 14:47:07', '009d4872-68e0-11df-88bf-000ae4cc0097'),
('4f25057e-7d1d-11df-b17c-000ae4cc0097', NULL, '55f09a6a-7d1a-11df-b17c-000ae4cc0097', '*:*', 'guest', 'guest', 1, 'eng', '', 'en', NULL, '2010-06-21 12:10:35', '009d4872-68e0-11df-88bf-000ae4cc0097', '2010-06-21 12:10:50', '009d4872-68e0-11df-88bf-000ae4cc0097');

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE IF NOT EXISTS `vendors` (
  `id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country_id` char(36) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vendors`
--

